# Reference-method experiment

This is a separate exploratory computation on the existing T-shirt recordings. It does not change Overleaf, GitHub, the source CSVs, or the grouped-validation results.

## Fixed design, before fitting

- Reference: Elgendi et al., DOI 10.1038/s44172-026-00675-8, supplied article-in-press PDF.
- Computational reference: `Elgendi/LooseGarment2024/T_shirt_Analysis_3.ipynb`, Git blob `5657d4fee992ddca16de696e55c856308da8343e`. The 50/50 example is in `T_shirt_Paper2.ipynb`, blob `a528e23680b8b6ff2af655af3df5cae07464291b`.
- Inputs: the three unchanged CSVs used by the existing participant-calibrated analysis, under `../tshirt_algorithm_benchmark_20260918/data/processed/`.
- Map the reference's 12 numeric columns to elapsed_s, adc_s1 through adc_s10, and position_index. Raw ADC counts represent the acquired electrical signal, as opposed to engineered temporal features. Converting counts linearly to nominal voltage before z-scoring would give equivalent standardized inputs.
- Coerce those 12 fields to numeric and remove a row only if one is missing, matching the reference's complete-case dropna on its 12-field input. Nonfinite values cause an explicit error instead of an undisclosed extra filtering rule.
- Retain initial baseline, holds and movements. Retain saturation readings. Do not apply the grouped analysis's ADC quality mask, imputation, feature windows, boundary trimming, additional peak exclusion, or protocol-aware normalization.
- Keep all eight original position_index labels. Their semantic movement differences from the reference study are not changed.
- Fit models separately for P01, P02 and P03.
- Exhaust all 10 single sensors, 45 pairs and 120 triplets.
- Use stratified random row holdouts with test proportions 0.2, 0.3 and 0.5. As in the reference combination evaluator, make a split per combination and share that split across the four classifiers.
- Fit StandardScaler on training rows only, then transform test rows.
- Use the reference classifier constructors: XGBClassifier(eval_metric='mlogloss'), RandomForestClassifier(), SVC(), and KNeighborsClassifier(). No hyperparameter search, class weighting or score-driven retries.
- Reproducibility adaptations: base seed 42, deterministic distinct split seeds derived from participant, test fraction and sensor tuple, and recorded model seeds. The reference's combination search has no fixed random seed. Limit model/BLAS thread counts for computation. Historical library versions were not pinned by the reference. These differences prevent a claim of bit-for-bit replication.
- Calculate test accuracy, balanced accuracy, macro-precision, macro-recall, macro-F1, support, confusion matrices and per-class support/recall. Store test row IDs and predictions for every evaluated model.
- Rank by test accuracy, as the reference does. Report both per-participant selected combinations and fixed combinations averaged across participants; do not conflate them. Also report the reference notebook's average across participants and classifiers for each fixed combination.
- This design gives 1,575 participant/split/subset evaluations and 6,300 fitted models. A pilot fits one prespecified triplet only to measure runtime and validate implementation, not to change the plan.
- Verify every input file's SHA-256 before and after, test/train disjointness, split hashes, metric recomputation from saved predictions, all eight class supports, and representative direct-reference replay.

## Interpretation

The selected scores reuse the test set for selection and are not unbiased outer-test estimates. Random-row splits can share the same physical repetition across training and testing. These are reference-matched within-recording results, not new-session or new-participant validation. Comparison with existing grouped scores is descriptive because the units, features, eligibility and selection procedures also differ. No target score is used as a stopping rule.
