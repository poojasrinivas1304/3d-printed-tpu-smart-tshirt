"""Reference-matched random-row benchmark; never edits input data or manuscript."""
import os
for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '1'
import argparse
import hashlib
import itertools
import json
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import scipy
import sklearn
import xgboost
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix, precision_recall_fscore_support
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from threadpoolctl import threadpool_limits
from xgboost import XGBClassifier

HERE = Path(__file__).resolve().parent
DATA = HERE.parent / 'tshirt_algorithm_benchmark_20260918/data/processed'
EXPECTED = {
    'subject_01.csv': '13da7f5642c5a379f88753df0266c8f673b0319323f4cbd3f543593fc321ea43',
    'subject_02.csv': '6b054a0d9963ac56204606bdd160b9eb55eb1b57f55e9f6b8ed2ec4fc97f40a6',
    'subject_03.csv': 'b20b9b4f8653bb841f789dbca18256070ee768cab17cbe7ae015fa552bfc2e84',
}
NAMES = ('XGBoost', 'RandomForest', 'SVM', 'KNN')
LABELS = np.arange(8)
CACHE = {}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def arrhash(a):
    return hashlib.sha256(np.asarray(a, dtype='<i8').tobytes()).hexdigest()


def seed_for(participant, test_fraction, sensors, model='split'):
    token = json.dumps([42, participant, test_fraction, list(sensors), model], separators=(',', ':'))
    return int.from_bytes(hashlib.sha256(token.encode()).digest()[:4], 'little')


def load_data(participant):
    if participant in CACHE:
        return CACHE[participant]
    path = DATA / f'subject_{participant:02d}.csv'
    assert sha(path) == EXPECTED[path.name], f'Changed input: {path}'
    frame = pd.read_csv(path)
    cols = ['elapsed_s'] + [f'adc_s{i}' for i in range(1, 11)] + ['position_index']
    numeric = frame[cols].apply(lambda s: pd.to_numeric(s.astype(str).str.replace(',', '.', regex=False), errors='coerce'))
    keep = ~numeric.isna().any(axis=1)
    selected = numeric.loc[keep]
    assert np.isfinite(selected.to_numpy()).all(), 'Nonfinite input: inspect explicitly'
    assert (selected.position_index == selected.position_index.astype(int)).all()
    X = selected.iloc[:, 1:11].to_numpy(dtype=float)
    y = selected.position_index.to_numpy(dtype=int) - 1
    assert np.array_equal(np.unique(y), LABELS)
    row_ids = np.flatnonzero(keep.to_numpy())
    audit = {
        'participant': f'P{participant:02d}', 'source_sha256': sha(path),
        'source_rows': len(frame), 'eligible_rows': len(selected),
        'excluded_source_rows_0based': np.flatnonzero(~keep.to_numpy()).tolist(),
        'class_support': np.bincount(y, minlength=8).tolist(),
        'phase_counts': frame.loc[keep, 'phase'].value_counts().to_dict(),
        'retained_rows_with_recorded_high_adc_flag': int(frame.loc[keep, 'high_adc_any'].sum()),
        'retained_rows_with_recorded_low_adc_flag': int(frame.loc[keep, 'low_adc_any'].sum()),
    }
    CACHE[participant] = X, y, row_ids, audit, frame.loc[keep].reset_index(drop=True)
    return CACHE[participant]


def model_for(name, seed):
    if name == 'XGBoost':
        return XGBClassifier(eval_metric='mlogloss', random_state=seed, n_jobs=1)
    if name == 'RandomForest':
        return RandomForestClassifier(random_state=seed, n_jobs=1)
    if name == 'SVM':
        return SVC()
    if name == 'KNN':
        return KNeighborsClassifier(n_jobs=1)
    raise ValueError(name)


def metrics(y, pred):
    p, r, f, support = precision_recall_fscore_support(y, pred, labels=LABELS, zero_division=0)
    return {
        'accuracy': float(accuracy_score(y, pred)),
        'balanced_accuracy': float(balanced_accuracy_score(y, pred)),
        'macro_precision': float(p.mean()), 'macro_recall': float(r.mean()), 'macro_f1': float(f.mean()),
        'n_test': len(y), 'n_correct': int(np.sum(y == pred)),
        'class_support': support.tolist(), 'class_recall': r.tolist(),
        'confusion_counts': confusion_matrix(y, pred, labels=LABELS).tolist(),
    }


def task_key(participant, test_fraction, sensors):
    return f'P{participant:02d}_test{int(test_fraction*100):02d}_' + '-'.join(f'S{i}' for i in sensors)


def evaluate(task):
    participant, test_fraction, sensors, output = task
    start = time.monotonic()
    out = Path(output)
    key = task_key(participant, test_fraction, sensors)
    result_path = out / 'tasks' / f'{key}.json'
    prediction_path = out / 'predictions' / f'{key}.npz'
    if result_path.exists() and prediction_path.exists():
        existing = json.loads(result_path.read_text())
        return {'key': key, 'cached': True, 'elapsed_s': existing['elapsed_s']}
    X, y, source_rows, _, frame = load_data(participant)
    split_seed = seed_for(participant, test_fraction, sensors)
    train, test = train_test_split(np.arange(len(y)), test_size=test_fraction, stratify=y, random_state=split_seed)
    assert not np.intersect1d(train, test).size
    assert len(train) + len(test) == len(y)
    cols = np.array(sensors) - 1
    scaler = StandardScaler()
    train_x = scaler.fit_transform(X[train][:, cols])
    test_x = scaler.transform(X[test][:, cols])
    assert np.allclose(scaler.mean_, X[train][:, cols].mean(axis=0))
    records, preds = [], []
    for name in NAMES:
        model_seed = seed_for(participant, test_fraction, sensors, name)
        model = model_for(name, model_seed)
        fit_start = time.monotonic()
        with threadpool_limits(limits=1):
            model.fit(train_x, y[train])
            pred = model.predict(test_x).astype(np.int8)
        rec = {'classifier': name, 'model_seed': model_seed, 'elapsed_s': time.monotonic()-fit_start, **metrics(y[test], pred)}
        records.append(rec)
        preds.append(pred)
    # Diagnostic only: quantify whether the same stored physical repetition enters both partitions.
    groups = list(zip(frame.set_id.to_numpy(), frame.rep.to_numpy()))
    train_groups = {groups[i] for i in train}
    test_groups = {groups[i] for i in test}
    neighbors = np.zeros(len(y), dtype=bool)
    neighbors[train] = True
    adjacent = ((test > 0) & neighbors[np.maximum(test-1, 0)]) | ((test < len(y)-1) & neighbors[np.minimum(test+1, len(y)-1)])
    record = {
        'key': key, 'participant': f'P{participant:02d}', 'test_fraction': test_fraction,
        'n_sensors': len(sensors), 'sensors': list(sensors), 'split_seed': split_seed,
        'n_train': len(train), 'n_test': len(test), 'train_index_sha256': arrhash(source_rows[train]),
        'test_index_sha256': arrhash(source_rows[test]), 'scaler_mean': scaler.mean_.tolist(),
        'scaler_scale': scaler.scale_.tolist(), 'train_groups': len(train_groups), 'test_groups': len(test_groups),
        'shared_groups': len(train_groups & test_groups),
        'test_fraction_with_adjacent_training_row': float(adjacent.mean()),
        'models': records, 'elapsed_s': time.monotonic()-start,
    }
    np.savez_compressed(prediction_path, source_train_row=source_rows[train], source_test_row=source_rows[test],
                        y_true=y[test].astype(np.int8), predictions=np.stack(preds), classifier=np.array(NAMES))
    result_path.write_text(json.dumps(record, indent=2, allow_nan=False))
    return {'key': key, 'cached': False, 'elapsed_s': record['elapsed_s'], 'accuracies': {r['classifier']:r['accuracy'] for r in records}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pilot', action='store_true')
    ap.add_argument('--workers', type=int, default=4)
    args = ap.parse_args()
    out = HERE / ('pilot' if args.pilot else 'results')
    (out / 'tasks').mkdir(parents=True, exist_ok=True)
    (out / 'predictions').mkdir(exist_ok=True)
    audits = [load_data(p)[3] for p in (1, 2, 3)]
    versions = {'python':sys.version, **{m.__name__:m.__version__ for m in (np,pd,sklearn,scipy,joblib,xgboost)}}
    manifest = {'completed':False, 'plan_sha256':sha(HERE/'PLAN.md'), 'script_sha256':sha(__file__),
                'versions':versions, 'inputs':audits, 'base_seed':42,
                'model_parameters':{name:model_for(name,42).get_params() for name in NAMES}, 'workers':args.workers}
    # Missing defaults in XGBoost are represented as null, not guessed historical values.
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2,default=str))
    if args.pilot:
        tasks = [(1,0.5,(1,2,9),str(out))]
    else:
        tasks = [(p,t,s,str(out)) for k in (1,2,3) for t in (0.5,0.2,0.3) for p in (1,2,3)
                 for s in itertools.combinations(range(1,11),k)]
    print(json.dumps({'event':'started','tasks':len(tasks),'fits':len(tasks)*4,'versions':versions}),flush=True)
    started = time.monotonic()
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        futures = [executor.submit(evaluate, t) for t in tasks]
        for completed, future in enumerate(as_completed(futures), 1):
            result = future.result()
            if args.pilot or completed % 10 == 0 or completed == len(tasks):
                print(json.dumps({'event':'progress','complete':completed,'total':len(tasks),'elapsed_s':time.monotonic()-started,**result}),flush=True)
    assert all(sha(DATA/name)==digest for name,digest in EXPECTED.items())
    manifest.update(completed=True,task_count=len(tasks),model_count=len(tasks)*4,elapsed_s=time.monotonic()-started,
                    input_hashes_unchanged=True)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2,default=str))
    print(json.dumps({'event':'complete','elapsed_s':manifest['elapsed_s']}),flush=True)


if __name__ == '__main__':
    main()
