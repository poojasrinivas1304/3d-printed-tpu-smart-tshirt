"""Fixed full-array search. All predictors are contemporaneous sensor readings."""
import os
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_key]='1'
import argparse
import hashlib
import importlib.util
import itertools
import json
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import sklearn
import xgboost
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_sample_weight
from threadpoolctl import threadpool_limits
from xgboost import XGBClassifier

HERE=Path(__file__).resolve().parent
REF=HERE.parent/'tshirt_reference_method_20260919'
spec=importlib.util.spec_from_file_location('reference_benchmark',REF/'benchmark.py')
ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
OUT=HERE/'results'
PAIR=list(itertools.combinations(range(10),2))
TRIPLET=(2,3,10)
PROCEDURES=('triplet_default','all10_default','all10_tuned')
CACHE={}


def clean(value):
    if isinstance(value,dict):return {str(k):clean(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [clean(v) for v in value]
    if isinstance(value,np.ndarray):return clean(value.tolist())
    if isinstance(value,np.generic):return clean(value.item())
    if isinstance(value,float) and not np.isfinite(value):return str(value)
    return value


def save(path,value):
    Path(path).write_text(json.dumps(clean(value),indent=2,allow_nan=False))


def seed(*parts):
    return int.from_bytes(hashlib.sha256(json.dumps([42,*parts],separators=(',',':')).encode()).digest()[:4],'little')


def grid():
    rows=[
        ('RF100','raw','RF',dict(n_estimators=100),False),
        ('RF300_all_features','raw','RF',dict(n_estimators=300,max_features=1.0),False),
        ('RF300_balanced_leaf2','raw','RF',dict(n_estimators=300,max_features=.7,min_samples_leaf=2,class_weight='balanced_subsample'),False),
        ('ExtraTrees300','raw','ET',dict(n_estimators=300,max_features=1.0),False),
        ('ExtraTrees300_balanced_leaf2','raw','ET',dict(n_estimators=300,max_features=1.0,min_samples_leaf=2,class_weight='balanced'),False),
        ('ExtraTrees300_spatial','spatial','ET',dict(n_estimators=300,max_features=.7),False),
        ('ExtraTrees300_spatial_balanced','spatial','ET',dict(n_estimators=300,max_features=.7,min_samples_leaf=2,class_weight='balanced'),False),
        ('XGBoost300_depth3','raw','XGB',dict(max_depth=3,reg_lambda=10),False),
        ('XGBoost300_depth6','raw','XGB',dict(max_depth=6,reg_lambda=5),False),
        ('XGBoost300_spatial_balanced','spatial','XGB',dict(max_depth=3,reg_lambda=10),True),
        ('KNN5_distance','raw','KNN',dict(n_neighbors=5,weights='distance'),False),
        ('KNN15_distance','raw','KNN',dict(n_neighbors=15,weights='distance'),False),
        ('KNN5_spatial_distance','spatial','KNN',dict(n_neighbors=5,weights='distance'),False),
    ]
    return [dict(id=i,name=n,features=v,family=f,parameters=p,balanced_sample_weight=w) for i,(n,v,f,p,w) in enumerate(rows)]


CANDIDATES=grid()


def load(p):
    if p not in CACHE:
        X,y,source,audit,frame=ref.load_data(p)
        assert np.array_equal(source,np.arange(len(y)))
        fold=frame.rep.to_numpy(int).copy();fold[fold==0]=1
        assert set(fold)=={1,2,3,4,5}
        groups=np.array([f'{a}:{b}' for a,b in zip(frame.set_id,frame.rep)])
        CACHE[p]=(X,y,source,audit,frame,fold,groups)
    return CACHE[p]


def setup_model(c,random_state):
    if c['family']=='RF':return RandomForestClassifier(**c['parameters'],random_state=random_state,n_jobs=1)
    if c['family']=='ET':return ExtraTreesClassifier(**c['parameters'],random_state=random_state,n_jobs=1)
    if c['family']=='KNN':return KNeighborsClassifier(**c['parameters'],n_jobs=1)
    return XGBClassifier(**c['parameters'],n_estimators=300,learning_rate=.05,min_child_weight=3,
                         subsample=.8,colsample_bytree=.8,eval_metric='mlogloss',random_state=random_state,n_jobs=1)


def transform(z,kind):
    if kind=='raw':return z
    assert z.shape[1]==10
    return np.column_stack([z,*[z[:,i]-z[:,j] for i,j in PAIR]])


def fit_predict(p,c,train,test,random_state,sensors=tuple(range(1,11)),model_path=None):
    X,y,*_=load(p); cols=np.array(sensors)-1
    scaler=StandardScaler().fit(X[train][:,cols])
    tx=transform(scaler.transform(X[train][:,cols]),c['features'])
    vx=transform(scaler.transform(X[test][:,cols]),c['features'])
    assert np.isfinite(tx).all() and np.isfinite(vx).all()
    assert np.allclose(scaler.mean_,X[train][:,cols].mean(axis=0))
    model=setup_model(c,random_state)
    weights=compute_sample_weight('balanced',y[train]) if c['balanced_sample_weight'] else None
    began=time.monotonic()
    with threadpool_limits(limits=1):
        if weights is None:model.fit(tx,y[train])
        else:model.fit(tx,y[train],sample_weight=weights)
        probability=model.predict_proba(vx)
        pred=model.classes_[probability.argmax(axis=1)].astype(np.int8)
    assert np.array_equal(model.classes_,np.arange(8))
    if model_path is not None:
        joblib.dump(dict(scaler=scaler,classifier=model,features=c['features'],sensors=sensors),model_path,compress=3)
    metadata=dict(seed=random_state,sensors=sensors,feature_dimension=tx.shape[1],scaler_mean=scaler.mean_,
                  scaler_scale=scaler.scale_,training_class_support=np.bincount(y[train],minlength=8),
                  model_parameters=model.get_params(),fit_predict_seconds=time.monotonic()-began)
    return pred,probability,metadata


def split_check(p,train,test,grouped=False):
    _,y,_,_,_,fold,groups=load(p)
    assert len(train)==len(np.unique(train)) and len(test)==len(np.unique(test))
    assert not np.intersect1d(train,test).size
    assert set(y[train])==set(y[test])==set(range(8))
    if grouped:
        assert set(groups[train]).isdisjoint(groups[test])
        assert set(fold[train]).isdisjoint(fold[test])


def key_for(design,p,outer):return f'{design}_P{p:02d}_fold{outer}'


def prepare(design,p,outer):
    _,y,source,_,frame,fold,_=load(p)
    if design=='random_rows':
        archive=REF/'results/predictions'/f'P{p:02d}_test20_S2-S3-S10.npz'
        with np.load(archive,allow_pickle=False) as a:train=a['source_train_row'];test=a['source_test_row']
        cv=StratifiedKFold(n_splits=3,shuffle=True,random_state=seed(design,p,'inner'))
        inner=[(i+1,train[it],train[iv]) for i,(it,iv) in enumerate(cv.split(train,y[train]))]
    else:
        train=np.flatnonzero(fold!=outer);test=np.flatnonzero(fold==outer)
        inner=[(int(r),train[fold[train]!=r],train[fold[train]==r]) for r in sorted(set(fold[train]))]
    split_check(p,train,test,design=='grouped_repetitions')
    assert np.array_equal(np.sort(np.r_[train,test]),source)
    seen=[]
    for _,it,iv in inner:
        split_check(p,it,iv,design=='grouped_repetitions')
        assert np.array_equal(np.sort(np.r_[it,iv]),np.sort(train))
        seen.extend(iv)
    assert np.array_equal(np.sort(seen),np.sort(train))
    key=key_for(design,p,outer)
    arrays={'outer_train':train,'outer_test':test}
    for i,it,iv in inner:arrays[f'inner{i}_train']=it;arrays[f'inner{i}_valid']=iv
    np.savez_compressed(OUT/'splits'/f'{key}.npz',**arrays)
    metadata=dict(key=key,design=design,participant=f'P{p:02d}',outer_fold=outer,inner_ids=[a[0] for a in inner],
                  n_train=len(train),n_test=len(test),train_hash=ref.arrhash(train),test_hash=ref.arrhash(test),
                  initial_baseline_test_rows=int(frame.iloc[test].phase.eq('initial_baseline').sum()))
    save(OUT/'splits'/f'{key}.json',metadata)
    return key,train,test,inner


def inner_task(args):
    design,p,outer,c=args
    key=key_for(design,p,outer); _,y,*_=load(p)
    meta=json.loads((OUT/'splits'/f'{key}.json').read_text())
    records=[];arrays={}
    with np.load(OUT/'splits'/f'{key}.npz') as split:
        for i in meta['inner_ids']:
            it,iv=split[f'inner{i}_train'],split[f'inner{i}_valid']
            pred,_,modelmeta=fit_predict(p,c,it,iv,seed(design,p,outer,c['id'],'inner',i))
            records.append(dict(inner_fold=i,**ref.metrics(y[iv],pred),**modelmeta))
            arrays[f'inner{i}_valid']=iv;arrays[f'inner{i}_truth']=y[iv];arrays[f'inner{i}_pred']=pred
    result=dict(key=key,candidate=c,folds=records,
                **{f'mean_{m}':float(np.mean([r[m] for r in records])) for m in ('accuracy','balanced_accuracy','macro_f1')})
    np.savez_compressed(OUT/'inner'/f'{key}_c{c["id"]:02d}.npz',**arrays)
    save(OUT/'inner'/f'{key}_c{c["id"]:02d}.json',result)
    return result


def ranking(result):
    return (-result['mean_macro_f1'],-result['mean_accuracy'],-result['mean_balanced_accuracy'],result['candidate']['id'])


def outer_seed(design,p,outer,cid):
    if design=='random_rows' and cid==0:return ref.seed_for(p,.2,TRIPLET,'RandomForest')
    return seed(design,p,outer,cid,'outer')


def fit_outer(design,p,outer,key,train,test,winner):
    _,y,_,_,frame,*_=load(p)
    for procedure in PROCEDURES:
        c=winner['candidate'] if procedure=='all10_tuned' else CANDIDATES[0]
        sensors=TRIPLET if procedure=='triplet_default' else tuple(range(1,11))
        pred,prob,modelmeta=fit_predict(p,c,train,test,outer_seed(design,p,outer,c['id']),sensors,
                                      OUT/'models'/f'{key}_{procedure}.joblib')
        if design=='random_rows' and procedure=='triplet_default':
            with np.load(REF/'results/predictions'/f'P{p:02d}_test20_S2-S3-S10.npz') as old:
                assert np.array_equal(test,old['source_test_row'])
                assert np.array_equal(pred,old['predictions'][list(old['classifier']).index('RandomForest')])
        hold=frame.iloc[test].phase.eq('hold').to_numpy()
        rec=dict(key=key,design=design,participant=f'P{p:02d}',outer_fold=outer,procedure=procedure,candidate=c,
                 metrics_all=ref.metrics(y[test],pred),metrics_hold=ref.metrics(y[test][hold],pred[hold]),
                 **modelmeta)
        np.savez_compressed(OUT/'outer'/f'{key}_{procedure}.npz',test_rows=test,truth=y[test],predictions=pred,
                            probabilities=prob,hold=hold)
        save(OUT/'outer'/f'{key}_{procedure}.json',rec)


def self_test():
    assert len(CANDIDATES)==13 and len(PAIR)==45
    z=np.arange(30,dtype=float).reshape(3,10)
    spatial=transform(z,'spatial')
    assert spatial.shape==(3,55) and np.array_equal(spatial[:,:10],z)
    for k,(i,j) in enumerate(PAIR):assert np.array_equal(spatial[:,10+k],z[:,i]-z[:,j])
    altered=z.copy();altered[1:]+=100
    assert np.array_equal(transform(altered,'spatial')[0],spatial[0])
    for p in (1,2,3):
        X,y,_,audit,_,fold,_=load(p)
        assert audit['source_rows']==audit['eligible_rows'] and X.shape==(len(y),10)
        for r in range(1,6):split_check(p,np.flatnonzero(fold!=r),np.flatnonzero(fold==r),True)
    print('Pre-fit tests passed: feature arithmetic, row independence, source hashes, class coverage and nominal-group separation.',flush=True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=6);ap.add_argument('--check-only',action='store_true')
    args=ap.parse_args();self_test()
    if args.check_only:return
    if (OUT/'manifest.json').exists():raise RuntimeError('Existing run: inspect rather than overwrite')
    for sub in ('splits','inner','outer','models'):(OUT/sub).mkdir(parents=True,exist_ok=True)
    manifest=dict(completed=False,plan_sha256=ref.sha(HERE/'PLAN.md'),script_sha256=ref.sha(__file__),
                  reference_script_sha256=ref.sha(REF/'benchmark.py'),candidates=CANDIDATES,workers=args.workers,
                  versions=dict(python=sys.version,numpy=np.__version__,pandas=pd.__version__,sklearn=sklearn.__version__,
                                xgboost=xgboost.__version__,joblib=joblib.__version__),inputs=[load(p)[3] for p in (1,2,3)])
    save(OUT/'manifest.json',manifest)
    designs=[('random_rows',p,0) for p in (1,2,3)]+[('grouped_repetitions',p,r) for p in (1,2,3) for r in range(1,6)]
    began=time.monotonic();selections=[];fits=0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for number,(design,p,outer) in enumerate(designs,1):
            key,train,test,inner=prepare(design,p,outer)
            futures=[pool.submit(inner_task,(design,p,outer,c)) for c in CANDIDATES]
            results=[f.result() for f in as_completed(futures)]
            winner=sorted(results,key=ranking)[0]
            selections.append(dict(key=key,design=design,participant=f'P{p:02d}',outer_fold=outer,
                                   candidate=winner['candidate'],inner_macro_f1=winner['mean_macro_f1'],
                                   inner_accuracy=winner['mean_accuracy'],inner_balanced_accuracy=winner['mean_balanced_accuracy']))
            save(OUT/'selections.json',selections)
            fit_outer(design,p,outer,key,train,test,winner)
            fits+=len(CANDIDATES)*len(inner)+len(PROCEDURES)
            print(json.dumps(dict(event='outer_complete',completed=number,total=len(designs),key=key,
                                  completed_fits=fits,elapsed_seconds=time.monotonic()-began)),flush=True)
    assert all(ref.sha(ref.DATA/name)==h for name,h in ref.EXPECTED.items())
    manifest.update(completed=True,outer_evaluations=len(designs),inner_model_fits=fits-54,outer_model_fits=54,
                    total_model_fits=fits,source_hashes_unchanged=True,elapsed_seconds=time.monotonic()-began)
    save(OUT/'manifest.json',manifest)
    print(json.dumps(dict(event='complete',fits=fits,elapsed_seconds=manifest['elapsed_seconds'])),flush=True)


if __name__=='__main__':main()
