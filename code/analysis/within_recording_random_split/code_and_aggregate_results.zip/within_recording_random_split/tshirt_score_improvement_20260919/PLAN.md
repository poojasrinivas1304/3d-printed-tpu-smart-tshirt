# Ten-sensor improvement experiment

Fixed before fitting this round. Keep the manuscript, GitHub, original CSVs, existing scripts and earlier result packages unchanged.

## Question

Can use of the full sensor array and a small training-only search improve the reference-style three-sensor scores? Also assess the same candidate procedure with nominal repetitions held out.

## Data and features

- Use the same 50,701 rows from subject_01/02/03.csv in the previous benchmark. Verify their recorded SHA-256 hashes. Keep all eight labels and all phases, including initial baseline and transitions. No additional peak masks, exclusions, relabeling or synthetic data.
- Predict each row from its ten raw ADC values. No time, participant ID, target, phase, set ID or repetition ID is a predictor. No temporal windows or smoothing, so features cannot share measurements across partitions.
- StandardScaler is fitted on the training rows only. The optional spatial representation appends all 45 pairwise differences between the ten standardized readings at that same instant (55 predictors total). This changes relative-channel weighting without using labels, protocol boundaries or other rows.
- Thirteen fixed candidates: RF100 default; RF300 using all features; RF300 with 0.7 feature fraction, leaf size 2 and balanced_subsample weighting; ExtraTrees300 raw with all features and leaf size 1, or leaf size 2 with balanced weighting; ExtraTrees300 spatial with feature fraction 0.7 and leaf size 1, or leaf size 2 and balanced weighting; XGBoost300 raw with depth 3/lambda 10 or depth 6/lambda 5; XGBoost300 spatial with depth 3/lambda 10 and training-derived balanced weights; distance-weighted KNN with k=5 or 15 on raw standardized readings, or k=5 on spatial readings. XGBoost learning rate 0.05, minimum child weight 3, subsample and column fraction 0.8. No early stopping using outer data.

## Two separately reported evaluation designs

1. **Reused random-row comparison:** exactly the saved 80/20 partitions for the previous common S2-S3-S10 result, independently for each participant. These are already inspected development splits, not new test data. Select the candidate by three-fold stratified inner validation using only the outer-training rows. Report the replayed RF100 triplet, RF100 full array, and inner-selected full array on identical outer-test rows. All four earlier metrics must reproduce for the triplet.
2. **Grouped check:** five outer folds separately for each participant, holding out nominal repetition numbers 1 through 5 across all target sets. Initial-baseline rows (stored rep 0) are attached to fold 1, rather than dropped or shared. Four inner leave-one-nominal-repetition-out folds operate only in the outer training set. Report RF100 triplet, RF100 full array and inner-selected full array on identical outer rows. Every stored (set_id, rep) group stays together. Stored returns can belong to the next repetition, so this is a nominal-repetition check, not proof of independent complete physical cycles or sessions.

Selection objective: mean inner macro-F1, then accuracy, then balanced accuracy, then fixed candidate order. Rank only after all inner predictions are saved. Fit the selected candidate once to all outer-training rows. Do not select a procedure based on its outer results. The three procedures are fixed comparisons, not alternative final winners selected after testing.

Separate models for P01, P02 and P03. Deterministic recorded seeds, identical outer partitions across procedures, and single-threaded model fits with bounded parallel jobs. No expansion of the search after viewing these outer scores.

## Outputs and verification

Save all inner predictions/scores/split rows, outer predictions/probabilities/confusion matrices, selected settings, source hashes, package versions, scaler parameters and fitted outer models. Report participant means and pooled scores separately, all phases as the matched primary analysis and held-only scores as a labeled secondary analysis. Metrics: accuracy, macro precision, macro recall/balanced accuracy, macro-F1 and class support/recall. No abstentions.

Independently verify exact prior-triplet replay, all input hashes, every planned fit/split, class coverage, training-only scaler statistics, group separation where required, selections from inner metrics only, and all saved metrics against predictions. These repeatedly inspected recordings remain exploratory development data. A high random-row score is not interchangeable with repetition-held-out or independent-session performance. The previous manuscript's 2,032-window analysis is a different unit of analysis and is unchanged.

Method references: https://scikit-learn.org/stable/modules/cross_validation.html and https://scikit-learn.org/stable/modules/ensemble.html
