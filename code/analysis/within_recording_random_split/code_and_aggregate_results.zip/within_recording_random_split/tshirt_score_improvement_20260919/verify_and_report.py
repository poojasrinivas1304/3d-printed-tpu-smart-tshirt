"""Independent prediction/scaler/split checks and descriptive reporting."""
import benchmark as b
import json
from collections import Counter
import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

M=('accuracy','balanced_accuracy','macro_precision','macro_recall','macro_f1')
LABELS=('Standing straight','Left arm raise','Right arm raise','Left shoulder touch and twist',
        'Right shoulder touch and twist','Both arms raise','Forward bend','Sitting')
TITLES={'triplet_default':'RF100 triplet S2-S3-S10','all10_default':'RF100 all ten sensors','all10_tuned':'Training-only selected all-ten model'}


def recount(true,pred):
    assert np.isin(true,np.arange(8)).all() and np.isin(pred,np.arange(8)).all()
    cm=np.zeros((8,8),dtype=np.int64);np.add.at(cm,(true,pred),1)
    support=cm.sum(axis=1);assert (support>0).all()
    recall=cm.diagonal()/support
    precision=np.divide(cm.diagonal(),cm.sum(axis=0),out=np.zeros(8),where=cm.sum(axis=0)>0)
    f1=np.divide(2*precision*recall,precision+recall,out=np.zeros(8),where=(precision+recall)>0)
    metrics=dict(accuracy=cm.trace()/cm.sum(),balanced_accuracy=recall.mean(),macro_precision=precision.mean(),
                 macro_recall=recall.mean(),macro_f1=f1.mean(),n_test=int(cm.sum()),n_correct=int(cm.trace()))
    return metrics,cm,precision,recall,f1,support


def check_score(stored,true,pred):
    met,cm,precision,recall,f1,support=recount(true,pred)
    assert all(np.isclose(stored[k],met[k],atol=1e-12,rtol=0) for k in M)
    assert stored['n_test']==met['n_test'] and stored['n_correct']==met['n_correct']
    assert np.array_equal(stored['confusion_counts'],cm)
    assert np.array_equal(stored['class_support'],support)
    assert np.allclose(stored['class_recall'],recall,atol=1e-12,rtol=0)
    return met


def check_scaler(meta,X,train):
    x=X[train][:,np.array(meta['sensors'])-1]
    assert np.allclose(x.mean(axis=0),meta['scaler_mean'],atol=1e-10,rtol=1e-12)
    scale=x.std(axis=0,ddof=0);scale[scale==0]=1
    assert np.allclose(scale,meta['scaler_scale'],atol=1e-10,rtol=1e-12)


def verify():
    manifest=json.loads((b.OUT/'manifest.json').read_text());assert manifest['completed']
    assert manifest['plan_sha256']==b.ref.sha(b.HERE/'PLAN.md')
    assert manifest['script_sha256']==b.ref.sha(b.HERE/'benchmark.py')
    assert manifest['reference_script_sha256']==b.ref.sha(b.REF/'benchmark.py')
    assert manifest['candidates']==b.CANDIDATES
    expected=[('random_rows',p,0) for p in (1,2,3)]+[('grouped_repetitions',p,r) for p in (1,2,3) for r in range(1,6)]
    assert {x.stem for x in (b.OUT/'splits').glob('*.json')}=={b.key_for(*a) for a in expected}
    assert len(list((b.OUT/'inner').glob('*.json')))==234
    assert len(list((b.OUT/'outer').glob('*.json')))==54
    selections=json.loads((b.OUT/'selections.json').read_text())
    assert len(selections)==18 and len({x['key'] for x in selections})==18
    selection_map={x['key']:x for x in selections}
    inner_scores=[];outer_rows=[];split_diagnostics=[];inner_count=0;outer_count=0
    for design,p,outer in expected:
        key=b.key_for(design,p,outer);X,y,source,_,frame,fold,groups=b.load(p)
        sm=json.loads((b.OUT/'splits'/f'{key}.json').read_text())
        with np.load(b.OUT/'splits'/f'{key}.npz',allow_pickle=False) as sp:
            train,test=sp['outer_train'],sp['outer_test']
            b.split_check(p,train,test,design=='grouped_repetitions')
            assert b.ref.arrhash(train)==sm['train_hash'] and b.ref.arrhash(test)==sm['test_hash']
            assert np.array_equal(np.sort(np.r_[train,test]),source)
            in_train=np.zeros(len(y),dtype=bool);in_train[train]=True
            adjacent=((test>0)&in_train[np.maximum(test-1,0)])|((test<len(y)-1)&in_train[np.minimum(test+1,len(y)-1)])
            shared=len(set(groups[train])&set(groups[test]))
            if design=='grouped_repetitions':assert shared==0
            split_diagnostics.append(dict(design=design,participant=f'P{p:02d}',outer_fold=outer,
                                          shared_nominal_groups=shared,test_rows=len(test),
                                          test_fraction_adjacent_to_training=float(adjacent.mean())))
            if design=='random_rows':
                with np.load(b.REF/'results/predictions'/f'P{p:02d}_test20_S2-S3-S10.npz') as old:
                    assert np.array_equal(train,old['source_train_row']) and np.array_equal(test,old['source_test_row'])
            else:assert (fold[test]==outer).all() and (fold[train]!=outer).all()
            every_inner=[]
            for i in sm['inner_ids']:
                it,iv=sp[f'inner{i}_train'],sp[f'inner{i}_valid']
                b.split_check(p,it,iv,design=='grouped_repetitions')
                assert np.array_equal(np.sort(np.r_[it,iv]),np.sort(train))
                assert not np.intersect1d(test,np.r_[it,iv]).size
                every_inner.extend(iv)
            assert np.array_equal(np.sort(every_inner),np.sort(train))
            ranked=[]
            for c in b.CANDIDATES:
                rec=json.loads((b.OUT/'inner'/f'{key}_c{c["id"]:02d}.json').read_text())
                assert rec['candidate']==c
                checked=[]
                with np.load(b.OUT/'inner'/f'{key}_c{c["id"]:02d}.npz') as a:
                    assert len(rec['folds'])==len(sm['inner_ids'])
                    for fr in rec['folds']:
                        i=fr['inner_fold'];it=sp[f'inner{i}_train'];iv=sp[f'inner{i}_valid']
                        assert np.array_equal(a[f'inner{i}_valid'],iv) and np.array_equal(a[f'inner{i}_truth'],y[iv])
                        m=check_score(fr,y[iv],a[f'inner{i}_pred']);check_scaler(fr,X,it)
                        assert np.array_equal(fr['training_class_support'],np.bincount(y[it],minlength=8))
                        assert fr['seed']==b.seed(design,p,outer,c['id'],'inner',i)
                        checked.append(m);inner_count+=1
                        inner_scores.append(dict(key=key,design=design,participant=f'P{p:02d}',outer_fold=outer,
                                                 inner_fold=i,candidate_id=c['id'],candidate=c['name'],**m))
                means={f'mean_{name}':float(np.mean([r[name] for r in checked])) for name in ('accuracy','balanced_accuracy','macro_f1')}
                assert all(np.isclose(rec[k],v,atol=1e-12,rtol=0) for k,v in means.items())
                ranked.append(dict(candidate=c,**means))
            winner=sorted(ranked,key=b.ranking)[0]
            assert selection_map[key]['candidate']==winner['candidate']
            for name in ('macro_f1','accuracy','balanced_accuracy'):
                assert np.isclose(selection_map[key][f'inner_{name}'],winner[f'mean_{name}'],atol=1e-12,rtol=0)
            for procedure in b.PROCEDURES:
                rec=json.loads((b.OUT/'outer'/f'{key}_{procedure}.json').read_text())
                c=winner['candidate'] if procedure=='all10_tuned' else b.CANDIDATES[0]
                assert rec['candidate']==c
                assert rec['seed']==b.outer_seed(design,p,outer,c['id'])
                assert rec['sensors']==([2,3,10] if procedure=='triplet_default' else list(range(1,11)))
                check_scaler(rec,X,train)
                with np.load(b.OUT/'outer'/f'{key}_{procedure}.npz') as a:
                    assert np.array_equal(a['test_rows'],test) and np.array_equal(a['truth'],y[test])
                    pred=a['predictions'];prob=a['probabilities'];hold=frame.iloc[test].phase.eq('hold').to_numpy()
                    assert np.array_equal(a['hold'],hold) and prob.shape==(len(test),8)
                    assert np.allclose(prob.sum(axis=1),1,atol=1e-6,rtol=0)
                    assert np.array_equal(prob.argmax(axis=1),pred)
                    check_score(rec['metrics_all'],y[test],pred);check_score(rec['metrics_hold'],y[test][hold],pred[hold])
                    # Replay every outer prediction from the persisted fitted model and source rows.
                    obj=joblib.load(b.OUT/'models'/f'{key}_{procedure}.joblib')
                    z=obj['scaler'].transform(X[test][:,np.array(obj['sensors'])-1])
                    features=b.transform(z,obj['features'])
                    with threadpool_limits(limits=1):replay=obj['classifier'].predict_proba(features)
                    assert np.allclose(replay,prob,atol=1e-12,rtol=0) and np.array_equal(replay.argmax(axis=1),pred)
                    if design=='random_rows' and procedure=='triplet_default':
                        oldrec=json.loads((b.REF/'results/tasks'/f'P{p:02d}_test20_S2-S3-S10.json').read_text())
                        oldmetric=next(m for m in oldrec['models'] if m['classifier']=='RandomForest')
                        check_score(oldmetric,y[test],pred)
                        with np.load(b.REF/'results/predictions'/f'P{p:02d}_test20_S2-S3-S10.npz') as old:
                            assert np.array_equal(pred,old['predictions'][list(old['classifier']).index('RandomForest')])
                    for k,idx in enumerate(test):
                        outer_rows.append(dict(design=design,participant=f'P{p:02d}',outer_fold=outer,procedure=procedure,
                                               source_row=int(idx),truth=int(y[idx]),prediction=int(pred[k]),hold=bool(hold[k]),
                                               candidate=c['name']))
                outer_count+=1
        print(f'Verified {key}',flush=True)
    assert inner_count==897 and outer_count==54 and manifest['total_model_fits']==951
    assert all(b.ref.sha(b.ref.DATA/name)==h for name,h in b.ref.EXPECTED.items())
    rows=pd.DataFrame(outer_rows)
    for (design,p,proc),f in rows.groupby(['design','participant','procedure']):
        assert not f.source_row.duplicated().any()
        if design=='grouped_repetitions':assert np.array_equal(np.sort(f.source_row),b.load(int(p[1:]))[2])
        others=rows[(rows.design==design)&(rows.participant==p)]
        for _,g in others.groupby('procedure'):assert np.array_equal(np.sort(f.source_row),np.sort(g.source_row))
    rows.to_csv(b.OUT/'outer_predictions.csv',index=False)
    pd.DataFrame(inner_scores).to_csv(b.OUT/'inner_scores.csv',index=False)
    diagnostics=pd.DataFrame(split_diagnostics);diagnostics.to_csv(b.OUT/'split_diagnostics.csv',index=False)
    verification=dict(inner_fits_verified=inner_count,outer_fits_verified=outer_count,all_planned_splits_present=True,
                      all_metrics_recomputed=True,all_outer_models_replayed=True,prior_triplet_reproduced_exactly=True,
                      identical_test_rows_across_procedures=True,train_only_scalers_verified=True,
                      grouped_partitions_disjoint=True,all_classes_retained=True,selection_uses_inner_scores_only=True,
                      source_hashes_unchanged=True,
                      random_row_mean_adjacent_training_fraction=float(diagnostics.loc[diagnostics.design.eq('random_rows'),'test_fraction_adjacent_to_training'].mean()))
    b.save(b.OUT/'verification.json',verification)
    return rows,selections,verification


def report(rows,selections,checks):
    metric_rows=[];class_rows=[];confusions={}
    for (design,procedure),f in rows.groupby(['design','procedure']):
        for person,g in [('Pooled',f),*list(f.groupby('participant'))]:
            for period,q in [('all_rows',g),('held_only',g[g.hold])]:
                m,cm,precision,recall,f1,support=recount(q.truth.to_numpy(),q.prediction.to_numpy())
                metric_rows.append(dict(design=design,procedure=procedure,participant=person,period=period,**m))
                confusions[f'{design}|{procedure}|{person}|{period}']=cm.tolist()
                for i in range(8):class_rows.append(dict(design=design,procedure=procedure,participant=person,period=period,
                                                       position=i+1,posture=LABELS[i],support=int(support[i]),precision=precision[i],recall=recall[i],f1=f1[i]))
    metrics=pd.DataFrame(metric_rows);metrics.to_csv(b.OUT/'metrics.csv',index=False)
    pd.DataFrame(class_rows).to_csv(b.OUT/'per_class_metrics.csv',index=False);b.save(b.OUT/'confusion_matrices.json',confusions)
    mean=metrics[metrics.participant.ne('Pooled')].groupby(['design','procedure','period'],as_index=False)[list(M)].mean()
    mean.to_csv(b.OUT/'participant_mean_metrics.csv',index=False)
    selected=pd.DataFrame([dict(design=s['design'],participant=s['participant'],outer_fold=s['outer_fold'],
                                candidate_id=s['candidate']['id'],candidate=s['candidate']['name'],features=s['candidate']['features'],
                                inner_macro_f1=s['inner_macro_f1']) for s in selections])
    selected.to_csv(b.OUT/'selected_settings.csv',index=False)
    headline={d:{p:mean[(mean.design==d)&(mean.procedure==p)&(mean.period=='all_rows')].iloc[0].to_dict()
                 for p in b.PROCEDURES} for d in ('random_rows','grouped_repetitions')}
    b.save(b.OUT/'headline.json',headline)
    line=['# Ten-sensor improvement experiment','','The manuscript, GitHub, original CSVs and prior analysis packages were not changed.','',
          '## Main result','','Metrics below are arithmetic means of three participant-specific scores. For grouped validation, each participant score pools their five outer folds before the three participants are averaged. All rows and all eight labels are retained.','']
    random_tuned=headline['random_rows']['all10_tuned'];grouped_tuned=headline['grouped_repetitions']['all10_tuned']
    line += [f"The inner-selected ten-sensor procedure reached {random_tuned['accuracy']*100:.2f}% accuracy in reused random splits, compared with {grouped_tuned['accuracy']*100:.2f}% in the nominal-repetition-held-out check. These evaluate different questions and must not be presented interchangeably. The random-split result does not establish equivalent performance on unseen repetitions or sessions.",'']
    for design,title in [('random_rows','Reused random-row comparison'),('grouped_repetitions','Nominal-repetition-held-out check')]:
        line += [f'### {title}','','| Procedure | Accuracy | Balanced accuracy / macro recall | Macro precision | Macro-F1 |',
                 '|---|---:|---:|---:|---:|']
        for p in b.PROCEDURES:
            r=headline[design][p]
            line.append(f"| {TITLES[p]} | {r['accuracy']*100:.2f}% | {r['balanced_accuracy']*100:.2f}% | {r['macro_precision']*100:.2f}% | {r['macro_f1']*100:.2f}% |")
        base=headline[design]['triplet_default'];full=headline[design]['all10_default'];tuned=headline[design]['all10_tuned']
        line += ['',f"Adding sensors with RF100 changed accuracy by {(full['accuracy']-base['accuracy'])*100:+.2f} percentage points. Inner model selection changed accuracy by {(tuned['accuracy']-full['accuracy'])*100:+.2f} points relative to RF100 with all ten sensors, and macro-F1 by {(tuned['macro_f1']-full['macro_f1'])*100:+.2f} points.",'']
    line += ['The random-row partitions are exactly the earlier 80/20 S2-S3-S10 partitions. They share repetitions between training and testing and have already been inspected. The grouped check holds out nominal repetition numbers across all target sets, with every stored (set_id, rep) group kept together. The initial baseline belongs to fold 1. Stored returns can be assigned to the next repetition; these are not independently verified complete physical cycles. Neither design constitutes a new recording, new participant or external validation.','',
             '## Participant results for the inner-selected procedure','','| Design | Participant | Accuracy | Balanced accuracy | Macro precision | Macro-F1 | Test rows |','|---|---|---:|---:|---:|---:|---:|']
    detail=metrics[(metrics.procedure=='all10_tuned')&(metrics.period=='all_rows')&metrics.participant.ne('Pooled')]
    for r in detail.itertuples():line.append(f'| {r.design} | {r.participant} | {r.accuracy*100:.2f}% | {r.balanced_accuracy*100:.2f}% | {r.macro_precision*100:.2f}% | {r.macro_f1*100:.2f}% | {r.n_test} |')
    line += ['','## Training-only choices','','| Design | Participant | Outer fold | Selected candidate | Inner macro-F1 |','|---|---|---:|---|---:|']
    for r in selected.itertuples():line.append(f'| {r.design} | {r.participant} | {r.outer_fold} | {r.candidate} | {r.inner_macro_f1*100:.2f}% |')
    line += ['','## Processing and interpretation','',
             '- Use all ten raw ADC channels; fit StandardScaler separately inside every training split. No labels, time, phase or protocol IDs enter the predictors.',
             '- Optional spatial features append 45 pairwise differences between standardized sensor values at the same instant. There are no temporal windows, smoothing or shared feature measurements across partitions.',
             '- Select among 13 predefined candidates by mean inner macro-F1, then accuracy, balanced accuracy and candidate order. Random-row tests use three inner stratified folds; grouped tests use four inner nominal-repetition folds. Outer scores are not used for these choices.',
             '- No new peak exclusions, sample removals, relabeling, synthetic examples, abstentions or test-derived decision thresholds. Balanced weights, where configured, use training labels only.',
             '- Primary scores measure agreement with the recorded labels over all phases, matching the reference-style scope. Transition labels identify prompted destinations, not verified instantaneous physical posture. Held-only results are saved separately as secondary metrics.',
             '- The previously saved 2,032-window analysis used a different unit/feature/eligibility design and produced 68.31% accuracy and 73.37% balanced accuracy. Those outputs are unchanged and are not directly interchangeable with these per-row scores.',
             '- This search follows extensive development on the same recordings. Even nested selection cannot convert this round into an untouched prospective test. A high random-row score should not be substituted for a grouped or new-session score.',
             '- The S2-S3-S10 comparator is fixed from the previous exploratory ranking. It is not a newly nested sensor-subset selection in this experiment. The all-ten tuning procedure uses inner-fold scores only for this round.',
             f"- In the reused random splits, an average of {checks['random_row_mean_adjacent_training_fraction']*100:.2f}% of test rows have an immediately adjacent training row. This quantifies the close temporal proximity of these tests; it does not establish how much of the score difference is caused by that proximity.",
             '',
             '## Verification and files','',
             f"Verified all {checks['inner_fits_verified']} inner fits and {checks['outer_fits_verified']} outer fits. Independently recomputed metrics, replayed every persisted outer model, checked every scaler against its training rows, verified grouped separation and identical evaluation rows, and reproduced the previous triplet predictions exactly. Input and fitting-script hashes are unchanged.",
             'The scientific-research spreadsheet workflow kept source observations separate from derived analysis and required independent numerical checks.',
             'Detailed outputs: results/metrics.csv (participant and pooled scores), results/participant_mean_metrics.csv, results/per_class_metrics.csv, results/outer_predictions.csv, results/inner_scores.csv, results/selected_settings.csv, results/split_diagnostics.csv, results/confusion_matrices.json and results/verification.json. CSV metrics are proportions (0 to 1); this report displays percentages. Fitted models, splits, probabilities and package versions are retained under results/.','',
             '## Reproduction','',
             'Use the same isolated environment as the reference-method experiment and run from this experiment folder. The benchmark refuses to overwrite an existing run. No new dependencies were installed for this round.','',
             '```sh',
             'DYLD_LIBRARY_PATH=/Library/Frameworks/Python.framework/Versions/3.14/lib/python3.14/site-packages/sklearn/.dylibs ../tshirt_reference_method_20260919/.venv/bin/python benchmark.py --workers 6',
             'DYLD_LIBRARY_PATH=/Library/Frameworks/Python.framework/Versions/3.14/lib/python3.14/site-packages/sklearn/.dylibs ../tshirt_reference_method_20260919/.venv/bin/python verify_and_report.py',
             '```','',
             'Method references: [cross-validation and training-only preprocessing](https://scikit-learn.org/stable/modules/cross_validation.html), [tree ensembles](https://scikit-learn.org/stable/modules/ensemble.html).']
    (b.HERE/'RESULTS.md').write_text('\n'.join(line)+'\n')
    print(json.dumps(b.clean(dict(headline=headline,checks=checks)),indent=2))


if __name__=='__main__':report(*verify())
