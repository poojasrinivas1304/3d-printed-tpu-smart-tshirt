"""Regenerate manuscript figures from immutable saved outer predictions.

No fitting, filtering, relabelling, or modification of source data is performed.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

ROOT = Path(__file__).resolve().parent
SRC = ROOT.parent / 'tshirt_temporal_test_20260918' / 'results'
PRIMARY = 'Training-only temporal-or-level selection'
predictions = json.loads((SRC / 'outer_predictions.json').read_text())
reported = json.loads((SRC / 'metrics.json').read_text())

def calculate(rows):
    cm = np.zeros((8, 8), dtype=int)
    for r in rows:
        cm[r['position_index'] - 1, r['predicted_position'] - 1] += 1
    support = cm.sum(axis=1)
    tp = np.diag(cm)
    precision = np.divide(tp, cm.sum(axis=0), out=np.zeros(8), where=cm.sum(axis=0)>0)
    recall = np.divide(tp, support, out=np.zeros(8), where=support>0)
    f1 = np.divide(2*tp, support+cm.sum(axis=0), out=np.zeros(8), where=support+cm.sum(axis=0)>0)
    return dict(support=int(cm.sum()), accuracy=float(tp.sum()/cm.sum()),
                macro_precision=float(precision.mean()), macro_recall=float(recall.mean()),
                macro_f1=float(f1.mean()), class_support=support.tolist(),
                class_precision=precision.tolist(), class_recall=recall.tolist(),
                class_f1=f1.tolist(), confusion_counts=cm.tolist())

verified = []
for stored in reported:
    rows = [r for r in predictions if r['procedure']==stored['procedure']
            and r['period']==stored['period']
            and (stored['participant']=='All' or r['participant']==stored['participant'])]
    result = calculate(rows)
    for key, value in result.items():
        assert np.allclose(value, stored[key], atol=1e-12, rtol=0), (stored['procedure'], key)
    verified.append(dict(procedure=stored['procedure'], period=stored['period'],
                         participant=stored['participant'], **result))

held = {r['participant']: r for r in verified if r['procedure']==PRIMARY and r['period']=='Held posture'}
assert held['All']['support']==2032
assert sum(np.diag(held['All']['confusion_counts']))==1388
assert len([r for r in predictions if r['procedure']==PRIMARY and r['period']=='Held posture'])==2032
unique = {(r['participant'], r['window_id']) for r in predictions if r['procedure']==PRIMARY and r['period']=='Held posture'}
assert len(unique)==2032
for procedure in {r['procedure'] for r in predictions}:
    ids={(r['participant'], r['window_id'], r['position_index']) for r in predictions if r['procedure']==procedure and r['period']=='Held posture'}
    primary_ids={(r['participant'], r['window_id'], r['position_index']) for r in predictions if r['procedure']==PRIMARY and r['period']=='Held posture'}
    assert ids==primary_ids
(ROOT/'verified_metrics.json').write_text(json.dumps(verified, indent=2)+'\n')

plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':10, 'axes.labelsize':11,
                     'axes.titlesize':12, 'axes.spines.top':False, 'axes.spines.right':False,
                     'savefig.facecolor':'white'})
palette = LinearSegmentedColormap.from_list('response', ['#f7fbfc','#b9dfe8','#5ba2b7','#235772','#112f45'])
labels = ['1  Standing','2  Left arm raise','3  Right arm raise','4  Left touch + twist',
          '5  Right touch + twist','6  Both arms raise','7  Forward bend','8  Sitting']
cm=np.asarray(held['All']['confusion_counts'])
row_pct=100*cm/cm.sum(axis=1, keepdims=True)
fig, ax=plt.subplots(figsize=(9,7.3), layout='constrained')
im=ax.imshow(row_pct, cmap=palette, vmin=0, vmax=100)
ax.set_xticks(range(8), labels, rotation=43, ha='right', rotation_mode='anchor')
ax.set_yticks(range(8), labels)
ax.set_xlabel('Predicted posture')
ax.set_ylabel('Prompted held posture')
ax.set_xticks(np.arange(-.5,8,1),minor=True); ax.set_yticks(np.arange(-.5,8,1),minor=True)
ax.grid(which='minor',color='white',linewidth=1.2); ax.tick_params(which='both',length=0)
for i in range(8):
    for j in range(8):
        value='0' if cm[i,j]==0 else f'{row_pct[i,j]:.1f}%\n({cm[i,j]})'
        ax.text(j,i,value,ha='center',va='center',fontsize=9,color='white' if row_pct[i,j]>55 else '#153244')
fig.colorbar(im,ax=ax,shrink=.8,pad=.035,label='Row-normalized windows (%)')
fig.savefig(ROOT/'Fig9.png',dpi=350)
plt.close(fig)

plt.rcParams.update({'font.size':14, 'axes.labelsize':14, 'axes.titlesize':15})
fig, (a,b)=plt.subplots(1,2,figsize=(12.0,5.3),gridspec_kw={'width_ratios':[1.15,1]},layout='constrained')
groups=['S1','S2','S3','All']; group_labels=['P01','P02','P03','Pooled']
metric_keys=['accuracy','macro_precision','macro_recall','macro_f1']
metric_labels=['Accuracy','Macro-precision','Balanced accuracy','Macro-F1']
colors=['#263f58','#4f83a1','#55a99d','#a0c6d4']; x=np.arange(4); width=.19
for index,(key,label,color) in enumerate(zip(metric_keys,metric_labels,colors)):
    bars=a.bar(x+(index-1.5)*width,[100*held[g][key] for g in groups],width=width,label=label,color=color)
a.set(ylim=(0,100),ylabel='Performance (%)',xticks=x,xticklabels=group_labels)
a.set_title('(a)  Performance by participant',loc='left',weight='bold',pad=13)
a.grid(axis='y',color='#dde4e8',linewidth=.6); a.set_axisbelow(True)
a.legend(loc='upper center',bbox_to_anchor=(.5,-.11),ncols=2,frameon=False,fontsize=12)
recall=np.array([held[g]['class_recall'] for g in groups]).T*100
im=b.imshow(recall,cmap=palette,vmin=0,vmax=100,aspect='auto')
b.set_title('(b)  Recall by posture',loc='left',weight='bold',pad=13)
b.set_xticks(range(4),group_labels); b.set_yticks(range(8),labels)
b.set_xticks(np.arange(-.5,4,1),minor=True); b.set_yticks(np.arange(-.5,8,1),minor=True)
b.grid(which='minor',color='white',linewidth=1.2); b.tick_params(which='both',length=0)
for i in range(8):
    for j in range(4):
        b.text(j,i,f'{recall[i,j]:.1f}',ha='center',va='center',fontsize=13,color='white' if recall[i,j]>55 else '#153244')
fig.colorbar(im,ax=b,shrink=.85,pad=.03,label='Recall (%)')
fig.savefig(ROOT/'Fig10.png',dpi=350)
plt.close(fig)

names=['Standing straight','Left arm raise','Right arm raise','Left shoulder touch and twist',
       'Right shoulder touch and twist','Both arms raise','Forward bend','Sitting']
for group,name in zip(groups,group_labels):
    h=held[group]
    print(name, {k:round(h[k]*100,2) for k in metric_keys}, 'n=',h['support'])
    for i in range(8):
        print(f"{name} & {i+1}. {names[i]} & {h['class_support'][i]} & {100*h['class_precision'][i]:.2f} & {100*h['class_recall'][i]:.2f} & {100*h['class_f1'][i]:.2f} \\\\")
print('Verified metric groups:',len(verified))
print('Held incorrect:',int(cm.sum()-np.trace(cm)), 'Standing-involved:',int(cm[0,1:].sum()+cm[1:,0].sum()))
