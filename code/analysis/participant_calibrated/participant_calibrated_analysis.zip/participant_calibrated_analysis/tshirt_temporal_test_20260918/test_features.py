import unittest
import numpy as np
import benchmark as b


class Features(unittest.TestCase):
    def test_linear(self):
        values=np.tile((np.arange(160)*.05)[:,None],(1,10))
        result=b.temporal_features(values,100,0).reshape(10,4)
        np.testing.assert_allclose(result[:,0],1.)
        np.testing.assert_allclose(result[:,1],2.5)
        np.testing.assert_allclose(result[:,2],1.)
        np.testing.assert_allclose(result[:,3],-.05*20)

    def test_future_and_previous_group_invariance(self):
        rng=np.random.default_rng(71);a=rng.normal(size=(160,10))
        expected=b.temporal_features(a,90,50)
        a[:50]=1e20;a[90:]=-1e20
        np.testing.assert_array_equal(expected,b.temporal_features(a,90,50))

    def test_missing_and_short_history(self):
        a=np.ones((80,10));a[:,3]=np.nan
        r=b.temporal_features(a,20,0).reshape(10,4)
        self.assertTrue(np.isnan(r[:,0]).all());self.assertTrue(np.isnan(r[:,1]).all())
        self.assertTrue(np.isnan(r[:,3]).all());self.assertTrue(np.isnan(r[3]).all())
        np.testing.assert_allclose(r[np.arange(10)!=3,2],0.)

    def test_train_only_imputation(self):
        bench,_,_=b.joint.load_dependencies()
        train=np.array([[1.,np.nan],[3.,2.],[np.nan,4.]])
        test=np.array([[np.nan,1000.]])
        transformed,unseen=bench.preprocess(train,test)
        self.assertAlmostEqual(unseen[0,0],0.)
        np.testing.assert_allclose(transformed.mean(0),0,atol=1e-14)


if __name__=='__main__':unittest.main()
