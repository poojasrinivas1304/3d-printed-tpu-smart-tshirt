#!/usr/bin/env python3
"""Independent feature/metric checks and selected-fit replays."""
from collections import Counter
import json
from pathlib import Path
import warnings
import numpy as np
import pandas as pd
import sklearn.metrics as skm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import benchmark as b

ROOT=b.ROOT
NAMES=['Standing straight','Left arm raise','Right arm raise','Left shoulder touch and twist',
       'Right shoulder touch and twist','Both arms raise','Forward bend','Sitting']


def independent_history(raw, row):
    group=raw.loc[raw.set_id.eq(row.set_id)&raw.rep.eq(row.rep)]
    last=int(row.sample_end);first=max(int(group.sample_index.min()),last-79)
    q=group.loc[group.sample_index.between(first,last)].copy()
    assert len(q)==last-first+1
    results={}
    for kind in ('res','adc'):
        collected=[]
        for sensor in range(1,11):
            qc=q[f'qc_high_adc_s{sensor}'].ne(0)|q[f'qc_low_adc_s{sensor}'].ne(0)|~np.isfinite(q[f'dr_s{sensor}'])
            values=q[f'dr_s{sensor}' if kind=='res' else f'adc_s{sensor}'].to_numpy(float,copy=True)
            values[qc.to_numpy()]=np.nan
            index=q.sample_index.to_numpy()
            def med(start,end):
                v=values[(index>=start)&(index<=end)];v=v[np.isfinite(v)]
                return float(np.median(v)) if len(v) else np.nan
            def iqr(start,end):
                v=values[(index>=start)&(index<=end)];v=v[np.isfinite(v)]
                return float(np.percentile(v,75)-np.percentile(v,25)) if len(v) else np.nan
            good=np.isfinite(values)
            slope=float(np.polyfit((index[good]-last)*.05,values[good],1)[0]) if good.sum()>=2 else np.nan
            current=med(last-19,last)
            collected.extend([current-med(last-39,last-20),current-med(last-79,last-40),slope,
                              iqr(last-19,last)-iqr(last-79,last-20)])
        results[kind]=np.asarray(collected)
    return first,results


def independently_score(truth,pred):
    return dict(accuracy=skm.accuracy_score(truth,pred),macro_precision=skm.precision_score(truth,pred,average='macro',zero_division=0),
                macro_recall=skm.recall_score(truth,pred,average='macro',zero_division=0),
                macro_f1=skm.f1_score(truth,pred,average='macro',zero_division=0))


def verify():
    result=ROOT/'results';manifest=json.loads((result/'manifest.json').read_text())
    assert manifest['completed'] and manifest['inner_fits']==960
    assert manifest['plan_sha256']==b.digest(ROOT/'PLAN.md')
    assert manifest['script_sha256']==b.digest(ROOT/'benchmark.py')
    for path,h in manifest['source_hashes'].items():assert b.digest(path)==h
    bench,_,audit=b.joint.load_dependencies()
    meta=pd.read_csv(b.joint.SOURCE/'results/window_manifest.csv')
    sources=pd.read_csv(result/'history_sources.csv')
    features=dict(np.load(result/'feature_matrices.npz'))
    pred=pd.DataFrame(json.loads((result/'outer_predictions.json').read_text()))
    selections=json.loads((result/'selections.json').read_text())
    metrics=json.loads((result/'metrics.json').read_text())
    raw={f'S{i}':pd.read_csv(b.joint.SOURCE/f'data/processed/subject_{i:02d}.csv') for i in range(1,4)}
    features_checked=0
    for row in meta.itertuples():
        start,values=independent_history(raw[row.participant],row)
        source=sources.loc[sources.window_id.eq(row.window_id)].iloc[0]
        assert int(source.history_sample_start)==start and int(source.history_sample_end)==row.sample_end
        for kind in ('res','adc'):
            for ctx in (20,40):
                np.testing.assert_allclose(features[f'{kind}7_{ctx}_history'][row.window_id,70:],values[kind],rtol=1e-9,atol=1e-8,equal_nan=True)
                np.testing.assert_array_equal(features[f'{kind}7_{ctx}_history'][row.window_id,:70],features[f'{kind}7_{ctx}'][row.window_id])
                features_checked+=1
    print(f'Independently verified {features_checked} temporal feature vectors against source CSVs.',flush=True)
    metric_checks=0
    for m in metrics:
        d=pred.loc[pred.procedure.eq(m['procedure'])&pred.period.eq(m['period'])]
        if m['participant']!='All':d=d.loc[d.participant.eq(m['participant'])]
        values=independently_score(d.position_index,d.predicted_position)
        for k,v in values.items():assert abs(v-m[k])<1e-12
        cm=skm.confusion_matrix(d.position_index,d.predicted_position,labels=range(1,9))
        assert cm.tolist()==m['confusion_counts'];assert len(d)==m['support']
        assert cm.sum(1).tolist()==m['class_support'];metric_checks+=1
    old=pd.DataFrame(json.loads((b.JOINT/'results/outer_predictions.json').read_text()))
    old=old.loc[old.procedure.eq(b.joint.PRIMARY)].sort_values('window_id')
    new=pred.loc[pred.procedure.eq(b.REFERENCE)].sort_values('window_id')
    np.testing.assert_array_equal(old.window_id,new.window_id)
    np.testing.assert_array_equal(old.predicted_position,new.predicted_position)
    for _,d in pred.groupby('procedure'):
        assert d.window_id.nunique()==2378 and len(d)==2378 and d.period.eq('Held posture').sum()==2032
        p=d[[f'probability_{k}' for k in range(1,9)]].to_numpy(copy=True)
        np.testing.assert_allclose(p.sum(1),1);assert (p>=0).all() and (p<=1).all()
        p[:,0]*=d.standing_multiplier.to_numpy()
        np.testing.assert_array_equal(np.argmax(p,axis=1)+1,d.predicted_position)
    source_meta=meta.copy()
    source_meta['context_sample_start']=np.minimum(meta.context_sample_start,sources.history_sample_start)
    source_meta['context_sample_end']=meta.sample_end
    split_count=0;selection_checks=0;outer_replays=0;inner_replays=0
    for person in ('S1','S2','S3'):
        for outer in range(1,6):
            train,test,prepared,checks=b.prepare(bench,audit,meta,source_meta,features,person,outer)
            split_count+=len(checks)
            block=json.loads((result/f'inner_{person}_rep{outer}.json').read_text())
            expected_ids={c['candidate_id'] for c in b.grid()}
            assert {r['candidate']['candidate_id'] for r in block['search']}==expected_ids
            assert len(block['search'])==112
            for r in block['search']:
                assert r['candidate']==next(c for c in b.grid() if c['candidate_id']==r['candidate']['candidate_id'])
                assert r['standing_multiplier'] in b.ALPHAS
                assert {f['inner_rep'] for f in r['folds']}==set(range(1,6))-{outer}
                for key,field in [('mean_macro_f1','macro_f1'),('mean_accuracy','accuracy'),('mean_balanced_accuracy','macro_recall')]:
                    assert abs(r[key]-np.mean([f[field] for f in r['folds']]))<1e-12
            assert block['reference']==b.reference(person,outer)
            expected={b.PRIMARY:min(block['search']+[block['reference']],key=b.rank),
                      b.LEVEL:min((r for r in block['search'] if not r['candidate']['history']),key=b.rank),
                      b.TEMPORAL:min((r for r in block['search'] if r['candidate']['history']),key=b.rank),
                      b.REFERENCE:block['reference']}
            cache={}
            for procedure,choice in expected.items():
                s=next(s for s in selections if s['participant']==person and s['outer_rep']==outer and s['procedure']==procedure)
                assert {k:v for k,v in s.items() if k not in ('participant','outer_rep','procedure')}==choice
                selection_checks+=1;c=s['candidate'];alpha=s['standing_multiplier'];key=(c['candidate_id'],alpha)
                if key not in cache:
                    cache[key]=b.fit_outer(c,alpha,features,train,test,meta.position_index.to_numpy(int),outer,bench)
                    outer_replays+=1
                predictions,probs=cache[key]
                saved=pred.loc[pred.participant.eq(person)&pred.rep.eq(outer)&pred.procedure.eq(procedure)].sort_values('window_id')
                np.testing.assert_array_equal(saved.window_id,meta.iloc[test].window_id)
                np.testing.assert_array_equal(saved.predicted_position,predictions)
                np.testing.assert_allclose(saved[[f'probability_{k}' for k in range(1,9)]],probs,atol=1e-14,rtol=0)
                if procedure==b.PRIMARY:
                    repeated=b.fit_inner(c,prepared,outer)
                    r=next(r for r in repeated if r['standing_multiplier']==alpha)
                    assert r['folds']==choice['folds'];inner_replays+=4
            print(f'Verified choices, splits and replays for {person} repetition {outer}.',flush=True)
    for path,h in manifest['source_hashes'].items():assert b.digest(path)==h
    verification=dict(passed=True,feature_vectors_checked=features_checked,metric_groups_checked=metric_checks,
                      split_checks=split_count,selection_checks=selection_checks,outer_fits_replayed=outer_replays,
                      primary_inner_fits_replayed=inner_replays,all_prediction_rows_checked=len(pred),
                      original_working_predictions_reproduced=True,sources_unchanged=True)
    b.save(result/'verification.json',verification)
    report(pred,selections,metrics,verification,manifest)
    print(json.dumps(verification,indent=2))


def tab(headers,rows):
    return '| '+' | '.join(headers)+' |\n|'+'|'.join(['---']*len(headers))+'|\n'+'\n'.join(
        '| '+' | '.join(str(x) for x in row)+' |' for row in rows)


def report(pred,selections,metrics,verification,manifest):
    procedures=[b.REFERENCE,b.LEVEL,b.TEMPORAL,b.PRIMARY]
    labels={b.REFERENCE:'Existing working model',b.LEVEL:'Level-only control',b.TEMPORAL:'Temporal-only ablation',b.PRIMARY:'Primary training-only selection'}
    def get(proc,person='All'):
        return next(x for x in metrics if x['procedure']==proc and x['period']=='Held posture' and x['participant']==person)
    old=get(b.REFERENCE);primary=get(b.PRIMARY)
    overall=tab(['Procedure','Accuracy','Macro precision','Balanced accuracy','Macro-F1'],
                [[labels[p],*[f'{100*get(p)[k]:.2f}%' for k in ('accuracy','macro_precision','macro_recall','macro_f1')]] for p in procedures])
    participants=tab(['Participant','Procedure','Accuracy','Macro precision','Balanced accuracy','Macro-F1'],
                     [[person,labels[p],*[f'{100*get(p,person)[k]:.2f}%' for k in ('accuracy','macro_precision','macro_recall','macro_f1')]]
                      for person in ('S1','S2','S3') for p in (b.REFERENCE,b.PRIMARY)])
    classes=tab(['Posture','Support','Previous recall','Primary recall','Primary precision','Primary F1'],
                [[name,primary['class_support'][i],f"{100*old['class_recall'][i]:.2f}%",f"{100*primary['class_recall'][i]:.2f}%",
                  f"{100*primary['class_precision'][i]:.2f}%",f"{100*primary['class_f1'][i]:.2f}%"] for i,name in enumerate(NAMES)])
    chosen=[s for s in selections if s['procedure']==b.PRIMARY]
    history_count=sum(s['candidate']['history'] for s in chosen)
    feature_counts=Counter(s['candidate']['feature_key'] for s in chosen)
    selection_table=tab(['Participant','Held-out repetition','Feature set','Leaf size','Standing multiplier'],
                        [[s['participant'],s['outer_rep'],s['candidate']['feature_key'],s['candidate']['min_samples_leaf'],s['standing_multiplier']] for s in chosen])
    errors=[];folds=[]
    for p in (b.REFERENCE,b.PRIMARY):
        d=pred.loc[pred.procedure.eq(p)&pred.period.eq('Held posture')]
        wrong=d.position_index.ne(d.predicted_position)
        involved=(d.position_index.eq(1)|d.predicted_position.eq(1))&wrong
        errors.append([labels[p],int(wrong.sum()),int(involved.sum()),int((wrong&d.position_index.eq(1)).sum())])
        for (person,rep),g in d.groupby(['participant','rep']):
            folds.append(dict(procedure=p,participant=person,outer_rep=int(rep),**independently_score(g.position_index,g.predicted_position)))
    fold=pd.DataFrame(folds);fold.to_csv(ROOT/'results/fold_metrics.csv',index=False)
    pivot=fold.pivot(index=['participant','outer_rep'],columns='procedure',values='macro_f1')
    improved=int((pivot[b.PRIMARY]>pivot[b.REFERENCE]+1e-12).sum());equal=int(np.isclose(pivot[b.PRIMARY],pivot[b.REFERENCE],rtol=0,atol=1e-12).sum())
    transitions=next(m for m in metrics if m['procedure']==b.PRIMARY and m['participant']=='All' and m['period']=='Transition')
    delta={k:100*(primary[k]-old[k]) for k in ('accuracy','macro_precision','macro_recall','macro_f1')}
    message=(f"The primary procedure changed macro-F1 by {delta['macro_f1']:+.2f} percentage points and accuracy by {delta['accuracy']:+.2f} points. "
             f"Balanced accuracy changed by {delta['macro_recall']:+.2f} points and macro precision by {delta['macro_precision']:+.2f} points.")
    text=f'''# Focused temporal-feature test

## Result

{message}

Primary results are **{100*primary['accuracy']:.2f}% accuracy, {100*primary['macro_recall']:.2f}% balanced accuracy, {100*primary['macro_f1']:.2f}% macro-F1 and {100*primary['macro_precision']:.2f}% macro precision**. No data collection, source-data edits or manuscript changes were made.

These remain exploratory participant-calibrated results from the same repeatedly used recordings. Nested training-only selection does not turn this development round into independent-session or external validation.

## All prespecified comparisons

{overall}

Every row uses the same 2,032 held decision windows, labels, ten sensors and outer repetition partitions. The primary row selects between level and temporal candidates plus the saved working fallback using inner scores only. The temporal-only row is a prespecified ablation, not a replacement chosen after seeing outer performance. The matched level-only control has a narrower candidate pool than the existing working procedure, so those two reference rows are not identical designs.

## Participants

{participants}

## All eight postures

{classes}

Balanced accuracy equals macro recall across the eight classes. Supports are decision windows, not independent trials.

## Error pattern and selection stability

{tab(['Procedure','All errors','Errors involving standing','Standing false negatives'],errors)}

Temporal features were selected in {history_count} of 15 primary outer folds. Feature-set counts: {dict(feature_counts)}. Primary macro-F1 improved in {improved} folds, tied in {equal}, and declined in {15-improved-equal}. Shared training data and repeated windows mean these are not independent experimental replications.

{selection_table}

## What changed

For each sensor, the new representation appends four causal features to the original statistics: recent median change over one second, recent median change relative to samples two-to-four seconds ago, four-second least-squares slope, and recent-versus-earlier IQR difference. Both ADC and recording-normalized resistance were tested. Existing high/low ADC masks and missing values were retained.

History stops at the prediction window's final sample and starts no earlier than the same stored repetition group. No future samples, previous-group samples, posture labels, target identifiers, elapsed time, participant IDs or repetition IDs are numerical inputs. No known reference-hold value is supplied to the new features. Missing intervals remain missing until training-fold imputation.

The existing decision windows and current-level features retain known phase boundaries, and history resets at known repetition-group starts. Short available histories are not padded. Boundary-dependent history availability can itself correlate with the fixed protocol; no unknown-boundary deployment claim is made.

The fixed grid used 16 feature/configuration candidates, the seven already-used standing multipliers, five outer repetition folds per participant and four inner folds. Imputation and scaling were trained separately inside each split. The ranking was mean inner macro-F1, then accuracy, balanced accuracy and fixed tie breakers. The primary pool also included the prior working choice using its original saved inner scores. No outer score was used for that selection.

The standing multiplier changes decision scores; it is not a calibrated probability or abstention threshold. No classes were removed, no new sample masks were added and no decision windows were dropped. The original incomplete-tail rule remains unchanged.

## Transitions

The primary model agreed with the prompted destination in {100*transitions['accuracy']:.2f}% of 346 transition windows. These were not used for selection and are not interpreted as instantaneous physical-posture ground truth.

## Verification

- Four pre-fit tests passed for expected feature arithmetic, causality, missing/short histories and train-only imputation.
- All {verification['feature_vectors_checked']:,} new feature-vector instances were independently reconstructed from the original CSV sample ranges. Four instances per window reflect two representations and two legacy contexts.
- Verified {verification['split_checks']} inner/outer splits with no shared raw history samples or stored groups, {verification['selection_checks']} selections and all {verification['all_prediction_rows_checked']:,} saved predictions.
- Independently recomputed {verification['metric_groups_checked']} metric groups, replayed {verification['outer_fits_replayed']} unique selected outer fits and {verification['primary_inner_fits_replayed']} primary inner fits. The previous working predictions reproduced exactly.
- Input files remained byte-for-byte unchanged. The plan and fitting-script hashes match their pre-fit manifest. The Spreadsheets skill's research guidance informed source preservation and independent checks.

The fixed run used {manifest['inner_fits']} inner fits and took {manifest['elapsed_seconds']/60:.1f} minutes before verification. The grid was not expanded after viewing the results.

## Limits and decision

This tests a focused feature change, not a new dataset. Only three participants and within-recording repetition folds are available. Fixed-order blocks, possible physical-cycle dependence, initial calibration, known protocol boundaries and repeated development remain limitations. The features cannot establish the cause of sensor-history effects or correct unverified physical-posture labels.

Compare the primary result with the existing working model across accuracy, macro-F1, balanced accuracy and individual participants before choosing what to discuss with the supervisor. A higher secondary score alone is not grounds to relabel the primary analysis. Further data-driven changes would be another exploratory round.

No Overleaf, GitHub, original records or prior result packages were changed. Full scores, predictions/probabilities, selections, feature arrays and source provenance are in `results/`. See `README.md` for reproduction.
'''
    (ROOT/'RESULTS.md').write_text(text)
    plot(old,primary)


def plot(old,new):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(12,4.8),layout='constrained',gridspec_kw={'width_ratios':[1,1.4]})
    keys=['accuracy','macro_precision','macro_recall','macro_f1'];labels=['Accuracy','Macro\nprecision','Balanced\naccuracy','Macro-F1']
    for offset,values,name,color in [(-.18,old,'Existing working model','#8595a5'),(.18,new,'Primary temporal test','#258b88')]:
        bars=axes[0].bar(np.arange(4)+offset,[100*values[k] for k in keys],width=.35,label=name,color=color)
        axes[0].bar_label(bars,fmt='%.1f',fontsize=8,padding=2)
    axes[0].set(xticks=range(4),xticklabels=labels,ylim=(0,100),ylabel='Score (%)',title='Same held-posture decision windows')
    axes[0].legend(frameon=False,loc='upper left',fontsize=8)
    y=np.arange(8)
    axes[1].plot(100*np.array(old['class_recall']),y,'o',color='#8595a5',label='Existing')
    axes[1].plot(100*np.array(new['class_recall']),y,'o',color='#258b88',label='Primary')
    for i in y:axes[1].plot([100*old['class_recall'][i],100*new['class_recall'][i]],[i,i],color='#ccd2d5',zorder=0)
    axes[1].set(yticks=y,yticklabels=NAMES,xlim=(0,100),xlabel='Recall (%)',title='All eight postures')
    axes[1].invert_yaxis();axes[1].grid(axis='x',alpha=.2)
    fig.savefig(ROOT/'comparison.png',dpi=180);plt.close(fig)


if __name__=='__main__':verify()
