# Focused temporal-feature test

## Result

The primary procedure changed macro-F1 by +0.82 percentage points and accuracy by +0.94 points. Balanced accuracy changed by +0.98 points and macro precision by +0.72 points.

Primary results are **68.31% accuracy, 73.37% balanced accuracy, 69.07% macro-F1 and 65.94% macro precision**. No data collection, source-data edits or manuscript changes were made.

These remain exploratory participant-calibrated results from the same repeatedly used recordings. Nested training-only selection does not turn this development round into independent-session or external validation.

## All prespecified comparisons

| Procedure | Accuracy | Macro precision | Balanced accuracy | Macro-F1 |
|---|---|---|---|---|
| Existing working model | 67.37% | 65.22% | 72.39% | 68.25% |
| Level-only control | 65.99% | 64.31% | 71.61% | 67.35% |
| Temporal-only ablation | 68.16% | 65.81% | 72.82% | 68.75% |
| Primary training-only selection | 68.31% | 65.94% | 73.37% | 69.07% |

Every row uses the same 2,032 held decision windows, labels, ten sensors and outer repetition partitions. The primary row selects between level and temporal candidates plus the saved working fallback using inner scores only. The temporal-only row is a prespecified ablation, not a replacement chosen after seeing outer performance. The matched level-only control has a narrower candidate pool than the existing working procedure, so those two reference rows are not identical designs.

## Participants

| Participant | Procedure | Accuracy | Macro precision | Balanced accuracy | Macro-F1 |
|---|---|---|---|---|---|
| S1 | Existing working model | 67.95% | 65.93% | 70.83% | 67.93% |
| S1 | Primary training-only selection | 70.01% | 67.96% | 73.13% | 70.02% |
| S2 | Existing working model | 71.24% | 68.86% | 77.05% | 72.33% |
| S2 | Primary training-only selection | 71.24% | 68.59% | 77.04% | 72.15% |
| S3 | Existing working model | 62.92% | 61.06% | 69.36% | 64.11% |
| S3 | Primary training-only selection | 63.66% | 61.50% | 70.01% | 64.65% |

## All eight postures

| Posture | Support | Previous recall | Primary recall | Primary precision | Primary F1 |
|---|---|---|---|---|---|
| Standing straight | 1017 | 60.77% | 61.65% | 74.03% | 67.27% |
| Left arm raise | 143 | 79.02% | 82.52% | 71.52% | 76.62% |
| Right arm raise | 143 | 77.62% | 79.72% | 62.30% | 69.94% |
| Left shoulder touch and twist | 144 | 68.75% | 68.06% | 49.75% | 57.48% |
| Right shoulder touch and twist | 147 | 73.47% | 75.51% | 63.43% | 68.94% |
| Both arms raise | 147 | 72.79% | 72.79% | 76.98% | 74.83% |
| Forward bend | 144 | 89.58% | 90.97% | 76.61% | 83.17% |
| Sitting | 147 | 57.14% | 55.78% | 52.90% | 54.30% |

Balanced accuracy equals macro recall across the eight classes. Supports are decision windows, not independent trials.

## Error pattern and selection stability

| Procedure | All errors | Errors involving standing | Standing false negatives |
|---|---|---|---|
| Existing working model | 663 | 630 | 399 |
| Primary training-only selection | 644 | 610 | 390 |

Temporal features were selected in 5 of 15 primary outer folds. Feature-set counts: {'adc7_40': 1, 'res7_40': 2, 'res7_40_history': 3, 'adc7_20_history': 1, 'adc5_40': 5, 'adc7_40_history': 1, 'adc7_20': 1, 'res5_40': 1}. Primary macro-F1 improved in 3 folds, tied in 10, and declined in 2. Shared training data and repeated windows mean these are not independent experimental replications.

| Participant | Held-out repetition | Feature set | Leaf size | Standing multiplier |
|---|---|---|---|---|
| S1 | 1 | adc7_40 | 1 | 0.75 |
| S1 | 2 | res7_40 | 1 | 0.5 |
| S1 | 3 | res7_40_history | 1 | 0.5 |
| S1 | 4 | res7_40_history | 1 | 0.5 |
| S1 | 5 | adc7_20_history | 1 | 0.5 |
| S2 | 1 | adc5_40 | 2 | 0.75 |
| S2 | 2 | adc5_40 | 1 | 0.5 |
| S2 | 3 | adc5_40 | 1 | 0.5 |
| S2 | 4 | adc5_40 | 1 | 0.5 |
| S2 | 5 | adc7_40_history | 1 | 0.5 |
| S3 | 1 | adc7_20 | 1 | 0.5 |
| S3 | 2 | res5_40 | 2 | 0.5 |
| S3 | 3 | res7_40 | 1 | 0.5 |
| S3 | 4 | adc5_40 | 1 | 0.5 |
| S3 | 5 | res7_40_history | 1 | 0.5 |

## What changed

For each sensor, the new representation appends four causal features to the original statistics: recent median change over one second, recent median change relative to samples two-to-four seconds ago, four-second least-squares slope, and recent-versus-earlier IQR difference. Both ADC and recording-normalized resistance were tested. Existing high/low ADC masks and missing values were retained.

History stops at the prediction window's final sample and starts no earlier than the same stored repetition group. No future samples, previous-group samples, posture labels, target identifiers, elapsed time, participant IDs or repetition IDs are numerical inputs. No known reference-hold value is supplied to the new features. Missing intervals remain missing until training-fold imputation.

The existing decision windows and current-level features retain known phase boundaries, and history resets at known repetition-group starts. Short available histories are not padded. Boundary-dependent history availability can itself correlate with the fixed protocol; no unknown-boundary deployment claim is made.

The fixed grid used 16 feature/configuration candidates, the seven already-used standing multipliers, five outer repetition folds per participant and four inner folds. Imputation and scaling were trained separately inside each split. The ranking was mean inner macro-F1, then accuracy, balanced accuracy and fixed tie breakers. The primary pool also included the prior working choice using its original saved inner scores. No outer score was used for that selection.

The standing multiplier changes decision scores; it is not a calibrated probability or abstention threshold. No classes were removed, no new sample masks were added and no decision windows were dropped. The original incomplete-tail rule remains unchanged.

## Transitions

The primary model agreed with the prompted destination in 19.94% of 346 transition windows. These were not used for selection and are not interpreted as instantaneous physical-posture ground truth.

## Verification

- Four pre-fit tests passed for expected feature arithmetic, causality, missing/short histories and train-only imputation.
- All 9,512 new feature-vector instances were independently reconstructed from the original CSV sample ranges. Four instances per window reflect two representations and two legacy contexts.
- Verified 75 inner/outer splits with no shared raw history samples or stored groups, 60 selections and all 9,512 saved predictions.
- Independently recomputed 32 metric groups, replayed 45 unique selected outer fits and 60 primary inner fits. The previous working predictions reproduced exactly.
- Input files remained byte-for-byte unchanged. The plan and fitting-script hashes match their pre-fit manifest. The Spreadsheets skill's research guidance informed source preservation and independent checks.

The fixed run used 960 inner fits and took 2.8 minutes before verification. The grid was not expanded after viewing the results.

## Limits and decision

This tests a focused feature change, not a new dataset. Only three participants and within-recording repetition folds are available. Fixed-order blocks, possible physical-cycle dependence, initial calibration, known protocol boundaries and repeated development remain limitations. The features cannot establish the cause of sensor-history effects or correct unverified physical-posture labels.

Compare the primary result with the existing working model across accuracy, macro-F1, balanced accuracy and individual participants before choosing what to discuss with the supervisor. A higher secondary score alone is not grounds to relabel the primary analysis. Further data-driven changes would be another exploratory round.

No Overleaf, GitHub, original records or prior result packages were changed. Full scores, predictions/probabilities, selections, feature arrays and source provenance are in `results/`. See `README.md` for reproduction.
