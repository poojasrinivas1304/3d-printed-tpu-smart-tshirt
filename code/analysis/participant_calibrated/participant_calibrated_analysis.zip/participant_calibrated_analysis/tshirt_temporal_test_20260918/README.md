# T-shirt focused temporal-feature test

Read `RESULTS.md` for findings and `PLAN.md` for the fixed design. This is a participant-calibrated software-only experiment on existing recordings. It does not establish independent-session performance.

Source CSVs remain in the sibling `tshirt_algorithm_benchmark_20260918/data/processed/` folder. The code reuses the preserved feature/preprocessing utilities and working-model selections in `tshirt_joint_benchmark_20260918`, which in turn reads the existing benchmark and validation helpers. Exact source paths and hashes, package versions, feature shapes and run details are recorded in `results/manifest.json`.

The bundled Python runtime lacked the required scientific model-fitting/plotting packages. This test uses the existing scientific environment at `/Library/Frameworks/Python.framework/Versions/3.14/bin/python3`. No dependencies were installed or changed.

From this folder:

```sh
MPLCONFIGDIR=/private/tmp/tshirt-temporal-mpl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Library/Frameworks/Python.framework/Versions/3.14/bin/python3 test_features.py
```

To rerun the fixed benchmark, supply a new output directory rather than overwriting the completed result:

```sh
MPLCONFIGDIR=/private/tmp/tshirt-temporal-mpl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Library/Frameworks/Python.framework/Versions/3.14/bin/python3 benchmark.py --out /private/tmp/tshirt-temporal-new-run --jobs 4
```

`verify_and_report.py` verifies the delivered `results/` folder and regenerates the report and comparison figure. It independently checks features and metrics and replays selected fits. The source files and previous results are read-only inputs.

Saved artifacts include all inner scores, outer predictions with unweighted class probabilities, fold selections, feature-source intervals, cached feature matrices, metrics, fold results and verification results. Standing reweighting is applied only when choosing the final class and is not probability calibration. Sensor and participant numbering are separate.
