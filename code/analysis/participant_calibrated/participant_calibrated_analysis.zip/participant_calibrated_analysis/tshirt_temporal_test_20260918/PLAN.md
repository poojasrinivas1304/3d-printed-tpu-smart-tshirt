# Focused causal-history test

This plan is fixed before fitting. It responds to the error audit, not to a target percentage. No new data collection, source edits, label changes, manual masks, new QC thresholds, boundary trimming, smoothing of predictions or manuscript/GitHub edits are authorized.

## Question

Do recent changes in each sensor improve discrimination between standing and movement, beyond the current signal level? Preserve all eight classes, all ten sensors and the existing 2,032 held-posture decision windows. Keep the 346 transition windows as a separate descriptive output, not a selection target.

## Features

Use the unchanged normalized-resistance and ADC representations and the original masks. The level-only controls retain the seven existing per-channel statistics and 20- or up-to-40-sample phase-delimited contexts. New temporal candidates append four features per sensor, computed at the decision-window end:

1. Median of the latest 20 samples minus median of the preceding 20 samples.
2. Median of the latest 20 samples minus median of samples 41–80 counting backward from the current end.
3. Ordinary least-squares slope over the latest up-to-80 samples, using device sample spacing of 0.05 s and finite values only.
4. IQR of the latest 20 samples minus IQR of the preceding up-to-60 samples.

Clip history to the beginning of the same stored set/repetition group, not to a future boundary. Empty/all-missing intervals remain NaN. Do not interpolate, fill missing raw samples, pad the history, use future samples, or supply phase, posture, target, elapsed time or repetition ID as numerical predictors. Short histories use only the data available so far.

The group-start reset and legacy phase-delimited feature extraction retain known protocol-boundary assumptions. This is not a test of unknown-boundary, free-living deployment. History cannot read the preceding repetition because its samples may belong to another partition. The initial recording calibration remains unchanged.

## Fixed candidate pool

Two representations × two legacy contexts × two ExtraTrees configurations × two feature sets = 16 candidates. All use 128 trees. Configurations are the previously used leaf 1 / sqrt / no class weighting and leaf 2 / 0.5 / balanced class weighting. No additional algorithms or sensor selection.

Retain the existing standing score multipliers 0.5, 0.75, 1, 1.25, 1.5, 2 and 3 as inner-only choices. This is score reweighting, not calibrated confidence. Include the previous working procedure's fold-specific choice, using its saved inner scores, as a fallback. Its outer predictions are never used to select a candidate.

## Validation and outputs

Use the unchanged participant-specific five outer repetition folds, with four inner repetition folds. Imputation and standardization are fitted only on each training partition. Check disjoint groups and all raw feature-history source samples at both levels. Each outer repetition holds out that repetition number across all seven movement blocks.

Primary: training-only selection from the fixed new pool plus the working fallback, maximizing mean inner macro-F1, then accuracy, balanced accuracy, multiplier proximity to one, candidate ID and multiplier. Secondary ablations: level-only choice and temporal-only choice, using the same ranking and folds. The unchanged working predictions remain the comparison reference. Report every procedure; do not promote a secondary procedure based on its outer score.

Record all inner scores, choices, outer predictions/probabilities, source ranges, versions and hashes. Report pooled and participant accuracy, balanced accuracy/macro recall, macro precision, macro-F1 and all per-class results. Compare standing-related error counts and fold stability. No population significance claim from correlated windows or overlapping training folds.

The run has 960 inner fits (16 × 4 × 15), plus selected outer fits. Do not expand the grid or change the plan after examining outer results. Stop after this test, whether performance improves or not. Repeated development on these recordings remains exploratory rather than fresh independent validation.

## Verification

Test causal feature invariance to future and previous-group changes, empty intervals, linear slopes and train-only imputation before fitting. Independently reconstruct temporal features and metrics afterwards, replay all unique selected outer fits, verify all selections against logged inner scores, and hash-check original files. Save outputs only in this new folder.
