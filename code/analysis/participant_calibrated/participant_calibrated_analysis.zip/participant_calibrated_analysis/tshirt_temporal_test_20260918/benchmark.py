#!/usr/bin/env python3
"""One prespecified causal-history experiment. See PLAN.md."""
from __future__ import annotations
import argparse
import importlib.util
import json
import math
import platform
import time
import warnings
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import sklearn
from joblib import Parallel, delayed, parallel_config

ROOT=Path(__file__).resolve().parent
JOINT=ROOT.parent/'tshirt_joint_benchmark_20260918'
PRIMARY='Training-only temporal-or-level selection'
LEVEL='Level-only control'
TEMPORAL='Temporal-only ablation'
REFERENCE='Existing working procedure'
ALPHAS=(.5,.75,1.,1.25,1.5,2.,3.)


def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


joint=module(JOINT/'joint_benchmark.py','joint_for_temporal')
metric,save,digest=joint.metric,joint.save,joint.digest


def temporal_features(values,end,group_start):
    """Values are time x 10; end exclusive; never reads at/after end."""
    start=max(group_start,end-80)
    history=values[start:end]
    current=values[max(group_start,end-20):end]
    previous=values[max(group_start,end-40):max(group_start,end-20)]
    older=values[start:max(group_start,end-40)]
    past=values[start:max(group_start,end-20)]
    def median(a):
        if not len(a):return np.full(values.shape[1],np.nan)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',RuntimeWarning)
            return np.nanmedian(a,axis=0)
    def iqr(a):
        if not len(a):return np.full(values.shape[1],np.nan)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',RuntimeWarning)
            q=np.nanquantile(a,[.25,.75],axis=0)
        return q[1]-q[0]
    slopes=[]
    t=np.arange(len(history))*.05
    for s in range(values.shape[1]):
        good=np.isfinite(history[:,s]);x=t[good];y=history[good,s]
        if len(x)<2:slopes.append(np.nan);continue
        centered=x-x.mean()
        slopes.append(float(np.dot(centered,y-y.mean())/np.dot(centered,centered)))
    m=median(current)
    return np.column_stack([m-median(previous),m-median(older),slopes,iqr(current)-iqr(past)]).ravel()


def build_features():
    bench,base,audit=joint.load_dependencies()
    meta,original,mask=joint.build_features(bench,base)
    features={}
    for kind in ('res','adc'):
        for ctx in (20,40):
            features[f'{kind}7_{ctx}']=original[f'{kind}{ctx}']
            features[f'{kind}5_{ctx}']=original[f'{kind}{ctx}'][:,[(s-1)*7+i for s in range(1,11) for i in (0,1,2,3,6)]]
    temporal={kind:np.empty((len(meta),40)) for kind in ('res','adc')}
    histories=[]
    for person in range(1,4):
        raw=pd.read_csv(joint.SOURCE/f'data/processed/subject_{person:02d}.csv')
        raw=base._recording_normalized_group(raw.loc[raw.set_id.between(1,7)].copy()).reset_index(drop=True)
        res=raw[[f'x_s{s}' for s in range(1,11)]].to_numpy(float)
        adc=raw[[f'adc_s{s}' for s in range(1,11)]].to_numpy(float,copy=True)
        adc[~np.isfinite(res)]=np.nan
        offsets={int(sample):i for i,sample in enumerate(raw.sample_index)}
        starts={(int(a),int(b)):int(g.index.min()) for (a,b),g in raw.groupby(['set_id','rep'])}
        for row in meta.loc[meta.participant.eq(f'S{person}')].itertuples():
            end=offsets[row.sample_end]+1;gs=starts[row.set_id,row.rep];start=max(gs,end-80)
            history=raw.iloc[start:end]
            assert history.set_id.eq(row.set_id).all() and history.rep.eq(row.rep).all()
            assert int(history.sample_index.max())==row.sample_end
            for kind,values in [('res',res),('adc',adc)]:
                temporal[kind][row.window_id]=temporal_features(values,end,gs)
            histories.append(dict(window_id=row.window_id,participant=row.participant,
                                  history_sample_start=int(history.sample_index.iloc[0]),history_sample_end=row.sample_end,
                                  history_samples=len(history),group_sample_start=int(raw.sample_index.iloc[gs])))
    hm=pd.DataFrame(histories).sort_values('window_id')
    assert np.array_equal(hm.window_id,meta.window_id)
    for kind in ('res','adc'):
        for ctx in (20,40):
            features[f'{kind}7_{ctx}_history']=np.column_stack([features[f'{kind}7_{ctx}'],temporal[kind]])
    for x in features.values():assert x.shape[0]==2378 and not np.isinf(x).any()
    source_meta=meta.copy()
    source_meta['context_sample_start']=np.minimum(meta.context_sample_start.to_numpy(),hm.history_sample_start.to_numpy())
    source_meta['context_sample_end']=meta.sample_end
    return bench,audit,meta,source_meta,features,hm,mask


def grid():
    result=[]
    for kind in ('res','adc'):
        for ctx in (20,40):
            for history in (False,True):
                key=f'{kind}7_{ctx}'+('_history' if history else '')
                for setting in (0,1):
                    c=joint.candidate(kind+'7',range(1,11),ctx,setting)
                    c={k:v for k,v in c.items() if k not in ('representation','context','sensors')}
                    c.update(candidate_id=f'{key}_m{setting}',feature_key=key,history=history)
                    result.append(c)
    assert len(result)==16
    return result


def rank(r):
    return (-r['mean_macro_f1'],-r['mean_accuracy'],-r['mean_balanced_accuracy'],
            abs(math.log(r['standing_multiplier'])),r['candidate']['candidate_id'],r['standing_multiplier'])


def reference(person,outer):
    old=next(x for x in json.loads((JOINT/'results/selections.json').read_text())
             if x['procedure']==joint.PRIMARY and x['participant']==person and x['outer_rep']==outer)
    original=old['candidate'];assert original['sensors']==list(range(1,11))
    c={k:v for k,v in original.items() if k not in ('representation','context','sensors','candidate_id')}
    c.update(candidate_id='working_reference',feature_key=f"{original['representation']}_{original['context']}",history=False)
    return dict(candidate=c,**{k:v for k,v in old.items() if k not in ('procedure','participant','outer_rep','candidate')})


def prepare(bench,audit,meta,source_meta,features,person,outer):
    held=meta.period.eq('Held posture').to_numpy();pm=meta.participant.eq(person).to_numpy()
    train=np.flatnonzero(pm&held&meta.rep.ne(outer).to_numpy())
    test=np.flatnonzero(pm&meta.rep.eq(outer).to_numpy())
    checks=[dict(level='outer',**audit.checked_split(source_meta,train,test))]
    prepared={k:[] for k in features};y=meta.position_index.to_numpy(int)
    for inner in sorted(meta.iloc[train].rep.unique()):
        it=train[meta.iloc[train].rep.ne(inner).to_numpy()];iv=train[meta.iloc[train].rep.eq(inner).to_numpy()]
        checks.append(dict(level='inner',inner_rep=int(inner),**audit.checked_split(source_meta,it,iv)))
        for key,x in features.items():
            tx,vx=bench.preprocess(x[it],x[iv])
            prepared[key].append((int(inner),tx,y[it],vx,y[iv]))
    return train,test,prepared,checks


def fit_inner(c,prepared,outer):
    scored={alpha:[] for alpha in ALPHAS}
    for inner,tx,y,vx,truth in prepared[c['feature_key']]:
        model=joint.estimator(c,42+1000*outer+10*inner)
        model.fit(tx,y);assert np.array_equal(model.classes_,joint.LABELS)
        probs=model.predict_proba(vx)
        for alpha in ALPHAS:
            m=metric(truth,joint.decide(probs,alpha))
            scored[alpha].append(dict(inner_rep=inner,**{k:m[k] for k in ('macro_precision','macro_recall','macro_f1','accuracy','support')}))
    return [dict(candidate=c,standing_multiplier=alpha,folds=folds,
                 mean_macro_f1=float(np.mean([f['macro_f1'] for f in folds])),
                 mean_accuracy=float(np.mean([f['accuracy'] for f in folds])),
                 mean_balanced_accuracy=float(np.mean([f['macro_recall'] for f in folds]))) for alpha,folds in scored.items()]


def fit_outer(c,alpha,features,train,test,y,outer,bench):
    tx,vx=bench.preprocess(features[c['feature_key']][train],features[c['feature_key']][test])
    model=joint.estimator(c,42+100000+1000*outer+3)
    model.fit(tx,y[train]);assert np.array_equal(model.classes_,joint.LABELS)
    probs=model.predict_proba(vx)
    return joint.decide(probs,alpha),probs


def tracked_paths():
    return sorted(set(joint.tracked_paths()+[p for p in JOINT.rglob('*') if p.is_file() and '__pycache__' not in p.parts]))


def run(args):
    started=time.time();args.out.mkdir(parents=True,exist_ok=False)
    hashes={str(p):digest(p) for p in tracked_paths()}
    bench,audit,meta,source_meta,features,histories,masks=build_features()
    histories.to_csv(args.out/'history_sources.csv',index=False)
    np.savez_compressed(args.out/'feature_matrices.npz',**features)
    manifest=dict(completed=False,primary=PRIMARY,expected_inner_fits=960,plan_sha256=digest(ROOT/'PLAN.md'),
                  script_sha256=digest(__file__),source_hashes=hashes,mask_audit=masks,
                  feature_shapes={k:list(v.shape) for k,v in features.items()},
                  versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,sklearn=sklearn.__version__,joblib=joblib.__version__),
                  source_recordings_reused=True)
    save(args.out/'manifest.json',manifest)
    print('Feature and history-source checks complete. Fixed 960-inner-fit test starting.',flush=True)
    predictions=[];selections=[];checks=[];y=meta.position_index.to_numpy(int);fits=0
    for person in sorted(meta.participant.unique()):
        for outer in range(1,6):
            train,test,prepared,split=prepare(bench,audit,meta,source_meta,features,person,outer)
            checks.extend([dict(participant=person,outer_rep=outer,**s) for s in split])
            computed=Parallel(n_jobs=args.jobs)(delayed(fit_inner)(c,prepared,outer) for c in grid())
            records=[r for batch in computed for r in batch];fits+=16*4
            assert len(records)==112
            ref=reference(person,outer)
            choices=[(PRIMARY,min(records+[ref],key=rank)),
                     (LEVEL,min((r for r in records if not r['candidate']['history']),key=rank)),
                     (TEMPORAL,min((r for r in records if r['candidate']['history']),key=rank)),(REFERENCE,ref)]
            cache={}
            for procedure,choice in choices:
                c=choice['candidate'];alpha=choice['standing_multiplier'];key=(c['candidate_id'],alpha)
                if key not in cache:cache[key]=fit_outer(c,alpha,features,train,test,y,outer,bench)
                predicted,probs=cache[key]
                part=meta.iloc[test].copy();part['predicted_position']=predicted;part['procedure']=procedure
                part['candidate_id']=c['candidate_id'];part['standing_multiplier']=alpha;part['uses_history']=c['history']
                for k in range(8):part[f'probability_{k+1}']=probs[:,k]
                predictions.extend(part.to_dict('records'))
                selections.append(dict(participant=person,outer_rep=outer,procedure=procedure,**choice))
            save(args.out/f'inner_{person}_rep{outer}.json',dict(participant=person,outer_rep=outer,search=records,reference=ref))
            save(args.out/'outer_predictions.json',predictions);save(args.out/'selections.json',selections);save(args.out/'split_audit.json',checks)
            print(f'Completed {person}, repetition {outer}/5; {time.time()-started:.0f}s. Outer scores withheld until completion.',flush=True)
    frame=pd.DataFrame(predictions);metrics=[]
    for (procedure,period),g in frame.groupby(['procedure','period'],sort=False):
        for person,d in [('All',g),*list(g.groupby('participant'))]:
            metrics.append(dict(procedure=procedure,period=period,participant=person,**metric(d.position_index,d.predicted_position)))
    for _,d in frame.groupby('procedure'):
        assert len(d)==2378 and d.window_id.nunique()==2378 and d.period.eq('Held posture').sum()==2032
    assert fits==960
    assert hashes=={str(p):digest(p) for p in tracked_paths()}
    manifest.update(completed=True,inner_fits=fits,elapsed_seconds=time.time()-started,sources_unchanged=True)
    save(args.out/'metrics.json',metrics);save(args.out/'manifest.json',manifest)
    for r in metrics:
        if r['period']=='Held posture' and r['participant']=='All':
            print({k:r[k] for k in ('procedure','accuracy','macro_precision','macro_recall','macro_f1')},flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=ROOT/'results');p.add_argument('--jobs',type=int,default=4)
    args=p.parse_args()
    with parallel_config(backend='loky',inner_max_num_threads=1):run(args)
