#!/usr/bin/env python3
"""Audit an existing benchmark and run a fixed participant-transfer stress test."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import platform
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from joblib import Parallel, delayed, parallel_config
from sklearn.impute import SimpleImputer
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import StandardScaler

LABELS = np.arange(1, 9)


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False))


def metrics(y, predicted):
    cm = confusion_matrix(y, predicted, labels=LABELS)
    tp = cm.diagonal()
    support = cm.sum(axis=1)
    predicted_support = cm.sum(axis=0)
    recall = np.divide(tp, support, out=np.zeros(8), where=support != 0)
    precision = np.divide(tp, predicted_support, out=np.zeros(8), where=predicted_support != 0)
    f1 = np.divide(2*tp, support+predicted_support, out=np.zeros(8), where=support+predicted_support != 0)
    return dict(accuracy=float(tp.sum()/cm.sum()), macro_precision=float(precision.mean()),
                macro_recall=float(recall.mean()), macro_f1=float(f1.mean()), support=int(cm.sum()),
                per_class_recall=recall.tolist(), per_class_precision=precision.tolist(),
                per_class_f1=f1.tolist(), class_support=support.tolist(), confusion_counts=cm.tolist())


def raw_samples(meta, indices):
    # Reconstruction below confirms every inclusive range is a contiguous, real
    # source-sample sequence in exactly one participant/group/phase/position.
    return {(r.participant, i) for r in meta.iloc[indices].itertuples()
            for i in range(r.context_sample_start, r.context_sample_end+1)}


def checked_split(meta, train, test, participant_exclusion=False):
    assert set(meta.iloc[train].group_id).isdisjoint(meta.iloc[test].group_id)
    a, b = raw_samples(meta, train), raw_samples(meta, test)
    assert not a.intersection(b)
    assert set(meta.iloc[train].position_index) == set(LABELS)
    assert set(meta.iloc[test].position_index) == set(LABELS)
    if participant_exclusion:
        assert set(meta.iloc[train].participant).isdisjoint(meta.iloc[test].participant)
    return dict(training_windows=len(train), test_windows=len(test), overlapping_raw_samples=0)


def fit_predict(bench, candidate, features, train, test, labels, seed):
    tx, vx = bench.preprocess(features[candidate['variant']][train], features[candidate['variant']][test])
    model = bench.classifier(candidate, seed)
    model.fit(tx, labels[train])
    return model.predict(vx).astype(int)


def score_transfer(bench, candidate, prepared, outer_person):
    fold_results = []
    for inner_person, tx, y, vx, truth in prepared[candidate['variant']]:
        model = bench.classifier(candidate, 42+200000+1000*outer_person+10*inner_person)
        model.fit(tx, y)
        result = metrics(truth, model.predict(vx))
        fold_results.append(dict(inner_person=inner_person, accuracy=result['accuracy'],
                                 balanced_accuracy=result['macro_recall']))
    return dict(candidate_id=candidate['candidate_id'], folds=fold_results,
                mean_balanced_accuracy=float(np.mean([r['balanced_accuracy'] for r in fold_results])),
                mean_accuracy=float(np.mean([r['accuracy'] for r in fold_results])))


def run(args):
    started = time.time()
    source = args.benchmark
    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    if (out/'audit.json').exists():
        raise RuntimeError('Audit output exists; use a new directory to preserve the record.')
    bench = module(source/'benchmark.py', 'benchmark_validation')
    base = bench.import_baseline(source/'baseline_analysis.py')
    original_checker = module(source/'check_outputs.py', 'existing_checks')
    original_checker.run(source)
    tracked = [source/'benchmark.py', source/'baseline_analysis.py', source/'PLAN.md',
               *sorted((source/'data/processed').glob('subject_*.csv')),
               *sorted((source/'results').glob('*'))]
    before = {str(p): digest(p) for p in tracked if p.is_file()}
    meta, features, _ = bench.build_variants(base, source/'data/processed')
    saved_meta = pd.read_csv(source/'results/window_manifest.csv')
    pd.testing.assert_frame_equal(meta, saved_meta, check_dtype=False, atol=1e-8, rtol=0)
    print('Reconstructed all 2,378 decision windows and both feature variants.', flush=True)
    y = meta.position_index.to_numpy(int)
    held = meta.period.eq('Held posture').to_numpy()
    people = sorted(meta.participant.unique())
    settings = bench.candidates()
    inputs = []
    for pi, person in enumerate(people, 1):
        raw = pd.read_csv(source/f'data/processed/subject_{pi:02d}.csv')
        assert raw.sample_index.is_unique
        assert raw.elapsed_s.diff().dropna().gt(0).all()
        assert raw.device_time_ms.diff().dropna().eq(50).all()
        assert raw.phase.eq('hold').equals(raw.is_hold.eq(1))
        initial = raw.loc[raw.phase.eq('initial_baseline')]
        assert len(initial) > 0 and initial.set_id.eq(0).all()
        errors = []
        for sensor in range(1, 11):
            baseline = initial[f'r_s{sensor}_ohm'].median()
            expected = raw[f'r_s{sensor}_ohm']/baseline-1
            actual = raw[f'dr_s{sensor}']
            mask = np.isfinite(expected) & np.isfinite(actual)
            errors.append(float(np.max(np.abs(expected[mask]-actual[mask]))))
        indexed = raw.set_index('sample_index', drop=False)
        for row in meta.loc[meta.participant.eq(person)].itertuples():
            context = indexed.loc[row.context_sample_start:row.context_sample_end]
            assert len(context) == row.context_samples
            assert context.sample_index.diff().dropna().eq(1).all()
            assert context.rep.eq(row.rep).all() and context.set_id.eq(row.set_id).all()
            assert context.phase.eq(row.phase).all() and context.position_index.eq(row.position_index).all()
            assert row.context_sample_end == row.sample_end
            assert len(indexed.loc[row.sample_start:row.sample_end]) == 20
        in_scope = raw.loc[raw.set_id.between(1, 7)]
        windows = meta.loc[meta.participant.eq(person)]
        inputs.append(dict(participant=person, rows=len(raw), baseline_rows=len(initial),
                           baseline_host_elapsed_first_last=[float(initial.elapsed_s.iloc[0]),float(initial.elapsed_s.iloc[-1])],
                           baseline_nominal_sample_duration_s=len(initial)*0.05,
                           baseline_has_100_samples=bool(len(initial)==100),
                           protocol_rows=len(in_scope), decision_windows=len(windows),
                           trailing_incomplete_segment_samples=int(len(in_scope)-20*len(windows)),
                           baseline_normalization_max_abs_difference_by_sensor=errors,
                           groups=int(in_scope.groupby(['set_id','rep']).ngroups)))
    predictions = pd.read_csv(source/'results/outer_predictions.csv')
    search = pd.read_csv(source/'results/inner_search_scores.csv')
    selection = pd.read_csv(source/'results/fold_selections.csv')
    # Perturb only test data, and verify it cannot change learned preprocessing.
    small_train = features['original_1s'][held][:100].copy()
    small_test = features['original_1s'][held][100:110].copy()
    first_train, _ = bench.preprocess(small_train, small_test)
    second_train, _ = bench.preprocess(small_train, np.full_like(small_test, 1e12))
    np.testing.assert_array_equal(first_train, second_train)
    outer_audit, inner_audit, replays = [], [], []
    for person in people:
        person_mask = meta.participant.eq(person).to_numpy()
        for outer in range(1,6):
            train = np.flatnonzero(person_mask & held & meta.rep.ne(outer).to_numpy())
            test = np.flatnonzero(person_mask & meta.rep.eq(outer).to_numpy())
            outer_audit.append(dict(participant=person, outer_rep=outer, **checked_split(meta, train, test)))
            choice = selection.loc[selection.participant.eq(person) & selection.outer_rep.eq(outer) & selection.procedure.eq('Nested selected')].iloc[0]
            candidate = settings[int(choice.candidate_id)]
            for inner in sorted(set(meta.iloc[train].rep)):
                itrain = train[meta.iloc[train].rep.ne(inner).to_numpy()]
                valid = train[meta.iloc[train].rep.eq(inner).to_numpy()]
                inner_audit.append(dict(participant=person, outer_rep=outer, inner_rep=int(inner), **checked_split(meta, itrain, valid)))
                pred = fit_predict(bench, candidate, features, itrain, valid, y, 42+1000*outer+10*int(inner))
                value = metrics(y[valid], pred)
                logged = search.loc[search.participant.eq(person) & search.outer_rep.eq(outer) & search.inner_rep.eq(inner) & search.candidate_id.eq(candidate['candidate_id'])].iloc[0]
                np.testing.assert_allclose([value['accuracy'],value['macro_recall'],value['macro_f1']],
                                           [logged.accuracy,logged.balanced_accuracy,logged.macro_f1],rtol=0,atol=1e-12)
            for procedure, cand in [('Exact baseline',settings[0]), ('Nested selected',candidate)]:
                pred = fit_predict(bench, cand, features, train, test, y, 42+100000+1000*outer+3)
                saved = predictions.loc[predictions.participant.eq(person) & predictions.rep.eq(outer) & predictions.procedure.eq(procedure)].sort_values('window_id')
                np.testing.assert_array_equal(saved.window_id.to_numpy(), meta.iloc[test].window_id.to_numpy())
                np.testing.assert_array_equal(saved.predicted_position.to_numpy(),pred)
                replays.append(dict(participant=person, outer_rep=outer, procedure=procedure,
                                    predictions=len(pred), mismatches=0, candidate_id=cand['candidate_id']))
            print(f'Replayed {person}, outer {outer}: selected inner scores and both outer predictions match.', flush=True)
    metric_report=[]
    for procedure in ['Exact baseline','Nested selected']:
        df = predictions.loc[predictions.procedure.eq(procedure) & predictions.period.eq('Held posture')]
        for person, d in [('All',df),*list(df.groupby('participant'))]:
            metric_report.append(dict(procedure=procedure, participant=person,
                                      **metrics(d.position_index, d.predicted_position)))
    main_metrics = pd.read_csv(source.parent/'tshirt_metrics_manuscript_20260918/assets/classification_metrics.csv')
    for row in main_metrics.itertuples():
        participant = row.participant if row.participant == 'All' else f'S{int(row.participant[1:])}'
        recomputed = next(r for r in metric_report if r['procedure']==row.procedure and r['participant']==participant)
        np.testing.assert_allclose([row.precision_macro,row.recall_macro,row.f1_macro,row.accuracy],
                                   [recomputed['macro_precision'],recomputed['macro_recall'],recomputed['macro_f1'],recomputed['accuracy']],
                                   rtol=0,atol=1e-12)
    audit = dict(input_checks=inputs, outer_split_checks=outer_audit, inner_split_checks=inner_audit,
                 selected_inner_fits_reproduced=60, outer_fits_reproduced=replays,
                 manuscript_metric_rows_verified=len(main_metrics),
                 original_metrics_recounted=metric_report, test_data_perturbation_preprocessing_check='pass',
                 verified_archive_sha256=before, versions=dict(python=platform.python_version(),numpy=np.__version__,
                 pandas=pd.__version__,sklearn=sklearn.__version__,joblib=joblib.__version__),
                 validation_plan_sha256=digest(Path(__file__).with_name('PLAN.md')),
                 validation_script_sha256=digest(__file__))
    save(out/'audit.json',audit)
    print('Reproduction audit passed. Starting nested leave-one-participant-out stress test.', flush=True)
    loso_search, loso_predictions, choices = [], [], []
    for outer_person, person in enumerate(people,1):
        train = np.flatnonzero(held & meta.participant.ne(person).to_numpy())
        test = np.flatnonzero(held & meta.participant.eq(person).to_numpy())
        checked_split(meta,train,test,participant_exclusion=True)
        prepared={v:[] for v in features}
        for inner_person, valid_person in enumerate(people,1):
            if valid_person==person:
                continue
            itrain=train[meta.iloc[train].participant.ne(valid_person).to_numpy()]
            valid=train[meta.iloc[train].participant.eq(valid_person).to_numpy()]
            checked_split(meta,itrain,valid,participant_exclusion=True)
            for variant,x in features.items():
                tx,vx=bench.preprocess(x[itrain],x[valid])
                prepared[variant].append((inner_person,tx,y[itrain],vx,y[valid]))
        results=Parallel(n_jobs=args.jobs)(delayed(score_transfer)(bench,c,prepared,outer_person) for c in settings)
        ranked=sorted(results,key=lambda r:(-r['mean_balanced_accuracy'],-r['mean_accuracy'],r['candidate_id']))
        winner=settings[ranked[0]['candidate_id']]
        loso_search.append(dict(test_participant=person,search=results))
        choices.append(dict(test_participant=person,candidate=winner,
                            inner_mean_balanced_accuracy=ranked[0]['mean_balanced_accuracy']))
        for procedure,candidate in [('LOSO baseline',settings[0]),('LOSO inner-selected',winner)]:
            pred=fit_predict(bench,candidate,features,train,test,y,42+300000+1000*outer_person+3)
            loso_predictions.extend(dict(procedure=procedure,participant=person,window_id=int(w),
                                         prompted=int(t),predicted=int(p))
                                    for w,t,p in zip(meta.iloc[test].window_id,y[test],pred))
        save(out/'transfer_search.json',loso_search)
        save(out/'transfer_predictions.json',loso_predictions)
        save(out/'transfer_selections.json',choices)
        print(f'Completed excluded participant {person}.',flush=True)
    frame=pd.DataFrame(loso_predictions)
    results=[]
    for procedure,df in frame.groupby('procedure'):
        assert df.window_id.nunique()==2032 and len(df)==2032
        for person,d in [('All',df),*list(df.groupby('participant'))]:
            results.append(dict(procedure=procedure,participant=person,**metrics(d.prompted,d.predicted)))
    save(out/'transfer_metrics.json',results)
    assert before=={str(p):digest(p) for p in tracked if p.is_file()}
    audit.update(source_and_results_unchanged=True,elapsed_seconds=time.time()-started,
                 transfer_inner_fits=384,transfer_outer_fits=6)
    save(out/'audit.json',audit)
    for r in results:
        print({k:r[k] for k in ['procedure','participant','macro_precision','macro_recall','macro_f1','accuracy','support']},flush=True)
    print(f'Completed validation, elapsed {time.time()-started:.1f}s. Original inputs and outputs unchanged.',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--benchmark',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--jobs',type=int,default=4)
    args=parser.parse_args()
    with parallel_config(backend='loky',inner_max_num_threads=1):
        run(args)
