#!/usr/bin/env python3
"""Independent metric checks, deterministic replays and a complete report."""
import json
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, confusion_matrix, precision_recall_fscore_support
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

import joint_benchmark as joint

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'results'
METRICS = ['macro_precision', 'macro_recall', 'macro_f1', 'accuracy']


def read(name):
    return json.loads((OUT/name).read_text())


def independent_metric(d):
    p, r, f, support = precision_recall_fscore_support(
        d.position_index, d.predicted_position, labels=range(1, 9), zero_division=0)
    return dict(macro_precision=float(p.mean()), macro_recall=float(r.mean()),
                macro_f1=float(f.mean()), accuracy=float(accuracy_score(d.position_index, d.predicted_position)),
                support=len(d), class_precision=p.tolist(), class_recall=r.tolist(),
                class_f1=f.tolist(), class_support=support.tolist(),
                confusion_counts=confusion_matrix(d.position_index, d.predicted_position, labels=range(1,9)).tolist())


def table(rows, with_person=False):
    heading = ['Procedure'] + (['Participant'] if with_person else []) + ['Macro precision', 'Balanced accuracy', 'Macro-F1', 'Accuracy']
    lines = ['| '+' | '.join(heading)+' |', '|'+'---|'*len(heading)]
    for r in rows:
        cells = [r['procedure']] + ([r['participant']] if with_person else [])
        cells += [f'{100*r[k]:.2f}%' for k in METRICS]
        lines.append('| '+' | '.join(cells)+' |')
    return '\n'.join(lines)


def run():
    manifest = read('manifest.json')
    assert manifest['completed'] and manifest['sources_unchanged']
    assert manifest['script_sha256'] == joint.digest(ROOT/'joint_benchmark.py')
    assert manifest['plan_sha256'] == joint.digest(ROOT/'PLAN.md')
    assert manifest['source_hashes'] == {p:joint.digest(p) for p in manifest['source_hashes']}
    predictions = pd.DataFrame(read('outer_predictions.json'))
    selections = read('selections.json')
    logged_metrics = read('metrics.json')
    checks = read('split_audit.json')
    assert len(predictions) == 11890 and len(selections) == 75 and len(checks) == 75
    assert all(r['overlapping_raw_samples'] == 0 for r in checks)
    bench, base, audit = joint.load_dependencies()
    meta, features, masks = joint.build_features(bench, base)
    assert masks == manifest['mask_audit']
    for _, d in predictions.groupby('procedure'):
        assert len(d) == 2378 and d.window_id.nunique() == 2378
        pd.testing.assert_frame_equal(meta, d.sort_values('window_id')[meta.columns].reset_index(drop=True),
                                      check_dtype=False, atol=1e-8, rtol=0)
    for r in logged_metrics:
        d = predictions.loc[predictions.procedure.eq(r['procedure']) & predictions.period.eq(r['period'])]
        if r['participant'] != 'All':
            d = d.loc[d.participant.eq(r['participant'])]
        actual = independent_metric(d)
        for key in actual:
            np.testing.assert_allclose(actual[key], r[key], atol=1e-12, rtol=0)
    # Recalculate selected feature columns with separate NumPy expressions.
    spot_checks = 0
    for person in range(1,4):
        raw = pd.read_csv(joint.SOURCE/f'data/processed/subject_{person:02d}.csv').set_index('sample_index')
        rows = meta.loc[meta.participant.eq(f'S{person}')].iloc[::37]
        for row in rows.itertuples():
            for context, start in [(20,row.sample_start),(40,row.context_sample_start)]:
                window = raw.loc[start:row.sample_end]
                for s in (1,7,10):
                    good = (window[f'qc_high_adc_s{s}'].eq(0) & window[f'qc_low_adc_s{s}'].eq(0)
                            & np.isfinite(window[f'dr_s{s}']))
                    for kind,col in [('res',f'dr_s{s}'),('adc',f'adc_s{s}')]:
                        v = window.loc[good,col].to_numpy(float)
                        if len(v):
                            wanted = [np.sum(v)/len(v), np.sqrt(np.sum((v-v.mean())**2)/(len(v)-1)) if len(v)>1 else 0,
                                      np.median(v), np.quantile(v,.75)-np.quantile(v,.25),
                                      np.min(v),np.max(v),(v[-1]-v[0])/max(1,len(v)-1)]
                        else:
                            wanted = [np.nan]*7
                        np.testing.assert_allclose(features[f'{kind}{context}'][row.window_id,(s-1)*7:s*7],
                                                   wanted, atol=1e-10, rtol=1e-12, equal_nan=True)
                        spot_checks += 1
    replayed_outer, replayed_inner, score_records = 0, 0, 0
    y = meta.position_index.to_numpy(int)
    for person in sorted(meta.participant.unique()):
        for outer in range(1,6):
            block = read(f'search_{person}_rep{outer}.json')
            assert len(block['screening']) == 756 and len(block['refinement']) == 672
            assert len(block['greedy_paths']) == 12
            for pool in [block['screening'],block['refinement']]:
                assert len({(r['candidate']['candidate_id'],r['standing_multiplier']) for r in pool}) == len(pool)
                for r in pool:
                    assert len(r['folds']) == 4
                    assert {f['inner_rep'] for f in r['folds']} == set(range(1,6))-{outer}
                    np.testing.assert_allclose([r['mean_macro_f1'],r['mean_accuracy'],r['mean_balanced_accuracy']],
                        [np.mean([f[k] for f in r['folds']]) for k in ['macro_f1','accuracy','macro_recall']],atol=1e-12,rtol=0)
                    score_records += 4
            for rep in joint.REPS:
                prior = []
                for count in (1,2,3):
                    pool = [r for r in block['screening'] if r['candidate']['representation']==rep
                            and len(r['candidate']['sensors'])==count]
                    assert len(pool)==(11-count)*7
                    expected = {tuple(sorted(prior+[s])) for s in range(1,11) if s not in prior}
                    assert {tuple(r['candidate']['sensors']) for r in pool} == expected
                    best = min(pool,key=joint.rank)
                    chosen = next(p['choice'] for p in block['greedy_paths'] if p['representation']==rep and p['sensor_count']==count)
                    assert best == chosen
                    prior = best['candidate']['sensors']
            train,test,prepared,new_checks = joint.prepare(bench,audit,meta,features,person,outer)
            here = [s for s in selections if s['participant']==person and s['outer_rep']==outer]
            cache = {}
            for choice in here:
                count = len(choice['candidate']['sensors'])
                pool = block['refinement'] if choice['procedure']==joint.PRIMARY else [r for r in block['refinement'] if len(r['candidate']['sensors'])==count]
                winner = min(pool,key=joint.rank)
                assert winner == {k:choice[k] for k in winner}
                c,alpha = choice['candidate'],choice['standing_multiplier']
                key = (c['candidate_id'],alpha)
                if key not in cache:
                    # Fit preprocessing directly here rather than reuse its helper.
                    x = features[joint.feature_key(c)][:,joint.columns(c)]
                    imputer = SimpleImputer(strategy='median',keep_empty_features=True)
                    scale = StandardScaler()
                    tx = scale.fit_transform(imputer.fit_transform(x[train]))
                    vx = scale.transform(imputer.transform(x[test]))
                    model = joint.estimator(c,42+100000+1000*outer+3)
                    model.fit(tx,y[train])
                    p = model.predict_proba(vx)
                    p[:,0] *= alpha
                    cache[key] = model.classes_[p.argmax(1)]
                    replayed_outer += 1
                saved = predictions.loc[predictions.participant.eq(person) & predictions.rep.eq(outer)
                                        & predictions.procedure.eq(choice['procedure'])].sort_values('window_id')
                np.testing.assert_array_equal(saved.predicted_position,cache[key])
            primary = next(s for s in here if s['procedure']==joint.PRIMARY)
            # Every inner fold of the selected primary candidate is replayed.
            replay = joint.fit_inner(primary['candidate'],prepared,outer)
            target = [r for r in block['refinement'] if r['candidate']['candidate_id']==primary['candidate']['candidate_id']]
            assert replay == target
            replayed_inner += 4
            print(f'Checked {person}, repetition {outer}: selections and predictions replay exactly.',flush=True)
    assert score_records == 85680
    assert manifest['source_hashes'] == {p:joint.digest(p) for p in manifest['source_hashes']}
    verification = dict(all_checks_passed=True, grouped_splits=75, selections_checked=75,
                        predictions_checked=11890, inner_weight_fold_scores_checked=score_records,
                        unique_outer_fits_replayed=replayed_outer, inner_fits_replayed=replayed_inner,
                        independently_checked_feature_vectors=spot_checks, source_hashes_unchanged=True)
    joint.save(OUT/'verification.json',verification)
    previous = pd.DataFrame(json.loads((joint.PREVIOUS/'results/outer_predictions.json').read_text()))
    previous = previous.loc[previous.procedure.eq('Refined macro-F1 + standing weight')].copy()
    previous['procedure'] = 'Previous refined full-array model'
    pd.testing.assert_frame_equal(meta,previous.sort_values('window_id')[meta.columns].reset_index(drop=True),
                                  check_dtype=False,atol=1e-8,rtol=0)
    old_held = previous.loc[previous.period.eq('Held posture')]
    before = dict(procedure='Previous refined full-array model',participant='All',**independent_metric(old_held))
    order = [joint.PRIMARY]+[f'{n}-sensor selection' for n in (1,2,3,10)]
    rows = [before]+[next(r for r in logged_metrics if r['procedure']==name and r['participant']=='All'
                         and r['period']=='Held posture') for name in order]
    after = rows[1]
    primary_selections = [s for s in selections if s['procedure']==joint.PRIMARY]
    participant_rows, fold_changes = [], []
    for person in sorted(meta.participant.unique()):
        old = independent_metric(old_held.loc[old_held.participant.eq(person)])
        participant_rows.append(dict(procedure='Previous',participant=person,**old))
        new = next(r for r in logged_metrics if r['procedure']==joint.PRIMARY and r['participant']==person and r['period']=='Held posture')
        participant_rows.append(dict(new,procedure='Joint selection'))
        for outer in range(1,6):
            a = old_held.loc[old_held.participant.eq(person) & old_held.rep.eq(outer)]
            b = predictions.loc[predictions.procedure.eq(joint.PRIMARY) & predictions.period.eq('Held posture')
                                & predictions.participant.eq(person) & predictions.rep.eq(outer)]
            am,bm = independent_metric(a),independent_metric(b)
            fold_changes.append(dict(participant=person,outer_rep=outer,**{k:bm[k]-am[k] for k in METRICS}))
    class_lines = ['| Posture | Support | Previous recall | New recall | New precision | New F1 |','|---|---:|---:|---:|---:|---:|']
    for i in range(8):
        class_lines.append(f"| {base.POSITION_NAMES[i+1]} | {after['class_support'][i]} | {100*before['class_recall'][i]:.2f}% | {100*after['class_recall'][i]:.2f}% | {100*after['class_precision'][i]:.2f}% | {100*after['class_f1'][i]:.2f}% |")
    choice_lines = ['| Participant | Outer repetition | Sensors | Representation | Context samples | Family | Leaf size | Max features | Class weight | Standing score multiplier |','|---|---:|---|---|---:|---|---:|---|---|---:|']
    for s in primary_selections:
        c = s['candidate']
        choice_lines.append(f"| {s['participant']} | {s['outer_rep']} | {', '.join('S'+str(x) for x in c['sensors'])} | {c['representation']} | {c['context']} | {c['family']} | {c['min_samples_leaf']} | {c['max_features']} | {c['class_weight'] or 'none'} | {s['standing_multiplier']} |")
    sensor_counts = Counter(len(s['candidate']['sensors']) for s in primary_selections)
    representations = Counter(s['candidate']['representation'] for s in primary_selections)
    stability = []
    for n in (1,2,3,10):
        chosen = [s for s in selections if s['procedure']==f'{n}-sensor selection']
        combinations = Counter(tuple(s['candidate']['sensors']) for s in chosen)
        stability.append(dict(sensor_count=n,combinations=[dict(sensors=list(k),outer_folds=v) for k,v in combinations.most_common()],
                              inclusion_counts={str(sensor):sum(sensor in s['candidate']['sensors'] for s in chosen) for sensor in range(1,11)}))
    transition = next(r for r in logged_metrics if r['procedure']==joint.PRIMARY and r['participant']=='All' and r['period']=='Transition')
    gains = ', '.join(f'{100*(after[k]-before[k]):+.2f} percentage points in {label}' for k,label in
                     [('macro_f1','macro-F1'),('macro_recall','balanced accuracy'),('accuracy','accuracy'),('macro_precision','macro precision')])
    direction = 'increased' if after['macro_f1'] > before['macro_f1'] else 'decreased' if after['macro_f1'] < before['macro_f1'] else 'did not change'
    report = f'''# Software-only sensor and feature benchmark

The prespecified joint-selection procedure achieved **{100*after['macro_f1']:.2f}% macro-F1, {100*after['macro_recall']:.2f}% balanced accuracy, {100*after['accuracy']:.2f}% accuracy and {100*after['macro_precision']:.2f}% macro precision** on the same 2,032 held-posture windows. Macro-F1 {direction} relative to the previous refined full-array procedure. Differences were {gains}.

These are internally checked exploratory results from repeatedly used recordings. They are not independent-session or external validation. No results have been added to the manuscript or GitHub.

## All prespecified procedures

{table(rows)}

Balanced accuracy is macro recall over all eight classes. All rows use identical decisions and labels, with no new data exclusions. The primary procedure chooses among one-, two-, three- and ten-sensor candidates using only inner training-fold validation. The count-specific rows are separate secondary procedures, not interchangeable primary results. Sensor identities can differ by participant and outer fold. The previous model used a broader tree-hyperparameter grid; differences cannot be attributed solely to one feature change.

## Participant results

{table(participant_rows,True)}

The joint procedure had higher macro-F1 in {sum(d['macro_f1']>0 for d in fold_changes)} of the 15 participant/repetition test folds. Folds share training data and are not independent experimental replications. No significance test or population confidence interval is claimed.

## Posture results

{chr(10).join(class_lines)}

## Method

- Participant-specific five-fold outer and four-fold inner repetition validation. Each fold holds out the same repetition number across the seven stored movement blocks. Complete stored set/repetition groups are kept together.
- Compare normalized resistance and ADC counts. Both use exactly the same original QC masks. The original seven statistics are compared with five obtained by dropping minimum and maximum. The reduced set retains mean, standard deviation and endpoint change, which are not fully outlier-resistant.
- Sensor screening is greedy within each representation: ten singles, then nine pair extensions and eight triplet extensions. Screening uses 64-tree ExtraTrees and the existing up-to-40-sample context. It does not exhaust all possible pairs/triplets or prove an optimal subset.
- Refine the four representations at each sensor count using 20- and up-to-40-sample contexts and three 128-tree configurations: ExtraTrees leaf 1/sqrt/no class weighting; ExtraTrees leaf 2/0.5/balanced weighting; RandomForest leaf 2/sqrt/balanced weighting.
- Select by mean inner macro-F1, then accuracy, balanced accuracy, fewer sensors for cross-count ties, standing-weight proximity to one, candidate ID and standing weight. The standing-class score multiplier is selected from 0.5, 0.75, 1, 1.25, 1.5, 2 and 3. It is not probability calibration or an abstention threshold.
- Training-fold median imputation and standardization are fitted independently for each inner/outer split. No protocol labels, elapsed times, participant identifiers or repetition identifiers are classifier inputs. Known phase/position boundaries still delimit the feature contexts, as in the previous analysis.
- All eight classes remain included. No smoothing, peak clipping, manually removed bursts, synthetic examples, boundary trimming or changed labels were introduced.

## Primary selections

Sensor-count frequency across the 15 outer folds: {dict(sorted(sensor_counts.items()))}. Representation frequency: {dict(representations)}. Representation codes use `res` for normalized resistance, `adc` for ADC counts, and `7`/`5` for the feature count per sensor.

{chr(10).join(choice_lines)}

Full count-specific selection frequencies and all confusion matrices are retained in `results/comparison.json` and `results/metrics.json`. These are fold-specific procedures, not one final fitted deployment model.

## Transitions

The primary procedure agreed with the prompted destination label in {100*transition['accuracy']:.2f}% of the 346 transition windows. This is reported separately from held-posture performance because there is no independently measured instantaneous physical-posture ground truth during a transition. Transition windows were not used to choose models.

## Verification and limits

- Verified all 75 inner/outer group and feature-source sample separations, 75 selections and 11,890 predictions. Recomputed all reported metrics using independent scikit-learn metric functions.
- Checked {score_records:,} logged candidate/weight/fold scores, replayed {replayed_outer} unique selected outer fits and all four inner fits for each of the 15 primary selections. All predictions and selected inner scores reproduced exactly.
- Independently checked {spot_checks} feature vectors against original sample ranges. Original CSVs and prior scripts/results remained byte-for-byte unchanged. Scientific spreadsheet-skill guidance informed these provenance and independent-calculation checks.
- This round used 6,480 screening fits and 5,760 refinement fits. Runtime before verification was {manifest['elapsed_seconds']/60:.1f} minutes. The fixed plan was saved before running and was not changed after examining outer scores.
- Only three within-recording participant datasets are available. Repeated algorithm development has reused previously inspected outer data. Nested training-only selection in this round does not remove development-set reuse or establish independent-session performance.
- Fixed-order blocks can confound posture with garment history and time even though these are not explicit predictors. Stored repetition groups do not prove independence of complete physical movement cycles. Initial calibration and known protocol boundaries are retained assumptions.
- ADC-feature comparisons do not establish ESP32 calibration, resistance accuracy, hardware reliability, adhesion or durability. No measurements from another manuscript were introduced.

No experimental work, source-data edits, date/ethics changes, Overleaf changes or GitHub changes were performed.

## Reproduce

Use the package versions recorded in `results/manifest.json`. From this workspace, run:

```sh
MPLCONFIGDIR=/private/tmp/tshirt-joint-mpl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Library/Frameworks/Python.framework/Versions/3.14/bin/python3 outputs/tshirt_joint_benchmark_20260918/joint_benchmark.py --out /private/tmp/tshirt-joint-new-run --jobs 4
```

Use an output directory that does not already exist. The code reads the preserved sibling `tshirt_algorithm_benchmark_20260918` package and `tshirt_model_validation_20260918/validate.py`. `verify_and_report.py` verifies the delivered `results/` directory and regenerates this report. The previous refined results remain in `tshirt_finetuning_20260918`.
'''
    (ROOT/'RESULTS.md').write_text(report)
    joint.save(OUT/'comparison.json',dict(procedures=rows,participants=participant_rows,fold_changes=fold_changes,
        count_specific_selection_stability=stability,primary_sensor_count_frequency=dict(sensor_counts),
        primary_representation_frequency=dict(representations)))
    print(json.dumps(verification,indent=2),flush=True)
    print(table(rows),flush=True)


if __name__=='__main__':
    run()
