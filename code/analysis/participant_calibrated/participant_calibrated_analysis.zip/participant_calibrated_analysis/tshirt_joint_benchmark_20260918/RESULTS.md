# Software-only sensor and feature benchmark

The prespecified joint-selection procedure achieved **68.25% macro-F1, 72.39% balanced accuracy, 67.37% accuracy and 65.22% macro precision** on the same 2,032 held-posture windows. Macro-F1 increased relative to the previous refined full-array procedure. Differences were +1.52 percentage points in macro-F1, -1.77 percentage points in balanced accuracy, +3.00 percentage points in accuracy, +3.23 percentage points in macro precision.

These are internally checked exploratory results from repeatedly used recordings. They are not independent-session or external validation. No results have been added to the manuscript or GitHub.

## All prespecified procedures

| Procedure | Macro precision | Balanced accuracy | Macro-F1 | Accuracy |
|---|---|---|---|---|
| Previous refined full-array model | 61.98% | 74.17% | 66.74% | 64.37% |
| Joint training-only selection | 65.22% | 72.39% | 68.25% | 67.37% |
| 1-sensor selection | 33.79% | 37.95% | 35.30% | 40.90% |
| 2-sensor selection | 46.43% | 54.66% | 49.67% | 50.39% |
| 3-sensor selection | 50.74% | 61.08% | 54.69% | 53.54% |
| 10-sensor selection | 65.22% | 72.39% | 68.25% | 67.37% |

Balanced accuracy is macro recall over all eight classes. All rows use identical decisions and labels, with no new data exclusions. The primary procedure chooses among one-, two-, three- and ten-sensor candidates using only inner training-fold validation. The count-specific rows are separate secondary procedures, not interchangeable primary results. Sensor identities can differ by participant and outer fold. The previous model used a broader tree-hyperparameter grid; differences cannot be attributed solely to one feature change.

## Participant results

| Procedure | Participant | Macro precision | Balanced accuracy | Macro-F1 | Accuracy |
|---|---|---|---|---|---|
| Previous | S1 | 64.88% | 72.55% | 67.69% | 67.50% |
| Joint selection | S1 | 65.93% | 70.83% | 67.93% | 67.95% |
| Previous | S2 | 64.48% | 78.37% | 69.84% | 66.81% |
| Joint selection | S2 | 68.86% | 77.05% | 72.33% | 71.24% |
| Previous | S3 | 57.38% | 71.61% | 62.58% | 58.79% |
| Joint selection | S3 | 61.06% | 69.36% | 64.11% | 62.92% |

The joint procedure had higher macro-F1 in 9 of the 15 participant/repetition test folds. Folds share training data and are not independent experimental replications. No significance test or population confidence interval is claimed.

## Posture results

| Posture | Support | Previous recall | New recall | New precision | New F1 |
|---|---:|---:|---:|---:|---:|
| Standing straight | 1017 | 51.43% | 60.77% | 72.79% | 66.24% |
| Left arm raise | 143 | 88.81% | 79.02% | 70.19% | 74.34% |
| Right arm raise | 143 | 79.72% | 77.62% | 60.00% | 67.68% |
| Left shoulder touch and twist | 144 | 71.53% | 68.75% | 50.00% | 57.89% |
| Right shoulder touch and twist | 147 | 74.83% | 73.47% | 62.79% | 67.71% |
| Both arms raise | 147 | 72.79% | 72.79% | 75.89% | 74.31% |
| Forward bend | 144 | 90.97% | 89.58% | 77.25% | 82.96% |
| Sitting | 147 | 63.27% | 57.14% | 52.83% | 54.90% |

## Method

- Participant-specific five-fold outer and four-fold inner repetition validation. Each fold holds out the same repetition number across the seven stored movement blocks. Complete stored set/repetition groups are kept together.
- Compare normalized resistance and ADC counts. Both use exactly the same original QC masks. The original seven statistics are compared with five obtained by dropping minimum and maximum. The reduced set retains mean, standard deviation and endpoint change, which are not fully outlier-resistant.
- Sensor screening is greedy within each representation: ten singles, then nine pair extensions and eight triplet extensions. Screening uses 64-tree ExtraTrees and the existing up-to-40-sample context. It does not exhaust all possible pairs/triplets or prove an optimal subset.
- Refine the four representations at each sensor count using 20- and up-to-40-sample contexts and three 128-tree configurations: ExtraTrees leaf 1/sqrt/no class weighting; ExtraTrees leaf 2/0.5/balanced weighting; RandomForest leaf 2/sqrt/balanced weighting.
- Select by mean inner macro-F1, then accuracy, balanced accuracy, fewer sensors for cross-count ties, standing-weight proximity to one, candidate ID and standing weight. The standing-class score multiplier is selected from 0.5, 0.75, 1, 1.25, 1.5, 2 and 3. It is not probability calibration or an abstention threshold.
- Training-fold median imputation and standardization are fitted independently for each inner/outer split. No protocol labels, elapsed times, participant identifiers or repetition identifiers are classifier inputs. Known phase/position boundaries still delimit the feature contexts, as in the previous analysis.
- All eight classes remain included. No smoothing, peak clipping, manually removed bursts, synthetic examples, boundary trimming or changed labels were introduced.

## Primary selections

Sensor-count frequency across the 15 outer folds: {10: 15}. Representation frequency: {'adc7': 3, 'res7': 2, 'res5': 4, 'adc5': 6}. Representation codes use `res` for normalized resistance, `adc` for ADC counts, and `7`/`5` for the feature count per sensor.

| Participant | Outer repetition | Sensors | Representation | Context samples | Family | Leaf size | Max features | Class weight | Standing score multiplier |
|---|---:|---|---|---:|---|---:|---|---|---:|
| S1 | 1 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | adc7 | 40 | ExtraTrees | 1 | sqrt | none | 0.75 |
| S1 | 2 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | res7 | 40 | ExtraTrees | 1 | sqrt | none | 0.5 |
| S1 | 3 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | res5 | 40 | ExtraTrees | 1 | sqrt | none | 0.5 |
| S1 | 4 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | res5 | 40 | ExtraTrees | 1 | sqrt | none | 0.5 |
| S1 | 5 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | adc7 | 40 | ExtraTrees | 1 | sqrt | none | 0.5 |
| S2 | 1 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | adc5 | 40 | ExtraTrees | 2 | 0.5 | balanced | 0.75 |
| S2 | 2 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | adc5 | 40 | ExtraTrees | 1 | sqrt | none | 0.5 |
| S2 | 3 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | adc5 | 40 | ExtraTrees | 1 | sqrt | none | 0.5 |
| S2 | 4 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | adc5 | 40 | ExtraTrees | 1 | sqrt | none | 0.5 |
| S2 | 5 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | adc5 | 40 | ExtraTrees | 1 | sqrt | none | 0.5 |
| S3 | 1 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | adc7 | 20 | ExtraTrees | 1 | sqrt | none | 0.5 |
| S3 | 2 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | res5 | 40 | ExtraTrees | 2 | 0.5 | balanced | 0.5 |
| S3 | 3 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | res7 | 40 | ExtraTrees | 1 | sqrt | none | 0.5 |
| S3 | 4 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | adc5 | 40 | ExtraTrees | 1 | sqrt | none | 0.5 |
| S3 | 5 | S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 | res5 | 40 | ExtraTrees | 1 | sqrt | none | 0.5 |

Full count-specific selection frequencies and all confusion matrices are retained in `results/comparison.json` and `results/metrics.json`. These are fold-specific procedures, not one final fitted deployment model.

## Transitions

The primary procedure agreed with the prompted destination label in 18.21% of the 346 transition windows. This is reported separately from held-posture performance because there is no independently measured instantaneous physical-posture ground truth during a transition. Transition windows were not used to choose models.

## Verification and limits

- Verified all 75 inner/outer group and feature-source sample separations, 75 selections and 11,890 predictions. Recomputed all reported metrics using independent scikit-learn metric functions.
- Checked 85,680 logged candidate/weight/fold scores, replayed 60 unique selected outer fits and all four inner fits for each of the 15 primary selections. All predictions and selected inner scores reproduced exactly.
- Independently checked 792 feature vectors against original sample ranges. Original CSVs and prior scripts/results remained byte-for-byte unchanged. Scientific spreadsheet-skill guidance informed these provenance and independent-calculation checks.
- This round used 6,480 screening fits and 5,760 refinement fits. Runtime before verification was 14.7 minutes. The fixed plan was saved before running and was not changed after examining outer scores.
- Only three within-recording participant datasets are available. Repeated algorithm development has reused previously inspected outer data. Nested training-only selection in this round does not remove development-set reuse or establish independent-session performance.
- Fixed-order blocks can confound posture with garment history and time even though these are not explicit predictors. Stored repetition groups do not prove independence of complete physical movement cycles. Initial calibration and known protocol boundaries are retained assumptions.
- ADC-feature comparisons do not establish ESP32 calibration, resistance accuracy, hardware reliability, adhesion or durability. No measurements from another manuscript were introduced.

No experimental work, source-data edits, date/ethics changes, Overleaf changes or GitHub changes were performed.

## Reproduce

Use the package versions recorded in `results/manifest.json`. From this workspace, run:

```sh
MPLCONFIGDIR=/private/tmp/tshirt-joint-mpl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Library/Frameworks/Python.framework/Versions/3.14/bin/python3 outputs/tshirt_joint_benchmark_20260918/joint_benchmark.py --out /private/tmp/tshirt-joint-new-run --jobs 4
```

Use an output directory that does not already exist. The code reads the preserved sibling `tshirt_algorithm_benchmark_20260918` package and `tshirt_model_validation_20260918/validate.py`. `verify_and_report.py` verifies the delivered `results/` directory and regenerates this report. The previous refined results remain in `tshirt_finetuning_20260918`.
