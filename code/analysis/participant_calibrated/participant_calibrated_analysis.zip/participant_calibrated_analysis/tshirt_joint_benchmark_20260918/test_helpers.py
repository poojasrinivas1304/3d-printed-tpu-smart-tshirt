"""Small, outcome-independent checks of feature indexing and metric helpers."""
import numpy as np
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
import joint_benchmark as j


def run():
    y = np.tile(np.arange(1,9),8)
    pred = y.copy()
    pred[::3] = 1
    pred[::7] = 4
    r = j.metric(y,pred)
    p,re,f,_ = precision_recall_fscore_support(y,pred,labels=np.arange(1,9),average='macro',zero_division=0)
    np.testing.assert_allclose([r['macro_precision'],r['macro_recall'],r['macro_f1'],r['accuracy']],
                              [p,re,f,accuracy_score(y,pred)],rtol=0,atol=1e-12)
    for rep in j.REPS:
        c = j.candidate(rep,[2,5,10],40,1)
        expected_stats = list(range(7)) if rep.endswith('7') else [0,1,2,3,6]
        expected = [7*(s-1)+v for s in [2,5,10] for v in expected_stats]
        np.testing.assert_array_equal(j.columns(c),expected)
        assert len(set(j.columns(c))) == len(expected)
    probabilities = np.full((2,8),0.01)
    probabilities[0,0],probabilities[0,1] = .4,.5
    probabilities[1,0],probabilities[1,7] = .6,.3
    np.testing.assert_array_equal(j.decide(probabilities,1),[2,1])
    np.testing.assert_array_equal(j.decide(probabilities,2),[1,1])
    np.testing.assert_array_equal(j.decide(probabilities,.4),[2,8])
    np.testing.assert_allclose(probabilities[:,0],[.4,.6])
    bench,_,_ = j.load_dependencies()
    train = np.arange(280,dtype=float).reshape(4,70)
    train[0,5] = np.nan
    train[:,6] = np.nan
    valid = np.zeros((2,70))
    first_train,first_valid = bench.preprocess(train,valid)
    second_train,_ = bench.preprocess(train,np.full_like(valid,1e12))
    np.testing.assert_array_equal(first_train,second_train)
    cols = j.columns(j.candidate('res5',[1,4,7],40,1))
    narrow_train,narrow_valid = bench.preprocess(train[:,cols],valid[:,cols])
    np.testing.assert_allclose(first_train[:,cols],narrow_train)
    np.testing.assert_allclose(first_valid[:,cols],narrow_valid)
    print('PASS: independent metrics, feature indices, decision weighting and train-only columnwise preprocessing.')


if __name__=='__main__':
    run()
