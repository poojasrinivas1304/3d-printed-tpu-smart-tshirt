#!/usr/bin/env python3
"""Fixed, traceable software-only benchmark. See PLAN.md before use."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import math
import platform
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from joblib import Parallel, delayed, parallel_config
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.metrics import confusion_matrix

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'tshirt_algorithm_benchmark_20260918'
PREVIOUS = ROOT.parent / 'tshirt_finetuning_20260918'
REPS = ('res7', 'res5', 'adc7', 'adc5')
ALPHAS = (0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0)
LABELS = np.arange(1, 9)
PRIMARY = 'Joint training-only selection'


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, allow_nan=False))


def load_dependencies():
    bench = module(SOURCE / 'benchmark.py', 'joint_source_benchmark')
    base = bench.import_baseline(SOURCE / 'baseline_analysis.py')
    audit = module(ROOT.parent / 'tshirt_model_validation_20260918/validate.py', 'joint_split_audit')
    return bench, base, audit


def metric(y, pred):
    cm = confusion_matrix(y, pred, labels=LABELS)
    tp = np.diag(cm)
    actual, predicted = cm.sum(1), cm.sum(0)
    p = np.divide(tp, predicted, out=np.zeros(8), where=predicted != 0)
    r = np.divide(tp, actual, out=np.zeros(8), where=actual != 0)
    f = np.divide(2*tp, actual+predicted, out=np.zeros(8), where=actual+predicted != 0)
    return dict(macro_precision=float(p.mean()), macro_recall=float(r.mean()),
                macro_f1=float(f.mean()), accuracy=float(tp.sum()/cm.sum()),
                support=int(cm.sum()), class_support=actual.tolist(),
                class_precision=p.tolist(), class_recall=r.tolist(), class_f1=f.tolist(),
                confusion_counts=cm.tolist())


def build_features(bench, base):
    meta, old, _ = bench.build_variants(base, SOURCE / 'data/processed')
    saved = pd.read_csv(SOURCE / 'results/window_manifest.csv')
    pd.testing.assert_frame_equal(meta, saved, check_dtype=False, atol=1e-8, rtol=0)
    features = {'res20': old['original_1s'], 'res40': old['context_2s']}
    adc = {20: [], 40: []}
    mask_audit = []
    for i in range(1, 4):
        raw = pd.read_csv(SOURCE / f'data/processed/subject_{i:02d}.csv')
        valid = raw.set_id.between(1, 7)
        normalized = base._recording_normalized_group(raw.loc[valid])
        indexed = normalized.set_index('sample_index', drop=False)
        counts = []
        for s in range(1, 11):
            values = indexed[f'adc_s{s}'].to_numpy(float)
            common = np.isfinite(indexed[f'x_s{s}'].to_numpy(float))
            assert np.isfinite(values[common]).all()
            values[~common] = np.nan
            indexed[f'a_s{s}'] = values
            counts.append(int((~common).sum()))
        mask_audit.append(dict(participant=f'S{i}', invalid_samples_by_sensor=counts))
        for row in meta.loc[meta.participant.eq(f'S{i}')].itertuples():
            for context, start in [(20, row.sample_start), (40, row.context_sample_start)]:
                window = indexed.loc[start:row.sample_end]
                assert window.rep.eq(row.rep).all() and window.set_id.eq(row.set_id).all()
                assert window.phase.eq(row.phase).all() and window.position_index.eq(row.position_index).all()
                assert len(window) == (20 if context == 20 else row.context_samples)
                adc[context].append([v for s in range(1, 11)
                                     for v in bench.stats(window[f'a_s{s}'].to_numpy(float))])
    for c in (20, 40):
        features[f'adc{c}'] = np.asarray(adc[c])
        assert features[f'adc{c}'].shape == (2378, 70)
        np.testing.assert_array_equal(np.isnan(features[f'res{c}']), np.isnan(features[f'adc{c}']))
    return meta, features, mask_audit


def columns(candidate):
    which = list(range(7)) if candidate['representation'].endswith('7') else [0, 1, 2, 3, 6]
    return np.array([(s-1)*7+f for s in candidate['sensors'] for f in which])


def feature_key(candidate):
    return ('res' if candidate['representation'].startswith('res') else 'adc') + str(candidate['context'])


def candidate(rep, sensors, context, setting, screen=False):
    specs = [dict(family='ExtraTrees', min_samples_leaf=1, max_features='sqrt', class_weight=None),
             dict(family='ExtraTrees', min_samples_leaf=2, max_features=0.5, class_weight='balanced'),
             dict(family='RF', min_samples_leaf=2, max_features='sqrt', class_weight='balanced')]
    spec = specs[1 if screen else setting]
    prefix = 'screen' if screen else 'refine'
    ident = f'{prefix}_{rep}_{context}_m{setting}_s' + '-'.join(f'{s:02d}' for s in sensors)
    return dict(candidate_id=ident, representation=rep, sensors=list(sensors),
                context=context, n_estimators=64 if screen else 128, **spec)


def estimator(c, seed):
    cls = ExtraTreesClassifier if c['family'] == 'ExtraTrees' else RandomForestClassifier
    keys = ['n_estimators', 'min_samples_leaf', 'max_features', 'class_weight']
    return cls(**{k: c[k] for k in keys}, random_state=seed, n_jobs=1)


def decide(probs, alpha):
    weighted = probs.copy()
    weighted[:, 0] *= alpha
    return LABELS[weighted.argmax(axis=1)]


def fit_inner(c, prepared, outer):
    records = {alpha: [] for alpha in ALPHAS}
    cols = columns(c)
    for inner, tx, truth, vx, target in prepared[feature_key(c)]:
        model = estimator(c, 42+1000*outer+10*inner)
        model.fit(tx[:, cols], truth)
        assert np.array_equal(model.classes_, LABELS)
        probs = model.predict_proba(vx[:, cols])
        for alpha in ALPHAS:
            values = metric(target, decide(probs, alpha))
            records[alpha].append(dict(inner_rep=inner, **{k: values[k] for k in
                ['macro_precision', 'macro_recall', 'macro_f1', 'accuracy', 'support']}))
    return [dict(candidate=c, standing_multiplier=alpha, folds=folds,
                 mean_macro_f1=float(np.mean([r['macro_f1'] for r in folds])),
                 mean_accuracy=float(np.mean([r['accuracy'] for r in folds])),
                 mean_balanced_accuracy=float(np.mean([r['macro_recall'] for r in folds])))
            for alpha, folds in records.items()]


def rank(r):
    return (-r['mean_macro_f1'], -r['mean_accuracy'], -r['mean_balanced_accuracy'],
            len(r['candidate']['sensors']), abs(math.log(r['standing_multiplier'])),
            r['candidate']['candidate_id'], r['standing_multiplier'])


def fit_outer(c, alpha, features, train, test, y, outer, bench):
    x = features[feature_key(c)][:, columns(c)]
    tx, vx = bench.preprocess(x[train], x[test])
    model = estimator(c, 42+100000+1000*outer+3)
    model.fit(tx, y[train])
    assert np.array_equal(model.classes_, LABELS)
    return decide(model.predict_proba(vx), alpha)


def tracked_paths():
    paths = [p for p in SOURCE.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    paths += [p for p in (PREVIOUS / 'results').glob('*') if p.is_file()]
    paths += [PREVIOUS / 'refine.py', PREVIOUS / 'PLAN.md',
              ROOT.parent / 'tshirt_model_validation_20260918/validate.py']
    return sorted(paths)


def prepare(bench, audit, meta, features, person, outer):
    held = meta.period.eq('Held posture').to_numpy()
    pm = meta.participant.eq(person).to_numpy()
    train = np.flatnonzero(pm & held & meta.rep.ne(outer).to_numpy())
    test = np.flatnonzero(pm & meta.rep.eq(outer).to_numpy())
    checks = [dict(level='outer', **audit.checked_split(meta, train, test))]
    prepared = {key: [] for key in features}
    y = meta.position_index.to_numpy(int)
    for inner in sorted(set(meta.iloc[train].rep)):
        it = train[meta.iloc[train].rep.ne(inner).to_numpy()]
        iv = train[meta.iloc[train].rep.eq(inner).to_numpy()]
        checks.append(dict(level='inner', inner_rep=int(inner), **audit.checked_split(meta, it, iv)))
        for key, x in features.items():
            tx, vx = bench.preprocess(x[it], x[iv])
            prepared[key].append((int(inner), tx, y[it], vx, y[iv]))
    return train, test, prepared, checks


def run(args):
    started = time.time()
    args.out.mkdir(parents=True, exist_ok=False)
    bench, base, audit = load_dependencies()
    hashes = {str(p): digest(p) for p in tracked_paths()}
    meta, features, mask_audit = build_features(bench, base)
    y = meta.position_index.to_numpy(int)
    manifest = dict(plan_sha256=digest(ROOT/'PLAN.md'), script_sha256=digest(__file__),
                    source_hashes=hashes, mask_audit=mask_audit,
                    versions=dict(python=platform.python_version(), numpy=np.__version__, pandas=pd.__version__,
                                  sklearn=sklearn.__version__, joblib=joblib.__version__),
                    held_windows=2032, transition_windows=346, primary=PRIMARY,
                    expected_screen_fits=6480, expected_refinement_fits=5760,
                    exploratory_reused_recordings=True, completed=False)
    save(args.out/'manifest.json', manifest)
    print('Prepared unchanged windows and four representations. Fixed search starting.', flush=True)
    predictions, selections, audits = [], [], []
    for person in sorted(meta.participant.unique()):
        for outer in range(1, 6):
            train, test, prepared, checks = prepare(bench, audit, meta, features, person, outer)
            audits.extend([dict(participant=person, outer_rep=outer, **c) for c in checks])
            screens, paths, final_candidates = [], [], []
            selected = {rep: [] for rep in REPS}
            for count in (1, 2, 3):
                tasks = []
                for rep in REPS:
                    combos = [tuple(sorted(selected[rep]+[s])) for s in range(1, 11) if s not in selected[rep]]
                    tasks += [candidate(rep, combo, 40, 1, screen=True) for combo in combos]
                fitted = Parallel(n_jobs=args.jobs)(delayed(fit_inner)(c, prepared, outer) for c in tasks)
                records = [r for fit in fitted for r in fit]
                screens.extend(records)
                for rep in REPS:
                    winner = min((r for r in records if r['candidate']['representation'] == rep), key=rank)
                    selected[rep] = winner['candidate']['sensors']
                    paths.append(dict(sensor_count=count, representation=rep, choice=winner))
                    final_candidates += [candidate(rep, selected[rep], ctx, setting)
                                         for ctx in (20, 40) for setting in range(3)]
            final_candidates += [candidate(rep, tuple(range(1, 11)), ctx, setting)
                                 for rep in REPS for ctx in (20, 40) for setting in range(3)]
            assert len(screens) == 108*7 and len(final_candidates) == 96
            fitted = Parallel(n_jobs=args.jobs)(delayed(fit_inner)(c, prepared, outer) for c in final_candidates)
            results = [r for fit in fitted for r in fit]
            assert len(results) == 96*7
            choices = [(PRIMARY, min(results, key=rank))]
            choices += [(f'{n}-sensor selection', min((r for r in results if len(r['candidate']['sensors']) == n), key=rank))
                        for n in (1, 2, 3, 10)]
            cache = {}
            for procedure, choice in choices:
                c, alpha = choice['candidate'], choice['standing_multiplier']
                cache_key = (c['candidate_id'], alpha)
                if cache_key not in cache:
                    cache[cache_key] = fit_outer(c, alpha, features, train, test, y, outer, bench)
                part = meta.iloc[test].copy()
                part['predicted_position'] = cache[cache_key]
                part['procedure'] = procedure
                part['candidate_id'] = c['candidate_id']
                part['standing_multiplier'] = alpha
                part['sensor_count'] = len(c['sensors'])
                predictions.extend(part.to_dict('records'))
                selections.append(dict(participant=person, outer_rep=outer, procedure=procedure, **choice))
            save(args.out/f'search_{person}_rep{outer}.json', dict(participant=person, outer_rep=outer,
                    screening=screens, greedy_paths=paths, refinement=results))
            save(args.out/'selections.json', selections)
            save(args.out/'outer_predictions.json', predictions)
            save(args.out/'split_audit.json', audits)
            print(f'Finished {person}, outer repetition {outer}/5; elapsed {time.time()-started:.0f}s. Outer scores withheld.', flush=True)
    frame = pd.DataFrame(predictions)
    metrics = []
    for (procedure, period), group in frame.groupby(['procedure', 'period'], sort=False):
        for person, d in [('All', group), *list(group.groupby('participant'))]:
            metrics.append(dict(procedure=procedure, period=period, participant=person,
                                **metric(d.position_index, d.predicted_position)))
    for _, d in frame.groupby('procedure'):
        assert len(d) == 2378 and d.window_id.nunique() == 2378
        assert set(d.window_id) == set(meta.window_id)
        assert d.period.eq('Held posture').sum() == 2032
    assert hashes == {str(p): digest(p) for p in tracked_paths()}
    save(args.out/'metrics.json', metrics)
    manifest.update(completed=True, elapsed_seconds=time.time()-started, sources_unchanged=True)
    save(args.out/'manifest.json', manifest)
    for r in metrics:
        if r['participant'] == 'All' and r['period'] == 'Held posture':
            print({k:r[k] for k in ['procedure','macro_precision','macro_recall','macro_f1','accuracy','support']}, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=ROOT/'results')
    parser.add_argument('--jobs', type=int, default=4)
    args = parser.parse_args()
    with parallel_config(backend='loky', inner_max_num_threads=1):
        run(args)
