# Fixed software-only sensor and feature benchmark

Written before running this round. This is another exploratory development round on the same three recordings, not a fresh independent validation. Do not change the search after viewing outer-test results.

## Preserved evaluation

- Preserve all source CSVs, labels, masks, earlier scripts and results byte-for-byte. No new exclusions, smoothing, relabeling, synthetic samples, boundary trimming or protocol/time predictors.
- Use the same 2,032 held-posture decision windows and 346 transition windows. All eight classes remain included.
- Participant-calibrated, five outer repetition folds and four inner repetition folds. A group is the stored set_id plus rep. Known phase/position boundaries delimit feature contexts. This is an offline protocol-segmented assessment, not a continuous deployment test.
- As before, the initial recording baseline is acquisition-time calibration, not fitted on held-posture test windows. Imputation and scaling are fitted on training folds only. Verify that groups and feature-source sample ranges are disjoint across each split.
- Existing QC flags and nonfinite normalized-resistance values determine the common mask for both representations. No threshold changes. ADC values must also be finite; assert identical valid-sample masks between representations.

## Feature representations

Compare normalized resistance and ADC counts, each with seven original statistics or five statistics dropping minimum and maximum. The retained five are mean, sample standard deviation, median, IQR and endpoint change divided by the number of finite-sample intervals. Dropping extrema does not make all remaining statistics outlier-resistant.

Use the existing 20-sample windows and up to 40 trailing samples, confined to the same group and contiguous phase/position segment. Predictions retain the same endpoints and target labels. ADC inputs do not constitute voltage/resistance calibration evidence.

## Bounded training-only search

1. For each of the four representations, screen sensor subsets using 40-sample context, 64-tree ExtraTrees, min_samples_leaf=2, max_features=0.5, class_weight=balanced. Greedy selection evaluates ten singles, nine extensions of the winning single, then eight extensions of the winning pair. Choose by mean inner macro-F1, then accuracy, balanced accuracy, standing-weight proximity to one, candidate ID and weight. This is not exhaustive pair/triplet optimization.
2. For each representation and each selected sensor count (1, 2, 3), refine its screened subset using both contexts and three fixed 128-tree settings: ExtraTrees leaf=1, max_features=sqrt, no class weighting; ExtraTrees leaf=2, max_features=0.5, balanced weighting; RandomForest leaf=2, max_features=sqrt, balanced weighting. Apply exactly the same compact grid to all ten sensors. This yields 96 refined candidates per outer fold.
3. At screening and refinement, evaluate standing-class score multipliers 0.5, 0.75, 1, 1.25, 1.5, 2 and 3. This is the previous decision-weighting rule, not calibrated probability estimation or abstention. Choose using mean inner macro-F1, then accuracy, balanced accuracy, fewer sensors (cross-count ties only), weight proximity to one, candidate ID and weight.
4. Primary procedure: jointly select sensor count, representation, context, classifier and weight from the 96 refined candidates using inner folds only. Secondary procedures select the best refined candidate separately at each count: 1, 2, 3 and 10. Do not promote a secondary procedure to primary after seeing outer scores.
5. Use deterministic original seeds: inner 42+1000*outer_rep+10*inner_rep; outer 42+100000+1000*outer_rep+3. All models have n_jobs=1; parallelize candidates with four workers. The fixed budget is 6,480 screening fits and 5,760 refinement fits, plus at most 75 selected outer fits. Reuse identical outer fits when primary and count-specific selections coincide.

## Checks and reporting

- Save every screening/refinement score, greedy path, final choice, held/transition prediction, source hash, package version and split audit.
- Independently recount pooled and participant macro precision, macro recall/balanced accuracy, macro-F1, accuracy, per-class metrics and confusion counts. Report all five prespecified procedures against the unchanged previous primary result (74.17% balanced accuracy, 66.74% macro-F1, 64.37% accuracy).
- Replay all unique selected outer fits and at least one selected inner candidate per participant/outer fold. Check source hashes and unchanged window identities. Report gains and regressions; no claim of statistical significance from correlated windows or three participants.
- No new experiments or Overleaf, GitHub, ethics, date or source-data changes. End this bounded round without adding further searches based on its outer-test scores.
