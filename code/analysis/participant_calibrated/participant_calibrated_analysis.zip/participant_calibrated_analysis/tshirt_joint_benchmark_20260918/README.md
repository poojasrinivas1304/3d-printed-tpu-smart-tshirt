# T-shirt software-only benchmark

This directory contains one fixed exploratory sensor/feature/model comparison. It does not modify the source data, previous analyses, manuscript or public repository.

- `PLAN.md`: the plan fixed before this run.
- `joint_benchmark.py`: grouped training-only sensor and model selection.
- `verify_and_report.py`: independent metric checks and deterministic model replays.
- `RESULTS.md`: the verified outcome report, generated after completion.
- `results/`: all inner scores, selections, predictions, split checks, source hashes and software versions.

The comparison preserves all 2,032 held-posture decisions, eight classes and existing QC masks. The 346 transition decisions are retained separately. It compares normalized resistance with ADC features, seven statistics with a five-statistic set that omits extrema, and one, two, three and ten sensors. Sensor selection is greedy within each representation, entirely inside the outer training partition. The primary procedure selects the sensor count using inner macro-F1 rather than test performance.

## Environment

Python 3.14.5, NumPy 2.4.6, pandas 3.0.3, scikit-learn 1.8.0, joblib 1.5.3, SciPy 1.17.1 and Matplotlib 3.10.9. Matplotlib is imported by the preserved baseline module, and SciPy is a scikit-learn dependency. The run manifest records the core version strings and hashes all referenced source files. `requirements.txt` lists the package versions actually used.

The bundled spreadsheet runtime did not provide scikit-learn, so computation used the already available scientific Python environment. No packages were installed or altered.

## Inputs and execution

Keep these sibling directories together:

```text
outputs/
  tshirt_algorithm_benchmark_20260918/
    benchmark.py
    baseline_analysis.py
    data/processed/subject_01.csv
    data/processed/subject_02.csv
    data/processed/subject_03.csv
    results/window_manifest.csv
  tshirt_model_validation_20260918/validate.py
  tshirt_finetuning_20260918/
    PLAN.md
    refine.py
    results/
  tshirt_joint_benchmark_20260918/
```

From the workspace root:

```sh
MPLCONFIGDIR=/private/tmp/tshirt-joint-mpl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Library/Frameworks/Python.framework/Versions/3.14/bin/python3 outputs/tshirt_joint_benchmark_20260918/joint_benchmark.py --out /private/tmp/tshirt-joint-reproduction --jobs 4
```

The output directory must not already exist. The source-relative paths are resolved from the script location. Running `verify_and_report.py` checks the delivered `results/` directory and regenerates only this round's report and verification outputs.

No deployment model is produced. Results are fold-specific, participant-calibrated and internally evaluated on recordings already used for development. Do not describe them as independent-session validation or choose a different primary analysis after inspecting the secondary results.
