#!/usr/bin/env python3
"""Summarize the completed fixed benchmark without changing model selection."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd


def markdown_table(frame):
    rows = ["| " + " | ".join(map(str, frame.columns)) + " |",
            "| " + " | ".join(["---"]*len(frame.columns)) + " |"]
    rows += ["| " + " | ".join(map(str, row)) + " |" for row in frame.itertuples(index=False, name=None)]
    return "\n".join(rows)


def main(folder):
    m = pd.read_csv(folder/"metrics.csv")
    c = pd.read_csv(folder/"class_recall.csv")
    folds = pd.read_csv(folder/"fold_selections.csv")
    pred = pd.read_csv(folder/"outer_predictions.csv")
    manifest = json.loads((folder/"manifest.json").read_text())
    procedures = ["Exact baseline", "Nested selected", "Nested RF", "Nested ExtraTrees", "Nested SVM", "Nested Logistic", "Nested HistGB"]
    pooled = m.loc[m.participant.eq("All") & m.period.eq("Held posture")].set_index("procedure").loc[procedures]
    display = pooled[["accuracy", "balanced_accuracy", "macro_f1"]].map(lambda x: f"{100*x:.2f}%").reset_index()
    baseline, selected = pooled.loc["Exact baseline"], pooled.loc["Nested selected"]
    delta = 100*(selected.balanced_accuracy-baseline.balanced_accuracy)
    held = m.loc[m.period.eq("Held posture") & m.participant.ne("All") & m.procedure.isin(procedures[:2])]
    people = held.pivot(index="participant", columns="procedure", values="balanced_accuracy")[procedures[:2]]
    people["Difference (percentage points)"] = 100*(people["Nested selected"]-people["Exact baseline"])
    people[procedures[:2]] = people[procedures[:2]].map(lambda x: f"{100*x:.2f}%")
    people["Difference (percentage points)"] = people["Difference (percentage points)"].map(lambda x:f"{x:+.2f}")
    classes = c.loc[c.participant.eq("All") & c.period.eq("Held posture") & c.procedure.isin(procedures[:2])]
    class_table = classes.pivot(index=["position", "posture", "support"], columns="procedure", values="recall")[procedures[:2]]
    class_table = class_table.map(lambda x:f"{100*x:.2f}%").reset_index()
    chosen = folds.loc[folds.procedure.eq("Nested selected")]
    stability = chosen.groupby(["family", "variant"]).size().reset_index(name="Outer folds selected")
    paired = folds.loc[folds.procedure.isin(procedures[:2])].pivot(index=["participant", "outer_rep"], columns="procedure", values="balanced_accuracy")
    differences = paired["Nested selected"]-paired["Exact baseline"]
    chosen_held = pred.loc[pred.procedure.eq("Nested selected") & pred.period.eq("Held posture")]
    standing = chosen_held.loc[chosen_held.position_index.eq(1)]
    standing_errors = int((~standing.correct).sum())
    all_errors = int((~chosen_held.correct).sum())
    standing_timing = standing.groupby("window_in_segment").correct.agg(recall="mean", support="size").reset_index()
    standing_timing.to_csv(folder/"standing_window_diagnostics.csv", index=False)
    # Independent recount of the primary headline from exported predictions.
    for procedure in procedures[:2]:
        d = pred.loc[pred.procedure.eq(procedure) & pred.period.eq("Held posture")]
        assert len(d) == 2032 and d.window_id.nunique() == 2032
        manual = d.assign(hit=d.position_index.eq(d.predicted_position)).groupby("position_index").hit.mean().mean()
        assert abs(manual-pooled.loc[procedure,"balanced_accuracy"]) < 1e-12
    report = f"""# T-shirt classification benchmark results

The exact original full-ten-sensor baseline was rerun and its predictions matched the original analysis functions for every outer fold. The nested-selected procedure changed pooled held-posture balanced accuracy from **{100*baseline.balanced_accuracy:.2f}% to {100*selected.balanced_accuracy:.2f}%** ({delta:+.2f} percentage points). All results below are out-of-fold predictions, not training accuracy.

**Important tradeoff:** ordinary accuracy fell from {100*baseline.accuracy:.2f}% to {100*selected.accuracy:.2f}%. Standing-straight recall fell from {class_table.loc[class_table.position.eq(1), 'Exact baseline'].iloc[0]} to {class_table.loc[class_table.position.eq(1), 'Nested selected'].iloc[0]}, while recall improved for all seven other postures. This is not a uniformly better or submission-ready solution.

## Main comparison

{markdown_table(display)}

All methods classify the same 2,032 held-posture windows across eight classes and use all ten sensors. The main proposed procedure is **Nested selected**, with model family, parameters and feature context chosen only from inner training-fold validation. Family-specific rows are secondary prespecified comparisons, not candidates from which to select a winner after examining these outer scores. Chance-level balanced accuracy for eight classes is 12.5%, not 50%.

## Participant results

{markdown_table(people.reset_index())}

Participant S1/S2/S3 corresponds to subject_01/02/03.csv, not sensor numbering. Across the 15 participant/repetition folds, nested selection improved balanced accuracy in {int((differences>0).sum())}, worsened it in {int((differences<0).sum())}, and tied in {int((differences==0).sum())}. These folds are correlated; they are not 15 independent participants.

## Recall by posture

{markdown_table(class_table)}

Class support is the number of held-posture decision windows, not independent trials. Position 4 means right hand touching left shoulder with a left torso twist. Position 5 is its mirror movement. The standing class has many more windows because reference holds recur across target blocks.

## Remaining classification errors

Standing accounts for {standing_errors} of {all_errors} remaining held-posture errors ({100*standing_errors/all_errors:.1f}%). In the post-run diagnostic, standing recall was {100*standing_timing.iloc[0]['recall']:.1f}% in the first nominal one-second window of the standing segment (n={int(standing_timing.iloc[0]['support'])}) and {100*standing_timing.iloc[-1]['recall']:.1f}% in the tenth (n={int(standing_timing.iloc[-1]['support'])}). The tenth-window count differs because incomplete trailing windows are not used. Full counts are in standing_window_diagnostics.csv.

This time pattern makes signal settling, return-to-standing behavior and label synchronization worth checking against acquisition records. It does not prove any of those explanations. No early standing windows were removed, relabeled or used to revise the search. A future comparison should specify in advance both the balanced-accuracy objective and the minimum acceptable standing recall, then confirm the chosen method on new sessions.

## What the inner validation selected

{markdown_table(stability)}

Exact settings and inner scores are in fold_selections.csv and inner_search_scores.csv. Model candidates and all software versions are recorded in manifest.json. No search settings were revised after observing this run's outer performance.

## Processing and validation

- Original QC masks and recording-baseline normalized dr_s1–dr_s10 fields were retained. No exploratory plot masks, manual burst deletions or new sample exclusions were used.
- Each decision covers the same complete 20-sample window as the original analysis. The optional context variant computes the same seven statistics using up to 40 trailing samples, ending at that decision and stopping at its stored group and phase/position boundary. It does not look forward.
- Five outer repetition folds and four inner folds were run separately for each participant. Imputation and scaling were fitted inside each training fold. The 64 candidate settings were ranked by inner mean balanced accuracy, then accuracy, then fixed candidate order.
- All feature measurements were checked for overlap across inner and outer train/test partitions. The initial recording calibration remains a shared fixed acquisition-time reference, not a label-trained preprocessing transform.
- Transitions were excluded from fitting and selection, but all 346 transition windows were predicted as a secondary test. Their metrics appear separately in metrics.csv; no transition windows were silently dropped from evaluation.
- Source hashes were unchanged after execution. Every procedure has the same test-window IDs. The pooled balanced accuracies above were independently recounted as mean per-class recall from the saved prediction file.
- A separate input audit found 50 ms increments throughout the stored device timestamps, but variable host reception intervals. These are nominal one-second, 20-sample decisions. The exported resistance values match R = 3300 × ADC / (4095 − ADC) numerically. This is an arithmetic check, not evidence of physical wiring or ADC calibration. No duplicated sample indices, nonincreasing host elapsed times or hold-label inconsistencies were found.

## Limits and next scientific step

This is an exploratory algorithm-development comparison on already-inspected data from three participants. It is participant-calibrated, within-recording recognition, not unseen-participant or independent-session performance. Both feature variants use known protocol segments; the longer context especially should not be described as continuous unconstrained recognition. Stored groups can place a return after a target in the next group, and adjacent repetitions in a fixed-order recording remain dependent even without shared raw measurements.

No classifier tuning repairs hardware faults, establishes ESP32 calibration, supplies new independent subjects, or proves garment durability. Treat the inner-selected pipeline as a candidate for new, separately recorded sessions with randomized posture order. Do not claim a statistically proven improvement from these three participants alone, and do not repeatedly tune against these same outer folds.

The manuscript, Overleaf, GitHub and source CSVs were not modified. Runtime: {manifest['elapsed_seconds']/60:.1f} minutes for feature construction, tuning, testing and verification.
"""
    (folder.parent/"RESULTS.md").write_text(report)
    print(markdown_table(display))
    print(markdown_table(people.reset_index()))
    print(markdown_table(class_table))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("results", type=Path)
    main(parser.parse_args().results)
