# T-shirt dataset and algorithm benchmark

Read RESULTS.md for the completed comparison. This is a separate exploratory analysis, not a replacement for the manuscript or published repository.

## Contents

- data/processed/subject_01.csv, subject_02.csv, subject_03.csv: byte-identical copies of the three released participant exports (16,900 / 16,900 / 16,901 rows). They contain ADC, resistance, normalized signals, protocol labels and timing metadata. These are processed exports, not untouched acquisition logs.
- baseline_analysis.py: unchanged original analysis script used to reproduce the full-ten-sensor baseline.
- benchmark.py: fixed nested model/feature selection and outer-fold testing.
- PLAN.md: search and comparison rules written before this run's outer results were inspected.
- summarize.py: independent metric recount and report generation from exported predictions.
- audit_data.py and results/input_audit.json: read-only checks of sampling metadata, labels, missing values, QC flags and resistance arithmetic. The arithmetic check does not verify physical hardware or ADC calibration.
- check_outputs.py: independently checks hashes, inner-only selection, prediction coverage and every exported metric (`python check_outputs.py .` for the supplied results).
- requirements.txt: tested Python package versions.
- results/manifest.json: hashes, versions, all 64 candidate settings and validation checks.
- results/window_manifest.csv: every evaluated decision window, group/fold identity and source sample bounds.
- results/inner_search_scores.csv: all candidate scores on every inner fold.
- results/fold_selections.csv: settings and held-posture outer metrics for each participant/fold/procedure.
- results/outer_predictions.csv: every outer prediction, including transitions.
- results/metrics.csv: pooled and participant accuracy, balanced accuracy, macro-F1 and support, with held/transition periods separate.
- results/class_recall.csv and confusion_counts.csv: class-specific results and full confusion counts.
- results/standing_window_diagnostics.csv: post-run standing recall by window number, with support. This diagnostic did not change model selection or exclude windows.

Participant S1/S2/S3 in result files corresponds to subject_01/02/03.csv (P01/P02/P03 in the manuscript). It is distinct from sensor numbering S1–S10. Performance values in CSVs are fractions; multiply by 100 to express percentages. A row of predictions is a decision window, not an independent participant or trial.

## Reproduce

Tested with Python 3.14.5. From this folder:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python benchmark.py --data-dir data/processed --baseline-script baseline_analysis.py --out reproduced_results --n-jobs 4
python summarize.py reproduced_results
python audit_data.py --data-dir data/processed --out reproduced_results/input_audit.json
```

On Windows use `.venv\Scripts\activate`. Use `--n-jobs 1` for a lower-concurrency run. Choose a new output directory on each run: the script refuses to overwrite an existing one. The summarizer writes RESULTS.md beside the chosen output directory, so copy this package before rerunning if you want to preserve the supplied report. Fixed seeds are included. Different library versions may produce different results.

The primary comparison is Exact baseline versus Nested selected. The latter chooses the family, parameters and context using only inner folds. Do not choose whichever family has the highest outer score and describe it as the original primary comparison.

## Important boundaries

No source CSVs, dates, posture labels, manuscript text, Overleaf files or GitHub content were changed. No manual peak exclusions or exploratory figure filters were added. The original QC flags were used unchanged. All ten sensors and all eight classes remain.

Training and testing are grouped within each participant's existing recording. Neither performance on a new participant nor performance in a new session is measured here. The optional two-second feature context stops at known protocol boundaries and cannot be presented as boundary-free online recognition. See PLAN.md and RESULTS.md for the full analysis limitations.

## Source

Repository: https://github.com/poojasrinivas1304/3d-printed-tpu-smart-tshirt

Input CSV copies correspond to data commit 899a984b25b5ff510d84a702cf7b74f8dc64f4b6. The unchanged baseline script corresponds to the movement-label-comment revision documented at commit 4d63aa3c7e0a8c738defdf8ca160ea2d19bc99aa. The input and script hashes are preserved in results/manifest.json.
