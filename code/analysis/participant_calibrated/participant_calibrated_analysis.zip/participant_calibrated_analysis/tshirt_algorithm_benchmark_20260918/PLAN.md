# T-shirt algorithm benchmark

Plan fixed before this run's outer-fold results are examined.

- Preserve the three released CSVs and original analysis script byte-for-byte.
- Reproduce the full-ten-sensor baseline with its exact 100-tree random forest, preprocessing and seeds.
- All eight posture classes remain. Use the existing participant-specific five outer repetition folds, four inner repetition folds, original QC flags and recording-baseline normalization. Initial baseline samples are not classification examples.
- Evaluate every method on exactly the same one-second decisions: 20 samples, non-overlapping, within each stored group and phase/position segment. Held postures are primary. Transitions are secondary, never used for tuning or fitting.
- Candidate features: original seven statistics per sensor over 20 samples; the same statistics over up to 40 trailing samples ending at each identical decision. Context stops at the stored group and phase/position boundary. Thus the latter requires known protocol boundaries and is not an unrestricted online classifier.
- Candidates: baseline RF100; RF200 and ExtraTrees200 with leaf size 1/2/4 and max_features sqrt/0.5; RBF SVM C 0.1/1/10/100 and gamma scale/0.01/0.1; logistic regression C 0.1/1/10; histogram gradient boosting learning rate 0.05/0.1 and 7/15 leaves. Use balanced class weighting. This is 64 feature/model settings, selected by mean inner-fold balanced accuracy, then accuracy, then fixed candidate order.
- Fit imputation and scaling only inside each training split. No subject ID, time, protocol set, repetition, or class label enters the predictors. No manual peak masks, new exclusions, label changes, smoothing with future samples, or test-set tuning.
- Report exact baseline, the overall inner-selected procedure, and separately prespecified family-specific inner-selected procedures. The overall procedure, not the best outer-scoring family, is the main proposed comparison.
- Export fold assignments, source sample bounds, all inner scores, selected settings, every outer prediction, class supports, participant metrics and confusion matrices. Verify group and measurement separation, matching test decisions, and source hashes.
- Do not keep changing the search after seeing outer results. These data have already been inspected and are development data, not an independent prospective test. Three participants and one recording each limit generalization. Existing stored group IDs include reference and target phases but can assign the return after a target to the next repetition, so report this limitation without claiming independent complete motion cycles.

No Overleaf, GitHub or original-file changes are authorized by this benchmark.
