#!/usr/bin/env python3
"""Fixed nested grouped benchmark; see PLAN.md. No source files are modified."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import platform
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from joblib import Parallel, delayed, parallel_config
from sklearn.ensemble import ExtraTreesClassifier, HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix, f1_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

LABELS = list(range(1, 9))
SEED = 42


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def import_baseline(path):
    spec = importlib.util.spec_from_file_location("baseline", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def stats(values):
    v = values[np.isfinite(values)]
    if not len(v):
        return [np.nan] * 7
    return [v.mean(), v.std(ddof=1) if len(v) > 1 else 0.0,
            np.median(v), np.percentile(v, 75) - np.percentile(v, 25),
            v.min(), v.max(), (v[-1] - v[0]) / max(1, len(v)-1)]


def build_variants(base, data_dir):
    original = base.load_data(data_dir)
    rows, context, audit = [], [], []
    for i in range(1, 4):
        raw = pd.read_csv(data_dir / f"subject_{i:02d}.csv")
        audit.append({"participant": f"S{i}", "source_rows": len(raw),
                      "position_names": raw.groupby("position_index")["position_name"].unique().map(list).to_dict(),
                      "nonmonotonic_elapsed_steps": int((raw.elapsed_s.diff().dropna() <= 0).sum()),
                      "qc_invalid_by_sensor": {str(s): int((raw[f"qc_high_adc_s{s}"].ne(0) | raw[f"qc_low_adc_s{s}"].ne(0)).sum()) for s in base.SENSORS}})
        df = raw.loc[raw.set_id.between(1, 7)].copy()
        df["participant"] = f"S{i}"
        for col in ["set_id", "rep", "position_index"]:
            df[col] = df[col].astype(int)
        df["group_id"] = df.participant + "_set" + df.set_id.astype(str) + "_rep" + df.rep.astype(str)
        for _, group in df.groupby("group_id", sort=False):
            group = base._recording_normalized_group(group)
            breaks = (group.phase.ne(group.phase.shift()) | group.position_index.ne(group.position_index.shift())).cumsum()
            for segment_id, segment in group.groupby(breaks, sort=False):
                for k in range(len(segment) // 20):
                    stop = (k+1) * 20
                    window = segment.iloc[k*20:stop]
                    history = segment.iloc[max(0, stop-40):stop]
                    row = {"participant": f"S{i}", "group_id": window.group_id.iloc[0],
                           "set_id": int(window.set_id.iloc[0]), "rep": int(window.rep.iloc[0]),
                           "phase": window.phase.iloc[0], "period": "Held posture" if window.phase.iloc[0] == "hold" else "Transition",
                           "position_index": int(window.position_index.iloc[0]), "elapsed_s": float(window.elapsed_s.mean()),
                           "window_in_segment": k+1, "window_samples": 20,
                           "segment_id": int(segment_id), "sample_start": int(window.sample_index.iloc[0]),
                           "sample_end": int(window.sample_index.iloc[-1]),
                           "context_sample_start": int(history.sample_index.iloc[0]),
                           "context_sample_end": int(history.sample_index.iloc[-1]), "context_samples": len(history)}
                    rows.append(row)
                    context.append([v for s in base.SENSORS for v in stats(history[f"x_s{s}"].to_numpy(float))])
    metadata = pd.DataFrame(rows)
    pd.testing.assert_frame_equal(original.drop(columns=base.feature_columns(base.SENSORS)), metadata[original.drop(columns=base.feature_columns(base.SENSORS)).columns], check_dtype=False)
    assert len(metadata) == 2378
    assert metadata.period.eq("Held posture").sum() == 2032
    features = {"original_1s": original[base.feature_columns(base.SENSORS)].to_numpy(float),
                "context_2s": np.asarray(context, dtype=float)}
    # The first window in every segment has exactly the original 20 samples.
    first = metadata.window_in_segment.eq(1).to_numpy()
    np.testing.assert_allclose(features["original_1s"][first], features["context_2s"][first], equal_nan=True)
    metadata["window_id"] = np.arange(len(metadata))
    return metadata, features, audit


def candidates():
    specifications = [{"family": "RF", "n_estimators": 100, "min_samples_leaf": 2, "max_features": "sqrt"}]
    for family in ("RF", "ExtraTrees"):
        for leaf in (1, 2, 4):
            for max_features in ("sqrt", 0.5):
                specifications.append({"family": family, "n_estimators": 200, "min_samples_leaf": leaf, "max_features": max_features})
    for c in (0.1, 1.0, 10.0, 100.0):
        for gamma in ("scale", 0.01, 0.1):
            specifications.append({"family": "SVM", "C": c, "gamma": gamma})
    for c in (0.1, 1.0, 10.0):
        specifications.append({"family": "Logistic", "C": c})
    for rate in (0.05, 0.1):
        for leaves in (7, 15):
            specifications.append({"family": "HistGB", "learning_rate": rate, "max_leaf_nodes": leaves})
    return [dict(spec, variant=variant, candidate_id=32*vi+j)
            for vi, variant in enumerate(("original_1s", "context_2s"))
            for j, spec in enumerate(specifications)]


def classifier(candidate, seed):
    kwargs = {k: v for k, v in candidate.items() if k not in ("family", "variant", "candidate_id")}
    family = candidate["family"]
    if family == "RF":
        return RandomForestClassifier(**kwargs, class_weight="balanced", random_state=seed, n_jobs=1)
    if family == "ExtraTrees":
        return ExtraTreesClassifier(**kwargs, class_weight="balanced", random_state=seed, n_jobs=1)
    if family == "SVM":
        return SVC(**kwargs, kernel="rbf", class_weight="balanced", random_state=seed)
    if family == "Logistic":
        return LogisticRegression(**kwargs, class_weight="balanced", max_iter=5000, random_state=seed)
    return HistGradientBoostingClassifier(**kwargs, class_weight="balanced", max_iter=150, early_stopping=False, random_state=seed)


def preprocess(train, valid):
    transformer = make_pipeline(SimpleImputer(strategy="median", keep_empty_features=True), StandardScaler())
    return transformer.fit_transform(train), transformer.transform(valid)


def scores(y, predicted):
    return {"accuracy": float(accuracy_score(y, predicted)),
            "balanced_accuracy": float(balanced_accuracy_score(y, predicted)),
            "macro_f1": float(f1_score(y, predicted, labels=LABELS, average="macro", zero_division=0)),
            "support": len(y)}


def score_candidate(candidate, prepared, outer_rep):
    results = []
    for inner_rep, train_x, y, valid_x, truth in prepared[candidate["variant"]]:
        model = classifier(candidate, SEED + 1000*outer_rep + 10*inner_rep)
        model.fit(train_x, y)
        result = scores(truth, model.predict(valid_x))
        results.append({"inner_rep": inner_rep, **result})
    return {**candidate, "inner_mean_balanced_accuracy": float(np.mean([s["balanced_accuracy"] for s in results])),
            "inner_mean_accuracy": float(np.mean([s["accuracy"] for s in results])), "folds": results}


def check_split(metadata, train_idx, test_idx):
    train, test = metadata.iloc[train_idx], metadata.iloc[test_idx]
    assert set(train.group_id).isdisjoint(test.group_id)
    # Check measurement overlap explicitly for the longest feature context.
    def measurements(frame):
        return {(row.participant, sample) for row in frame.itertuples()
                for sample in range(row.context_sample_start, row.context_sample_end+1)}
    assert measurements(train).isdisjoint(measurements(test))
    assert set(train.position_index) == set(LABELS)
    assert set(test.position_index) == set(LABELS)


def run(args):
    started = time.time()
    args.out.mkdir(parents=True, exist_ok=False)
    paths = [args.data_dir/f"subject_{i:02d}.csv" for i in range(1,4)] + [args.baseline_script]
    hashes = {str(p): digest(p) for p in paths}
    base = import_baseline(args.baseline_script)
    meta, features, audit = build_variants(base, args.data_dir)
    settings = candidates()
    assert len(settings) == 64 and len({c["candidate_id"] for c in settings}) == 64
    manifest = {"source_sha256": hashes, "benchmark_sha256": digest(__file__),
                "plan_sha256": digest(Path(__file__).with_name("PLAN.md")), "candidates": settings,
                "versions": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__, "sklearn": sklearn.__version__, "joblib": joblib.__version__},
                "held_windows": int(meta.period.eq("Held posture").sum()), "transition_windows": int(meta.period.eq("Transition").sum()),
                "audit": audit}
    (args.out/"manifest.json").write_text(json.dumps(manifest, indent=2))
    meta.to_csv(args.out/"window_manifest.csv", index=False)
    print(f"Loaded {len(meta)} windows, 64 candidates, source hashes recorded", flush=True)
    all_predictions, all_search, selections = [], [], []
    for participant in sorted(meta.participant.unique()):
        for outer_rep in range(1, 6):
            p_mask = meta.participant.eq(participant).to_numpy()
            held = meta.period.eq("Held posture").to_numpy()
            train = np.flatnonzero(p_mask & held & meta.rep.ne(outer_rep).to_numpy())
            test = np.flatnonzero(p_mask & meta.rep.eq(outer_rep).to_numpy())
            check_split(meta, train, test)
            prepared = {v: [] for v in features}
            for inner_rep in sorted(set(meta.iloc[train].rep)):
                itrain = train[meta.iloc[train].rep.ne(inner_rep).to_numpy()]
                valid = train[meta.iloc[train].rep.eq(inner_rep).to_numpy()]
                check_split(meta, itrain, valid)
                for variant, x in features.items():
                    tx, vx = preprocess(x[itrain], x[valid])
                    prepared[variant].append((int(inner_rep), tx, meta.iloc[itrain].position_index.to_numpy(), vx, meta.iloc[valid].position_index.to_numpy()))
            results = Parallel(n_jobs=args.n_jobs)(delayed(score_candidate)(c, prepared, outer_rep) for c in settings)
            for result in results:
                for inner in result["folds"]:
                    all_search.append({"participant": participant, "outer_rep": outer_rep,
                                       **{k: v for k, v in result.items() if k != "folds"}, **inner})
            ranked = sorted(results, key=lambda r: (-r["inner_mean_balanced_accuracy"], -r["inner_mean_accuracy"], r["candidate_id"]))
            winners = {"Nested selected": ranked[0]}
            for family in ("RF", "ExtraTrees", "SVM", "Logistic", "HistGB"):
                winners[f"Nested {family}"] = next(r for r in ranked if r["family"] == family)
            winners["Exact baseline"] = {**settings[0], "inner_mean_balanced_accuracy": None, "inner_mean_accuracy": None}
            for procedure, winner in winners.items():
                candidate = settings[winner["candidate_id"]]
                tx, vx = preprocess(features[candidate["variant"]][train], features[candidate["variant"]][test])
                model = classifier(candidate, SEED + 100000 + 1000*outer_rep + 3)
                model.fit(tx, meta.iloc[train].position_index.to_numpy())
                pred = model.predict(vx).astype(int)
                part = meta.iloc[test].copy()
                part["procedure"] = procedure
                part["candidate_id"] = candidate["candidate_id"]
                part["predicted_position"] = pred
                part["correct"] = pred == part.position_index.to_numpy()
                all_predictions.append(part)
                ht = part.period.eq("Held posture")
                selections.append({"participant": participant, "outer_rep": outer_rep, "procedure": procedure,
                                   **candidate, "inner_mean_balanced_accuracy": winner["inner_mean_balanced_accuracy"],
                                   **scores(part.loc[ht, "position_index"], part.loc[ht, "predicted_position"])})
                if procedure == "Exact baseline":
                    original_data = pd.DataFrame(features["original_1s"], columns=base.feature_columns(base.SENSORS))
                    original_data["position_index"] = meta.position_index.to_numpy()
                    bx, by, btx, _ = base.preprocess_split(original_data.iloc[train], original_data.iloc[test])
                    bp = base.predict_preprocessed(bx, by, btx, base.SENSORS, 100, SEED+100000+1000*outer_rep+3)
                    np.testing.assert_array_equal(pred, bp)
            # Durable progress, without examining or printing outer performance.
            pd.DataFrame(all_search).to_csv(args.out/"inner_search_scores.csv", index=False)
            pd.DataFrame(selections).to_csv(args.out/"fold_selections.csv", index=False)
            pd.concat(all_predictions).to_csv(args.out/"outer_predictions.csv", index=False)
            print(f"Completed {participant}, outer repetition {outer_rep}; elapsed {time.time()-started:.0f}s", flush=True)
    predictions = pd.concat(all_predictions, ignore_index=True)
    metric_rows, class_rows, matrices = [], [], []
    for (procedure, period), period_data in predictions.groupby(["procedure", "period"], sort=False):
        for participant, d in [("All", period_data), *list(period_data.groupby("participant"))]:
            y, pred = d.position_index.to_numpy(), d.predicted_position.to_numpy()
            metric_rows.append({"procedure": procedure, "participant": participant, "period": period, **scores(y, pred)})
            for label in LABELS:
                mask = y == label
                class_rows.append({"procedure": procedure, "participant": participant, "period": period,
                                   "position": label, "posture": base.POSITION_NAMES[label], "support": int(mask.sum()),
                                   "recall": float(np.mean(pred[mask] == label)) if mask.any() else None})
            cm = confusion_matrix(y, pred, labels=LABELS)
            for i, truth in enumerate(LABELS):
                for j, prediction in enumerate(LABELS):
                    matrices.append({"procedure": procedure, "participant": participant, "period": period,
                                     "actual": truth, "predicted": prediction, "count": int(cm[i,j])})
    metrics = pd.DataFrame(metric_rows)
    metrics.to_csv(args.out/"metrics.csv", index=False)
    pd.DataFrame(class_rows).to_csv(args.out/"class_recall.csv", index=False)
    pd.DataFrame(matrices).to_csv(args.out/"confusion_counts.csv", index=False)
    for procedure, d in predictions.groupby("procedure"):
        assert len(d) == 2378 and d.window_id.nunique() == 2378
        assert d.period.eq("Held posture").sum() == 2032
    assert hashes == {str(p): digest(p) for p in paths}, "Source changed during execution"
    manifest.update({"elapsed_seconds": time.time()-started, "verification": "Source hashes unchanged; exact baseline predictions match original functions; group/measurement separation verified; identical test windows across all procedures."})
    (args.out/"manifest.json").write_text(json.dumps(manifest, indent=2))
    print(metrics.loc[metrics.participant.eq("All") & metrics.period.eq("Held posture")].to_string(index=False), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--baseline-script", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--n-jobs", type=int, default=4)
    args = parser.parse_args()
    with parallel_config(backend="loky", inner_max_num_threads=1):
        run(args)
