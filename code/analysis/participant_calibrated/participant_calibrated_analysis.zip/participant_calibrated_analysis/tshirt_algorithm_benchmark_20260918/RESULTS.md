# T-shirt classification benchmark results

The exact original full-ten-sensor baseline was rerun and its predictions matched the original analysis functions for every outer fold. The nested-selected procedure changed pooled held-posture balanced accuracy from **53.16% to 75.90%** (+22.74 percentage points). All results below are out-of-fold predictions, not training accuracy.

**Important tradeoff:** ordinary accuracy fell from 63.78% to 59.74%. Standing-straight recall fell from 77.97% to 38.35%, while recall improved for all seven other postures. This is not a uniformly better or submission-ready solution.

## Main comparison

| procedure | accuracy | balanced_accuracy | macro_f1 |
| --- | --- | --- | --- |
| Exact baseline | 63.78% | 53.16% | 58.22% |
| Nested selected | 59.74% | 75.90% | 63.80% |
| Nested RF | 62.89% | 61.97% | 61.56% |
| Nested ExtraTrees | 61.17% | 76.41% | 64.91% |
| Nested SVM | 50.98% | 73.86% | 57.09% |
| Nested Logistic | 52.02% | 70.89% | 56.84% |
| Nested HistGB | 65.99% | 59.39% | 61.96% |

All methods classify the same 2,032 held-posture windows across eight classes and use all ten sensors. The main proposed procedure is **Nested selected**, with model family, parameters and feature context chosen only from inner training-fold validation. Family-specific rows are secondary prespecified comparisons, not candidates from which to select a winner after examining these outer scores. Chance-level balanced accuracy for eight classes is 12.5%, not 50%.

## Participant results

| participant | Exact baseline | Nested selected | Difference (percentage points) |
| --- | --- | --- | --- |
| S1 | 54.49% | 74.06% | +19.57 |
| S2 | 52.78% | 79.11% | +26.33 |
| S3 | 52.16% | 74.57% | +22.41 |

Participant S1/S2/S3 corresponds to subject_01/02/03.csv, not sensor numbering. Across the 15 participant/repetition folds, nested selection improved balanced accuracy in 15, worsened it in 0, and tied in 0. These folds are correlated; they are not 15 independent participants.

## Recall by posture

| position | posture | support | Exact baseline | Nested selected |
| --- | --- | --- | --- | --- |
| 1 | Standing straight | 1017 | 77.97% | 38.35% |
| 2 | Left arm raise | 143 | 60.14% | 89.51% |
| 3 | Right arm raise | 143 | 46.85% | 86.71% |
| 4 | Left shoulder touch and twist | 144 | 33.33% | 88.89% |
| 5 | Right shoulder touch and twist | 147 | 53.74% | 77.55% |
| 6 | Both arms raise | 147 | 50.34% | 78.23% |
| 7 | Forward bend | 144 | 74.31% | 84.03% |
| 8 | Sitting | 147 | 28.57% | 63.95% |

Class support is the number of held-posture decision windows, not independent trials. Position 4 means right hand touching left shoulder with a left torso twist. Position 5 is its mirror movement. The standing class has many more windows because reference holds recur across target blocks.

## Remaining classification errors

Standing accounts for 627 of 818 remaining held-posture errors (76.7%). In the post-run diagnostic, standing recall was 13.3% in the first nominal one-second window of the standing segment (n=105) and 55.6% in the tenth (n=72). The tenth-window count differs because incomplete trailing windows are not used. Full counts are in standing_window_diagnostics.csv.

This time pattern makes signal settling, return-to-standing behavior and label synchronization worth checking against acquisition records. It does not prove any of those explanations. No early standing windows were removed, relabeled or used to revise the search. A future comparison should specify in advance both the balanced-accuracy objective and the minimum acceptable standing recall, then confirm the chosen method on new sessions.

## What the inner validation selected

| family | variant | Outer folds selected |
| --- | --- | --- |
| ExtraTrees | context_2s | 2 |
| ExtraTrees | original_1s | 12 |
| SVM | original_1s | 1 |

Exact settings and inner scores are in fold_selections.csv and inner_search_scores.csv. Model candidates and all software versions are recorded in manifest.json. No search settings were revised after observing this run's outer performance.

## Processing and validation

- Original QC masks and recording-baseline normalized dr_s1–dr_s10 fields were retained. No exploratory plot masks, manual burst deletions or new sample exclusions were used.
- Each decision covers the same complete 20-sample window as the original analysis. The optional context variant computes the same seven statistics using up to 40 trailing samples, ending at that decision and stopping at its stored group and phase/position boundary. It does not look forward.
- Five outer repetition folds and four inner folds were run separately for each participant. Imputation and scaling were fitted inside each training fold. The 64 candidate settings were ranked by inner mean balanced accuracy, then accuracy, then fixed candidate order.
- All feature measurements were checked for overlap across inner and outer train/test partitions. The initial recording calibration remains a shared fixed acquisition-time reference, not a label-trained preprocessing transform.
- Transitions were excluded from fitting and selection, but all 346 transition windows were predicted as a secondary test. Their metrics appear separately in metrics.csv; no transition windows were silently dropped from evaluation.
- Source hashes were unchanged after execution. Every procedure has the same test-window IDs. The pooled balanced accuracies above were independently recounted as mean per-class recall from the saved prediction file.
- A separate input audit found 50 ms increments throughout the stored device timestamps, but variable host reception intervals. These are nominal one-second, 20-sample decisions. The exported resistance values match R = 3300 × ADC / (4095 − ADC) numerically. This is an arithmetic check, not evidence of physical wiring or ADC calibration. No duplicated sample indices, nonincreasing host elapsed times or hold-label inconsistencies were found.

## Limits and next scientific step

This is an exploratory algorithm-development comparison on already-inspected data from three participants. It is participant-calibrated, within-recording recognition, not unseen-participant or independent-session performance. Both feature variants use known protocol segments; the longer context especially should not be described as continuous unconstrained recognition. Stored groups can place a return after a target in the next group, and adjacent repetitions in a fixed-order recording remain dependent even without shared raw measurements.

No classifier tuning repairs hardware faults, establishes ESP32 calibration, supplies new independent subjects, or proves garment durability. Treat the inner-selected pipeline as a candidate for new, separately recorded sessions with randomized posture order. Do not claim a statistically proven improvement from these three participants alone, and do not repeatedly tune against these same outer folds.

The manuscript, Overleaf, GitHub and source CSVs were not modified. Runtime: 12.5 minutes for feature construction, tuning, testing and verification.
