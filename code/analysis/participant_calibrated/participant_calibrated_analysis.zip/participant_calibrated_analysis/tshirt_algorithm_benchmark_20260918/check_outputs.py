#!/usr/bin/env python3
"""Independently validate a finished benchmark and its input copies."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score


def run(root):
    results = root/"results"
    manifest = json.loads((results/"manifest.json").read_text())
    for original, expected in manifest["source_sha256"].items():
        original_name = Path(original).name
        copy = root/"data/processed"/original_name if original_name.endswith(".csv") else root/"baseline_analysis.py"
        assert hashlib.sha256(copy.read_bytes()).hexdigest() == expected
    assert hashlib.sha256((root/"benchmark.py").read_bytes()).hexdigest() == manifest["benchmark_sha256"]
    assert hashlib.sha256((root/"PLAN.md").read_bytes()).hexdigest() == manifest["plan_sha256"]
    windows = pd.read_csv(results/"window_manifest.csv")
    pred = pd.read_csv(results/"outer_predictions.csv")
    inner = pd.read_csv(results/"inner_search_scores.csv")
    choices = pd.read_csv(results/"fold_selections.csv")
    metrics = pd.read_csv(results/"metrics.csv")
    assert len(inner) == 64*4*15
    assert len(choices) == 7*15
    assert len(pred) == 7*2378
    assert inner.groupby(["participant","outer_rep","candidate_id"]).size().eq(4).all()
    assert (inner.outer_rep != inner.inner_rep).all()
    for (person, outer), d in inner.groupby(["participant", "outer_rep"]):
        ranked = d.groupby("candidate_id").agg(balanced_accuracy=("balanced_accuracy", "mean"), accuracy=("accuracy", "mean")).reset_index()
        ranked = ranked.sort_values(["balanced_accuracy", "accuracy", "candidate_id"], ascending=[False,False,True])
        recorded = choices.loc[choices.participant.eq(person)&choices.outer_rep.eq(outer)&choices.procedure.eq("Nested selected")]
        assert len(recorded) == 1 and recorded.candidate_id.iloc[0] == ranked.candidate_id.iloc[0]
    for procedure, d in pred.groupby("procedure"):
        assert d.window_id.nunique() == 2378
        assert sorted(d.window_id) == sorted(windows.window_id)
        assert d.correct.eq(d.position_index.eq(d.predicted_position)).all()
    for row in metrics.itertuples():
        d = pred.loc[pred.procedure.eq(row.procedure)&pred.period.eq(row.period)]
        if row.participant != "All":
            d = d.loc[d.participant.eq(row.participant)]
        assert len(d) == row.support
        y, p = d.position_index, d.predicted_position
        np.testing.assert_allclose([row.accuracy,row.balanced_accuracy,row.macro_f1],
                                   [accuracy_score(y,p),balanced_accuracy_score(y,p),f1_score(y,p,labels=range(1,9),average="macro",zero_division=0)],atol=1e-12,rtol=0)
    print("PASS: source/code/plan hashes; all 3,840 inner scores; all 105 selected-fold records; all 16,646 outer predictions; inner-only winners; identical test decisions; every exported metric.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", type=Path)
    run(parser.parse_args().folder)
