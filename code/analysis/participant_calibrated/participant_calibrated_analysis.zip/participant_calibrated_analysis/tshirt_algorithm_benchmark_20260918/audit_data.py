#!/usr/bin/env python3
"""Read-only input checks; does not change features, labels or exclusions."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd


def run(data_dir, output):
    records = []
    for participant in range(1, 4):
        d = pd.read_csv(data_dir/f"subject_{participant:02d}.csv")
        device_dt = d.device_time_ms.diff().dropna()
        host_dt = d.elapsed_s.diff().dropna()
        record = {
            "participant": f"S{participant}", "rows": len(d),
            "duplicate_sample_indices": int(d.sample_index.duplicated().sum()),
            "nonincreasing_host_times": int(host_dt.le(0).sum()),
            "host_interval_seconds_min_median_max": [float(host_dt.min()),float(host_dt.median()),float(host_dt.max())],
            "device_interval_ms_min_median_max": [float(device_dt.min()),float(device_dt.median()),float(device_dt.max())],
            "phase_is_hold_mismatches": int(d.phase.eq("hold").ne(d.is_hold.eq(1)).sum()),
            "groups": int(d.loc[d.set_id.between(1,7)].groupby(["set_id", "rep"]).ngroups),
            "sensors": [],
        }
        for sensor in range(1,11):
            adc = d[f"adc_s{sensor}"].to_numpy(float)
            resistance = d[f"r_s{sensor}_ohm"].to_numpy(float)
            normalized = d[f"dr_s{sensor}"].to_numpy(float)
            good = np.isfinite(adc) & np.isfinite(resistance) & (adc>0) & (adc<4095) & (resistance>0)
            with np.errstate(divide="ignore",invalid="ignore"):
                expected = 3300*adc/(4095-adc)
                reverse = 3300*(4095-adc)/adc
                r0 = resistance/(1+normalized)
            r0 = r0[np.isfinite(r0)]
            record["sensors"].append({
                "sensor": sensor,
                "qc_invalid": int((d[f"qc_high_adc_s{sensor}"].ne(0)|d[f"qc_low_adc_s{sensor}"].ne(0)).sum()),
                "normalized_missing": int(np.isnan(normalized).sum()),
                "median_relative_resistance_error_sensor_to_ground_formula": float(np.median(np.abs(resistance[good]-expected[good])/resistance[good])),
                "median_relative_resistance_error_reversed_formula": float(np.median(np.abs(resistance[good]-reverse[good])/resistance[good])),
                "inferred_r0_median_ohms": float(np.median(r0)),
                "inferred_r0_range_ohms": float(np.max(r0)-np.min(r0)),
            })
        records.append(record)
    report = {"participants": records, "interpretation": [
        "The stored device-time interval is 50 ms throughout all three exports, while host reception time varies. Do not interpret reception-time bursts alone as irregular sensor sampling.",
        "The resistance fields numerically match R=3300*ADC/(4095-ADC). This checks exported arithmetic, not the physical resistor, actual divider wiring, or ESP32 calibration.",
        "No source values, timing metadata, labels or QC flags were changed by this audit. Existing protocol labels were retained; timestamp/label synchronization would need acquisition records to verify independently."
    ]}
    output.write_text(json.dumps(report, indent=2))
    print(output)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    run(a.data_dir, a.out)
