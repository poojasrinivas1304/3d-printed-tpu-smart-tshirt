"""Portable entry point; original analysis files and saved results stay unchanged."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def verify_files():
    for f in json.loads((ROOT/'FILES.json').read_text()):
        assert sha(ROOT/f['path']) == f['sha256'], f['path']
    for f in json.loads((ROOT/'INPUTS.json').read_text()):
        assert sha(ROOT/f['path']) == f['sha256'], f['path']

def prepare(repository):
    for f in json.loads((ROOT/'INPUTS.json').read_text()):
        source = repository/f['repository_path']
        assert sha(source) == f['sha256'], f'Input differs from the frozen analysis: {source}'
        target = ROOT/f['path']
        if target.exists():
            assert sha(target) == f['sha256'], target
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
    verify_files()
    print('All packaged files and unchanged public input datasets match their SHA-256 hashes.')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['prepare','figures','verify','fit'])
    p.add_argument('--repository', type=Path)
    p.add_argument('--output', type=Path)
    p.add_argument('--jobs', type=int, default=4)
    a = p.parse_args()
    if a.action == 'prepare':
        assert a.repository, '--repository must name the downloaded/cloned repository root'
        prepare(a.repository.resolve())
        return
    verify_files()
    if a.action == 'fit':
        assert a.output and not a.output.exists(), '--output must be a new directory'
        subprocess.run([sys.executable,str(ROOT/'tshirt_temporal_test_20260918/benchmark.py'),
                        '--out',str(a.output.resolve()),'--jobs',str(a.jobs)],check=True)
        return
    # These historical scripts write report artifacts. Run them in an isolated copy.
    work = Path(tempfile.mkdtemp(prefix='tshirt-reproduction-'))/'analysis'
    shutil.copytree(ROOT,work,ignore=shutil.ignore_patterns('__pycache__'))
    print(f'Isolated reproduction directory: {work}',flush=True)
    if a.action == 'figures':
        subprocess.run([sys.executable,str(work/'tshirt_results_update_20260918/build_figures.py')],check=True)
    else:
        temporal = work/'tshirt_temporal_test_20260918'
        subprocess.run([sys.executable,str(temporal/'test_features.py')],check=True)
        sys.path.insert(0,str(temporal))
        spec=importlib.util.spec_from_file_location('archived_verification',temporal/'verify_and_report.py')
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        digest=module.b.digest
        def relocated_digest(path):
            path=Path(path)
            if path.is_absolute() and '/outputs/' in str(path):
                path=work/str(path).split('/outputs/',1)[1]
            return digest(path)
        # Resolve original provenance paths against the package, never the author's laptop.
        module.b.digest=relocated_digest
        module.verify()
    if a.output:
        assert not a.output.exists(), '--output must be a new directory'
        a.output.mkdir(parents=True)
        folders=['tshirt_results_update_20260918'] if a.action=='figures' else ['tshirt_temporal_test_20260918']
        for folder in folders:
            shutil.copytree(work/folder,a.output/folder,ignore=shutil.ignore_patterns('__pycache__'))
    verify_files()
    print('Reproduction finished; archived files and public datasets are unchanged.')

if __name__=='__main__':
    main()
