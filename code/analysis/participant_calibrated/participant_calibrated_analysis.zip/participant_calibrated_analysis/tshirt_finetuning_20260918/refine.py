#!/usr/bin/env python3
"""One fixed participant-specific macro-F1 refinement round; see PLAN.md."""
from __future__ import annotations
import argparse
import importlib.util
import json
import math
import platform
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from joblib import Parallel, delayed, parallel_config
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.metrics import confusion_matrix

MULTIPLIERS=(0.5,0.75,1.0,1.25,1.5,2.0,3.0)
LABELS=np.arange(1,9)
PRIMARY='Refined macro-F1 + standing weight'
UNWEIGHTED='Refined macro-F1, no decision weight'
OLD_F1='Original grid selected by macro-F1'


def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def dump(path,obj):
    path.write_text(json.dumps(obj,indent=2,allow_nan=False))


def metric(y,pred):
    counts=confusion_matrix(y,pred,labels=LABELS)
    tp=counts.diagonal()
    supports=counts.sum(1)
    predicted=counts.sum(0)
    precision=np.divide(tp,predicted,out=np.zeros(8),where=predicted!=0)
    recall=np.divide(tp,supports,out=np.zeros(8),where=supports!=0)
    f1=np.divide(2*tp,predicted+supports,out=np.zeros(8),where=(predicted+supports)!=0)
    return dict(macro_precision=float(precision.mean()),macro_recall=float(recall.mean()),
                macro_f1=float(f1.mean()),accuracy=float(tp.sum()/counts.sum()),
                standing_recall=float(recall[0]),support=int(counts.sum()),
                class_support=supports.tolist(),class_precision=precision.tolist(),
                class_recall=recall.tolist(),class_f1=f1.tolist(),confusion_counts=counts.tolist())


def grid():
    result=[]
    for variant in ['original_1s','context_2s']:
        for family,leaves in [('ExtraTrees',[1,2,4,8]),('RF',[2,4])]:
            for leaf in leaves:
                for max_features in ['sqrt',0.5]:
                    for class_weight in [None,'balanced']:
                        result.append(dict(candidate_id=len(result),family=family,variant=variant,
                                           n_estimators=200,min_samples_leaf=leaf,
                                           max_features=max_features,class_weight=class_weight))
    assert len(result)==48
    return result


def estimator(candidate,seed):
    cls=ExtraTreesClassifier if candidate['family']=='ExtraTrees' else RandomForestClassifier
    kwargs={k:v for k,v in candidate.items() if k not in ['candidate_id','family','variant']}
    return cls(**kwargs,random_state=seed,n_jobs=1)


def decide(probabilities,classes,multiplier):
    weighted=probabilities.copy()
    weighted[:,np.flatnonzero(classes==1)[0]]*=multiplier
    return classes[np.argmax(weighted,axis=1)]


def inner_fit(candidate,prepared,outer):
    per_multiplier={a:[] for a in MULTIPLIERS}
    for inner,tx,y,vx,truth in prepared[candidate['variant']]:
        model=estimator(candidate,42+1000*outer+10*inner)
        model.fit(tx,y)
        probs=model.predict_proba(vx)
        assert np.array_equal(model.classes_,LABELS)
        for a in MULTIPLIERS:
            result=metric(truth,decide(probs,model.classes_,a))
            per_multiplier[a].append(dict(inner_rep=inner,**{k:result[k] for k in
                ['macro_precision','macro_recall','macro_f1','accuracy','standing_recall','support']}))
    return [dict(candidate_id=candidate['candidate_id'],standing_multiplier=a,folds=rows,
                 mean_macro_f1=float(np.mean([r['macro_f1'] for r in rows])),
                 mean_accuracy=float(np.mean([r['accuracy'] for r in rows])),
                 mean_balanced_accuracy=float(np.mean([r['macro_recall'] for r in rows])))
            for a,rows in per_multiplier.items()]


def rank_key(r):
    return (-r['mean_macro_f1'],-r['mean_accuracy'],-r['mean_balanced_accuracy'],
            abs(math.log(r['standing_multiplier'])),r['candidate_id'],r['standing_multiplier'])


def run(args):
    started=time.time()
    args.out.mkdir(parents=True,exist_ok=False)
    source=args.benchmark
    bench=load_module(source/'benchmark.py','bench_refine')
    base=bench.import_baseline(source/'baseline_analysis.py')
    validation=load_module(source.parent/'tshirt_model_validation_20260918/validate.py','validation_refine')
    paths=[p for p in source.rglob('*') if p.is_file()]
    # Also preserve the completed participant-exclusion evidence.
    paths += [p for p in (source.parent/'tshirt_model_validation_20260918/results').glob('*') if p.is_file()]
    hashes={str(p):bench.digest(p) for p in paths}
    meta,features,_=bench.build_variants(base,source/'data/processed')
    saved_meta=pd.read_csv(source/'results/window_manifest.csv')
    pd.testing.assert_frame_equal(meta,saved_meta,check_dtype=False,atol=1e-8,rtol=0)
    settings=grid()
    old_settings=bench.candidates()
    search_old=pd.read_csv(source/'results/inner_search_scores.csv')
    manifest=dict(plan_sha256=bench.digest(Path(__file__).with_name('PLAN.md')),
                  script_sha256=bench.digest(__file__),source_hashes=hashes,
                  candidates=settings,multipliers=MULTIPLIERS,
                  versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,
                                sklearn=sklearn.__version__,joblib=joblib.__version__),
                  primary=PRIMARY,selection='mean inner macro-F1, accuracy, balanced accuracy, multiplier proximity to one, candidate ID, multiplier',
                  window_count=len(meta),held_windows=int(meta.period.eq('Held posture').sum()),
                  exploratory_second_round=True)
    dump(args.out/'manifest.json',manifest)
    print('Fixed search started: 48 tree candidates x 7 decision weights; 15 outer folds; unchanged decisions.',flush=True)
    predictions,searches,selections,split_audit=[],[],[],[]
    held=meta.period.eq('Held posture').to_numpy()
    y=meta.position_index.to_numpy(int)
    for person in sorted(meta.participant.unique()):
        for outer in range(1,6):
            p=meta.participant.eq(person).to_numpy()
            train=np.flatnonzero(p & held & meta.rep.ne(outer).to_numpy())
            test=np.flatnonzero(p & meta.rep.eq(outer).to_numpy())
            split_audit.append(dict(participant=person,outer_rep=outer,level='outer',**validation.checked_split(meta,train,test)))
            prepared={v:[] for v in features}
            for inner in sorted(set(meta.iloc[train].rep)):
                itrain=train[meta.iloc[train].rep.ne(inner).to_numpy()]
                valid=train[meta.iloc[train].rep.eq(inner).to_numpy()]
                split_audit.append(dict(participant=person,outer_rep=outer,inner_rep=int(inner),level='inner',**validation.checked_split(meta,itrain,valid)))
                for variant,x in features.items():
                    tx,vx=bench.preprocess(x[itrain],x[valid])
                    prepared[variant].append((int(inner),tx,y[itrain],vx,y[valid]))
            fits=Parallel(n_jobs=args.jobs)(delayed(inner_fit)(c,prepared,outer) for c in settings)
            candidates=[r for results in fits for r in results]
            assert len(candidates)==336
            searches.append(dict(participant=person,outer_rep=outer,search=candidates))
            primary=sorted(candidates,key=rank_key)[0]
            no_weight=sorted([r for r in candidates if r['standing_multiplier']==1],key=rank_key)[0]
            chosen=[(PRIMARY,primary),(UNWEIGHTED,no_weight)]
            old_inner=search_old.loc[search_old.participant.eq(person) & search_old.outer_rep.eq(outer)]
            ranked=old_inner.groupby('candidate_id').agg(macro_f1=('macro_f1','mean'),accuracy=('accuracy','mean'),
                       balanced_accuracy=('balanced_accuracy','mean')).reset_index().sort_values(
                       ['macro_f1','accuracy','balanced_accuracy','candidate_id'],ascending=[False,False,False,True])
            old_choice=ranked.iloc[0]
            old_candidate=old_settings[int(old_choice.candidate_id)]
            outer_cache={}
            for procedure,choice in chosen:
                candidate=settings[choice['candidate_id']]
                if candidate['candidate_id'] not in outer_cache:
                    tx,vx=bench.preprocess(features[candidate['variant']][train],features[candidate['variant']][test])
                    model=estimator(candidate,42+100000+1000*outer+3)
                    model.fit(tx,y[train])
                    outer_cache[candidate['candidate_id']]=(model.predict_proba(vx),model.classes_)
                probs,classes=outer_cache[candidate['candidate_id']]
                pred=decide(probs,classes,choice['standing_multiplier'])
                part=meta.iloc[test].copy()
                part['predicted_position']=pred
                part['procedure']=procedure
                part['candidate_id']=candidate['candidate_id']
                part['standing_multiplier']=choice['standing_multiplier']
                predictions.extend(part.to_dict('records'))
                mask=part.period.eq('Held posture')
                selections.append(dict(participant=person,outer_rep=outer,procedure=procedure,candidate=candidate,
                         standing_multiplier=choice['standing_multiplier'],inner_macro_f1=choice['mean_macro_f1'],
                         **metric(part.loc[mask,'position_index'],part.loc[mask,'predicted_position'])))
            pred=validation.fit_predict(bench,old_candidate,features,train,test,y,42+100000+1000*outer+3)
            part=meta.iloc[test].copy()
            part['predicted_position']=pred
            part['procedure']=OLD_F1
            part['candidate_id']=old_candidate['candidate_id']
            part['standing_multiplier']=1.0
            predictions.extend(part.to_dict('records'))
            mask=part.period.eq('Held posture')
            selections.append(dict(participant=person,outer_rep=outer,procedure=OLD_F1,candidate=old_candidate,
                     standing_multiplier=1.0,inner_macro_f1=float(old_choice.macro_f1),
                     **metric(part.loc[mask,'position_index'],part.loc[mask,'predicted_position'])))
            dump(args.out/'inner_search.json',searches)
            dump(args.out/'selections.json',selections)
            dump(args.out/'outer_predictions.json',predictions)
            print(f'Completed {person}, repetition {outer}; elapsed {time.time()-started:.0f}s. Outer metrics withheld until completion.',flush=True)
    frame=pd.DataFrame(predictions)
    records=[]
    for (procedure,period),df in frame.groupby(['procedure','period'],sort=False):
        for person,d in [('All',df),*list(df.groupby('participant'))]:
            records.append(dict(procedure=procedure,period=period,participant=person,
                                **metric(d.position_index,d.predicted_position)))
    for procedure,d in frame.groupby('procedure'):
        assert len(d)==2378 and d.window_id.nunique()==2378
        assert set(d.window_id)==set(meta.window_id)
        assert d.period.eq('Held posture').sum()==2032
    assert hashes=={str(p):bench.digest(p) for p in paths}
    dump(args.out/'metrics.json',records)
    dump(args.out/'split_audit.json',split_audit)
    manifest.update(elapsed_seconds=time.time()-started,completed=True,sources_unchanged=True,
                    inner_model_fits=2880,candidate_weight_evaluations=20160)
    dump(args.out/'manifest.json',manifest)
    for r in records:
        if r['participant']=='All' and r['period']=='Held posture':
            print({k:r[k] for k in ['procedure','macro_precision','macro_recall','macro_f1','accuracy','standing_recall','support']},flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--benchmark',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--jobs',type=int,default=4)
    a=p.parse_args()
    with parallel_config(backend='loky',inner_max_num_threads=1):
        run(a)
