# Participant-calibrated refinement: fixed second-round plan

This is a second exploratory development round, motivated by the already-observed standing errors. The previous outer folds have been inspected; repeating nested cross-validation does not turn these data into a fresh confirmatory test. Report this limitation, all prespecified comparisons, and any regressions. Do not revise this plan after inspecting this round's outer results.

## Data and evaluation

- Preserve original CSVs, labels, QC masks, normalization, benchmark and validation outputs byte-for-byte. No manual peak removal, new exclusions, boundary trimming, synthetic examples, relabeling or time/protocol predictors.
- Use the same all-ten-sensor features (original 20-sample statistics and up to 40 trailing samples within known protocol segments), 2,032 held decisions and 346 transition decisions.
- Fit participant-specific models with five outer repetition folds and four inner repetition folds. Fit imputation/scaling only on inner training or outer training data. Verify group/sample separation at both levels.
- Tune on held windows only; never use outer performance for selection. Report transition disagreement separately, not as errors against measured instantaneous physical posture.

## One bounded candidate search

- Extra Trees, 200 trees: minimum leaf size 1/2/4/8; maximum features sqrt/0.5; class weighting none/balanced (16 settings).
- Random forest, 200 trees: minimum leaf size 2/4; maximum features sqrt/0.5; class weighting none/balanced (8 settings).
- Cross those 24 settings with the two unchanged feature contexts: 48 fitted candidates per inner split.
- Decision-level standing score multiplier: 0.5, 0.75, 1, 1.25, 1.5, 2, 3. Multiply only the forest score for class 1, then take argmax over all eight classes. This is decision weighting, not calibrated probability estimation, abstention or label correction.
- Primary selection: maximize mean inner-fold macro-F1; break ties by mean accuracy, then mean balanced accuracy, then prefer a multiplier closest to one (absolute log multiplier), then candidate ID and multiplier. No minimum standing-recall constraint is imposed.
- This gives 336 candidate/decision-weight settings, evaluated through 2,880 inner model fits (four inner splits, 15 outer splits, 48 candidates). Fit every selected outer model once using all outer-training held windows.
- Use the original deterministic seeds: inner 42+1000*outer_rep+10*inner_rep; outer 42+100000+1000*outer_rep+3.

## Prespecified comparisons

1. Primary: new tree search and standing decision weight, selected by inner macro-F1.
2. Secondary ablation: same tree search, multiplier fixed at one, selected by inner macro-F1.
3. Secondary objective-only comparison: select from the previous 64-candidate grid by its recorded mean inner macro-F1, then accuracy, balanced accuracy and candidate ID; refit the selected outer candidate. Its search grid and inner scores were already recorded. This is not a new unseen-data assessment.
4. Keep the original RF baseline and previous balanced-accuracy-selected procedure unchanged as historical comparisons on the identical decisions.

Report pooled and participant macro precision, macro recall/balanced accuracy, macro-F1, accuracy, standing recall, support and confusion matrices. Retain all settings, fold-level metrics, inner search records, selected weights and predictions. Recount metrics independently from confusion counts and check source hashes at completion. Do not claim a generalization improvement or choose a different primary procedure after seeing outer outcomes.

No Overleaf, GitHub, ethics, date or source-data changes. No new participant-excluded analysis is required in this round; keep its existing record intact.
